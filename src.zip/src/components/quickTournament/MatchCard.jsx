import { useEffect, useState } from "react";

function MatchCard({
    roundId,
    match,
    skinsEnabled,
    onSaveScore,
    drawEditMode,
    selectedTeams,
    onSelectTeamForSwap
}) {
    const teamASelected =
        selectedTeams?.some(
            selection => selection.teamId === match.teamA.id
        );

    const teamBSelected =
        selectedTeams?.some(
            selection => selection.teamId === match.teamB.id
        );

    const [scoreA, setScoreA] = useState(match.scoreA ?? "");
    const [scoreB, setScoreB] = useState(match.scoreB ?? "");

    const [skinsA, setSkinsA] = useState(match.skinsA ?? "");
    const [skinsB, setSkinsB] = useState(match.skinsB ?? "");

    useEffect(() => {

        setScoreA(match.scoreA ?? "");
        setScoreB(match.scoreB ?? "");

        setSkinsA(match.skinsA ?? "");
        setSkinsB(match.skinsB ?? "");

    }, [
        match.scoreA,
        match.scoreB,
        match.skinsA,
        match.skinsB
    ]);

    const handleSave = () => {

        if (scoreA === "" || scoreB === "") {

            alert("Please enter both scores.");

            return;

        }

        if (
            skinsEnabled &&
            (
                skinsA === "" ||
                skinsB === ""
            )
        ) {

            alert("Please enter both skin scores.");

            return;

        }

        onSaveScore(

            roundId,

            match.id,

            scoreA,

            scoreB,

            skinsA,

            skinsB

        );

    };

    return (

        <div className="card h-100 shadow-sm bowlpoint-match-card">

            <div className="card-body bowlpoint-match-card-body">

                <button
                    type="button"
                    className={`btn w-100 text-start fw-bold mb-3 ${
                        drawEditMode && !match.completed
                            ? "btn-outline-primary"
                            : "btn-link text-dark p-0"
                    } ${
                        teamASelected
                            ? "border-primary bg-primary text-white"
                            : ""
                    }`}
                    disabled={!drawEditMode || match.completed}
                    onClick={() =>
                        onSelectTeamForSwap(
                            roundId,
                            match.teamA.id
                        )
                    }
                >
                    {teamASelected && (
                        <i className="bi bi-check-circle-fill me-2"></i>
                    )}

                    {match.teamA.name}
                </button>

                <div className="row g-3">

                    <div className={skinsEnabled ? "col-6" : "col-12"}>

                        <label className="form-label">

                            Score

                        </label>

                        <input
                            type="number"
                            min="0"
                            className="form-control form-control-lg text-center bowlpoint-score-input"
                            placeholder="Enter score"
                            inputMode="numeric"
                            value={scoreA}
                            disabled={match.completed}
                            onChange={(e) =>
                                setScoreA(e.target.value)
                            }
                        />

                    </div>

                    {skinsEnabled && (

                        <div className="col-6">

                            <label className="form-label">

                                Skins

                            </label>

                            <input
                                type="number"
                                min="0"
                                className="form-control form-control-lg text-center bowlpoint-score-input bowlpoint-skins-input"
                                placeholder="Enter skins"
                                inputMode="numeric"
                                value={skinsA}
                                disabled={match.completed}
                                onChange={(e) =>
                                    setSkinsA(e.target.value)
                                }
                            />

                        </div>

                    )}

                </div>

                <div className="d-flex align-items-center my-4 bowlpoint-match-divider">

                    <div className="flex-grow-1 border-top"></div>

                    <span className="mx-3 text-muted fw-bold">
                        VS
                    </span>

                    <div className="flex-grow-1 border-top"></div>

                </div>

                <button
                    type="button"
                    className={`btn w-100 text-start fw-bold mb-3 ${
                        drawEditMode && !match.completed
                            ? "btn-outline-primary"
                            : "btn-link text-dark p-0"
                    } ${
                        teamBSelected
                            ? "border-primary bg-primary text-white"
                            : ""
                    }`}
                    disabled={!drawEditMode || match.completed}
                    onClick={() =>
                        onSelectTeamForSwap(
                            roundId,
                            match.teamB.id
                        )
                    }
                >
                    {teamBSelected && (
                        <i className="bi bi-check-circle-fill me-2"></i>
                    )}

                    {match.teamB.name}
                </button>

                <div className="row g-3">

                    <div className={skinsEnabled ? "col-6" : "col-12"}>

                        <label className="form-label">

                            Score

                        </label>

                        <input
                            type="number"
                            min="0"
                            className="form-control form-control-lg text-center bowlpoint-score-input"
                            placeholder="Enter score"
                            inputMode="numeric"
                            value={scoreB}
                            disabled={match.completed}
                            onChange={(e) =>
                                setScoreB(e.target.value)
                            }
                        />

                    </div>

                    {skinsEnabled && (

                        <div className="col-6">

                            <label className="form-label">

                                Skins

                            </label>

                            <input
                                type="number"
                                min="0"
                                className="form-control form-control-lg text-center bowlpoint-score-input bowlpoint-skins-input"
                                placeholder="Enter skins"
                                inputMode="numeric"
                                value={skinsB}
                                disabled={match.completed}
                                onChange={(e) =>
                                    setSkinsB(e.target.value)
                                }
                            />

                        </div>

                    )}

                </div>

            </div>

            <div className="card-footer bg-white bowlpoint-match-card-footer">

                {match.completed ? (

                    <button
                        className="btn btn-success w-100"
                        disabled
                    >

                        ✓ Score Saved

                    </button>

                ) : (

                    <button
                        className="btn btn-primary w-100"
                        onClick={handleSave}
                    >

                        Save Score

                    </button>

                )}

            </div>

        </div>

    );

}

export default MatchCard;