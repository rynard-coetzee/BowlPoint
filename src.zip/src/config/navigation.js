const navigation = [

    {
        title: "Dashboard",
        path: "/",
        icon: "house-fill"
    },

    {
        title: "Quick Score",
        path: "/quick-score",
        icon: "diagram-3-fill"
    },

    {
        title: "Quick Draw",
        path: "/quick-draw",
        icon: "shuffle"
    },

    {
        title: "Competitions",
        path: "/competitions",
        icon: "trophy-fill"
    },

    {
        title: "Clubs",
        roles: ["admin", "comp_secretary"],
        path: "/clubs",
        icon: "building-fill"
    },

    {
        title: "Club Facilities",
        roles: ["admin", "comp_secretary"],
        path: "/facilities",
        icon: "grid-3x3-gap-fill"
    },
    {
        title: "Facility Calendar",
        roles: ["admin", "comp_secretary"],
        path: "/facility-calendar",
        icon: "calendar-week-fill"
    },

    {
        title: "Players",
        roles: ["admin", "comp_secretary"],
        path: "/players",
        icon: "person-fill"
    },

    {
        title: "Reports",
        path: "/reports",
        icon: "bar-chart-fill"
    },

    {
        title: "Users",
        path: "/users",
        icon: "people-fill",
        roles: ["admin", "comp_secretary"]
    },

    {
        title: "Audit Log",
        roles: ["admin"],
        path: "/audit-log",
        icon: "clipboard-data-fill"
    },

    {
        title: "Settings",
        roles: ["admin", "comp_secretary"],
        path: "/settings",
        icon: "gear-fill"
    }

];

export default navigation;