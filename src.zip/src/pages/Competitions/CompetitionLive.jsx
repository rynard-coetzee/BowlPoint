import { Fragment, useCallback, useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "../../lib/supabaseClient";
import { getPlayerDisplayName } from "../../utils/playerDisplay";

function getSectionByeTeam(section, round, matches) {
    const roundMatches = (matches || []).filter(
        match => match.section_id === section?.id && match.round_id === round?.id
    );

    if (!roundMatches.length || !(section?.teams || []).length) return null;

    const playingTeamIds = new Set();
    roundMatches.forEach(match => {
        if (match.team_a_id) playingTeamIds.add(match.team_a_id);
        if (match.team_b_id) playingTeamIds.add(match.team_b_id);
    });

    return (section.teams || []).find(team => !playingTeamIds.has(team.id)) || null;
}

function calculateStandings(section, matches, scoring) {
    const winPoints = Number(scoring?.win ?? 2);
    const drawPoints = Number(scoring?.draw ?? 1);
    const lossPoints = Number(scoring?.loss ?? 0);
    const skinsEnabled = Boolean(scoring?.skins?.enabled);
    const pointsPerSkin = Number(scoring?.skins?.pointsPerSkin ?? 1);

    return (section.teams || []).map(team => {
        const row = {
            team,
            played: 0,
            wins: 0,
            draws: 0,
            losses: 0,
            skinsWon: 0,
            points: 0,
            shotsFor: 0,
            shotsAgainst: 0,
            aggregate: 0
        };

        matches
            .filter(match => match.section_id === section.id && match.completed)
            .forEach(match => {
                if (match.team_a_id !== team.id && match.team_b_id !== team.id) return;

                const isA = match.team_a_id === team.id;
                const sf = Number(isA ? match.score_a : match.score_b);
                const sa = Number(isA ? match.score_b : match.score_a);

                row.played += 1;
                row.shotsFor += sf;
                row.shotsAgainst += sa;

                const skins = Number(isA ? match.skins_a : match.skins_b) || 0;
                if (skinsEnabled) {
                    row.skinsWon += skins;
                    row.points += skins * pointsPerSkin;
                }

                if (sf > sa) {
                    row.wins += 1;
                    row.points += winPoints;
                } else if (sf === sa) {
                    row.draws += 1;
                    row.points += drawPoints;
                } else {
                    row.losses += 1;
                    row.points += lossPoints;
                }
            });

        row.aggregate = row.shotsFor - row.shotsAgainst;
        return row;
    }).sort((a, b) =>
        b.points - a.points ||
        b.aggregate - a.aggregate ||
        b.shotsFor - a.shotsFor ||
        (a.team.team_number || 0) - (b.team.team_number || 0)
    );
}

function StatusBadge({ status }) {
    const config = {
        draft: ["bg-secondary", "Draft"],
        registration: ["bg-info text-dark", "Registration"],
        draw_generated: ["bg-primary", "Draw Generated"],
        in_progress: ["bg-warning text-dark", "Live"],
        completed: ["bg-success", "Completed"],
        cancelled: ["bg-danger", "Cancelled"]
    };

    const [className, label] = config[status] || ["bg-secondary", status || "Competition"];
    return <span className={`badge ${className}`}>{label}</span>;
}

function CompetitionLive() {
    const { publicCode } = useParams();
    const [competition, setCompetition] = useState(null);
    const [teams, setTeams] = useState([]);
    const [rounds, setRounds] = useState([]);
    const [sections, setSections] = useState([]);
    const [matches, setMatches] = useState([]);
    const [facilityBookings, setFacilityBookings] = useState([]);
    const [facilityGreens, setFacilityGreens] = useState([]);
    const [facilityRinks, setFacilityRinks] = useState([]);
    const [sectionVenueRows, setSectionVenueRows] = useState([]);
    const [venueClubs, setVenueClubs] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const [lastUpdated, setLastUpdated] = useState(null);

    const loadData = useCallback(async () => {
        if (!publicCode) return;

        setError("");

        const competitionResult = await supabase
            .from("competitions")
            .select("id, name, status, public_code, format, structure, scoring, start_date, end_date")
            .eq("public_code", publicCode.toUpperCase())
            .maybeSingle();

        if (competitionResult.error) throw competitionResult.error;
        if (!competitionResult.data) {
            setCompetition(null);
            setError("Competition not found or is not available publicly.");
            setLoading(false);
            return;
        }

        const competitionId = competitionResult.data.id;

        const [teamsResult, roundsResult, sectionsResult, matchesResult, bookingsResult, greensResult, rinksResult, sectionVenuesResult, clubsResult] = await Promise.all([
            supabase
                .from("competition_teams")
                .select(`
                    id,
                    competition_id,
                    club_id,
                    team_number,
                    team_name,
                    status,
                    clubs (
                        id,
                        name,
                        short_name
                    ),
                    competition_team_players (
                        id,
                        player_id,
                        position,
                        position_order,
                        players (
                            id,
                            first_name,
                            nickname,
                            last_name,
                            display_name
                        )
                    )
                `)
                .eq("competition_id", competitionId)
                .order("team_number"),
            supabase
                .from("competition_rounds")
                .select("id, competition_id, competition_day_id, round_number, round_name, status, competition_days(id, day_number, playing_date, name, venue_club_id)")
                .eq("competition_id", competitionId)
                .order("round_number"),
            supabase
                .from("competition_sections")
                .select("id, competition_id, section_number, section_name")
                .eq("competition_id", competitionId)
                .order("section_number"),
            supabase
                .from("competition_matches")
                .select("id, competition_id, round_id, section_id, match_number, team_a_id, team_b_id, score_a, score_b, skins_a, skins_b, completed, completed_at, next_match_id, next_match_slot")
                .eq("competition_id", competitionId)
                .order("match_number"),
            supabase
                .from("facility_bookings")
                .select("id, competition_id, match_id, green_id, rink_id, playing_date, session_name, starts_at, ends_at, status")
                .eq("competition_id", competitionId)
                .neq("status", "cancelled"),
            supabase
                .from("club_greens")
                .select("id, name, club_id")
                .order("name"),
            supabase
                .from("green_rinks")
                .select("id, label, green_id"),
            supabase
                .from("competition_section_venues")
                .select("section_id, club_id")
                .eq("competition_id", competitionId),
            supabase
                .from("clubs")
                .select("id, name, short_name")
        ]);

        if (teamsResult.error) throw teamsResult.error;
        if (roundsResult.error) throw roundsResult.error;
        if (sectionsResult.error) throw sectionsResult.error;
        if (matchesResult.error) throw matchesResult.error;
        if (bookingsResult.error) throw bookingsResult.error;
        if (greensResult.error) throw greensResult.error;
        if (rinksResult.error) throw rinksResult.error;
        if (sectionVenuesResult.error) throw sectionVenuesResult.error;
        if (clubsResult.error) throw clubsResult.error;

        const activeBookings = bookingsResult.data || [];
        const greenRows = greensResult.data || [];
        const rinkRows = rinksResult.data || [];
        const venueRows = sectionVenuesResult.data || [];
        const clubRows = clubsResult.data || [];
        const bookingByMatchId = new Map(activeBookings.map(booking => [booking.match_id, booking]));
        const greenById = new Map(greenRows.map(green => [green.id, green]));
        const rinkById = new Map(rinkRows.map(rink => [rink.id, rink]));
        const venueClubBySectionId = new Map(venueRows.map(row => [row.section_id, row.club_id]));
        const clubById = new Map(clubRows.map(club => [club.id, club]));

        const teamById = new Map((teamsResult.data || []).map(team => [team.id, team]));
        const roundById = new Map((roundsResult.data || []).map(round => [round.id, round]));

        const sectionIds = (sectionsResult.data || []).map(section => section.id);
        const sectionTeamsResult = sectionIds.length
            ? await supabase
                .from("competition_section_teams")
                .select("id, section_id, competition_team_id")
                .in("section_id", sectionIds)
            : { data: [], error: null };

        if (sectionTeamsResult.error) throw sectionTeamsResult.error;

        const sectionTeams = sectionTeamsResult.data || [];
        const hydratedSections = (sectionsResult.data || []).map(section => ({
            ...section,
            teams: sectionTeams
                .filter(row => row.section_id === section.id)
                .map(row => teamById.get(row.competition_team_id))
                .filter(Boolean)
        }));

        const hydratedMatches = (matchesResult.data || []).map(match => ({
            ...match,
            teamA: teamById.get(match.team_a_id),
            teamB: teamById.get(match.team_b_id),
            round: roundById.get(match.round_id),
            facilityBooking: bookingByMatchId.get(match.id) || null
        }));

        setCompetition(competitionResult.data);
        setTeams(teamsResult.data || []);
        setRounds(roundsResult.data || []);
        setSections(hydratedSections);
        setMatches(hydratedMatches);
        setFacilityBookings(activeBookings);
        setFacilityGreens(greenRows);
        setFacilityRinks(rinkRows);
        setSectionVenueRows(venueRows);
        setVenueClubs(clubRows);
        setLastUpdated(new Date());
        setLoading(false);
    }, [publicCode]);

    useEffect(() => {
        let cancelled = false;

        const run = async () => {
            try {
                if (!cancelled) setLoading(true);
                await loadData();
            } catch (loadError) {
                if (!cancelled) {
                    console.error("Unable to load public competition:", loadError);
                    setError(loadError.message || "Unable to load competition.");
                    setLoading(false);
                }
            }
        };

        run();
        return () => { cancelled = true; };
    }, [loadData]);

    useEffect(() => {
        if (!competition?.id) return undefined;

        const fallbackRefresh = window.setInterval(() => {
            loadData();
        }, 15000);

        const channel = supabase
            .channel(`competition-live-${competition.id}`)
            .on(
                "postgres_changes",
                {
                    event: "*",
                    schema: "public",
                    table: "competition_matches",
                    filter: `competition_id=eq.${competition.id}`
                },
                () => loadData()
            )
            .on(
                "postgres_changes",
                {
                    event: "*",
                    schema: "public",
                    table: "competitions",
                    filter: `id=eq.${competition.id}`
                },
                () => loadData()
            )
            .subscribe();

        return () => {
            window.clearInterval(fallbackRefresh);
            supabase.removeChannel(channel);
        };
    }, [competition?.id, loadData]);

    const playerName = (player) => {
        return getPlayerDisplayName(player);
    };

    const getTeamPlayerNames = (team) => {
        return (team?.competition_team_players || [])
            .slice()
            .sort((a, b) => (a.position_order || 0) - (b.position_order || 0))
            .map(item => playerName(item.players))
            .filter(Boolean);
    };

    const getTeamBaseName = (team) => {
        if (!team) return "TBD";

        const explicitName = team.team_name?.trim();
        if (explicitName) return explicitName;

        const clubCode =
            team.clubs?.short_name?.trim() ||
            team.club_short_name?.trim() ||
            team.clubs?.name?.trim() ||
            "TEAM";

        const clubTeams = teams
            .filter(item => item?.club_id && team.club_id && item.club_id === team.club_id)
            .slice()
            .sort((a, b) => {
                const numberA = a.team_number || 0;
                const numberB = b.team_number || 0;
                if (numberA !== numberB) return numberA - numberB;
                return String(a.id || "").localeCompare(String(b.id || ""));
            });

        const sequenceIndex = clubTeams.findIndex(item => item.id === team.id);
        const sequenceNumber = sequenceIndex >= 0 ? sequenceIndex + 1 : (team.team_number || 1);

        return `${clubCode}${sequenceNumber}`;
    };

    const TeamDisplay = ({ team, className = "" }) => {
        if (!team) return <span className={className}>TBD</span>;

        const playerNames = getTeamPlayerNames(team);

        return (
            <span className={className}>
                <strong>{getTeamBaseName(team)}</strong>
                {playerNames.length > 0 && (
                    <span className="d-block small text-muted fw-normal mt-1">
                        ({playerNames.join(", ")})
                    </span>
                )}
            </span>
        );
    };

    const getSectionVenueName = (section) => {
        const clubId = section ? sectionVenueRows.find(row => row.section_id === section.id)?.club_id : null;
        const club = clubId ? venueClubs.find(item => item.id === clubId) : null;
        return club?.name || club?.short_name || null;
    };

    const getMatchRinkLabel = (match) => {
        const booking = match?.facilityBooking || facilityBookings.find(item => item.match_id === match?.id);
        if (!booking) return "Rink TBC";
        const green = facilityGreens.find(item => item.id === booking.green_id);
        const rink = facilityRinks.find(item => item.id === booking.rink_id);
        const venue = green ? venueClubs.find(item => item.id === green.club_id) : null;
        const parts = [];
        if (green?.name) parts.push(green.name);
        if (rink?.label) parts.push(`Rink ${rink.label}`);
        if (parts.length === 0) return "Rink TBC";
        return `${parts.join(" · ")}${venue?.name ? ` — ${venue.name}` : ""}`;
    };

    const sectionalRoundNumber = useMemo(() => {
        const numbers = matches
            .filter(match => match.section_id !== null && match.round?.round_number)
            .map(match => match.round.round_number);
        return numbers.length ? Math.max(...numbers) : 0;
    }, [matches]);

    const currentRound = useMemo(() => {
        return rounds.find(round => {
            const roundMatches = matches.filter(match => match.round_id === round.id);
            return roundMatches.length > 0 && roundMatches.some(match => !match.completed);
        }) || null;
    }, [rounds, matches]);

    const recentResults = useMemo(() => {
        return matches
            .filter(match => match.completed)
            .sort((a, b) => new Date(b.completed_at || 0) - new Date(a.completed_at || 0))
            .slice(0, 8);
    }, [matches]);

    const playoffRounds = useMemo(() => {
        return rounds
            .filter(round => round.round_number > sectionalRoundNumber)
            .map(round => ({
                ...round,
                matches: matches
                    .filter(match => match.round_id === round.id)
                    .sort((a, b) => a.match_number - b.match_number)
            }));
    }, [rounds, matches, sectionalRoundNumber]);

    const sectionalRounds = useMemo(() => {
        return rounds
            .filter(round => round.round_number <= sectionalRoundNumber)
            .map(round => ({
                ...round,
                matches: matches
                    .filter(match => match.round_id === round.id && match.section_id)
                    .sort((a, b) => a.match_number - b.match_number)
            }))
            .filter(round => round.matches.length);
    }, [rounds, matches, sectionalRoundNumber]);

    const competitionProgress = useMemo(() => {
        const completed = matches.filter(match => match.completed).length;
        return {
            completed,
            total: matches.length,
            percent: matches.length ? Math.round((completed / matches.length) * 100) : 0
        };
    }, [matches]);

    const clubPlayerSummary = useMemo(() => {
        const byClub = new Map();

        teams.forEach(team => {
            const clubId = team.club_id || `team-${team.id}`;
            const clubName =
                team.clubs?.name?.trim() ||
                team.club_short_name?.trim() ||
                team.clubs?.short_name?.trim() ||
                "Unassigned";
            const clubCode =
                team.clubs?.short_name?.trim() ||
                team.club_short_name?.trim() ||
                "";

            if (!byClub.has(clubId)) {
                byClub.set(clubId, {
                    id: clubId,
                    name: clubName,
                    code: clubCode,
                    playerIds: new Set()
                });
            }

            const entry = byClub.get(clubId);
            (team.competition_team_players || []).forEach(item => {
                if (item.player_id) entry.playerIds.add(item.player_id);
            });
        });

        return Array.from(byClub.values())
            .map(entry => ({
                ...entry,
                playerCount: entry.playerIds.size
            }))
            .sort((a, b) =>
                b.playerCount - a.playerCount ||
                a.name.localeCompare(b.name)
            );
    }, [teams]);

    if (loading) {
        return (
            <div className="container py-5 text-center">
                <div className="spinner-border text-primary mb-3"></div>
                <div className="text-muted">Loading live competition...</div>
            </div>
        );
    }

    if (error || !competition) {
        return (
            <div className="container py-5">
                <div className="card shadow-sm border-0">
                    <div className="card-body text-center py-5">
                        <i className="bi bi-exclamation-circle fs-1 text-danger"></i>
                        <h2 className="mt-3">Competition unavailable</h2>
                        <p className="text-muted mb-0">{error || "This competition could not be found."}</p>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="min-vh-100 bg-light">
            <div className="container py-3 py-md-5" style={{ maxWidth: 1100 }}>
                <div className="card shadow-sm border-0 mb-3 mb-md-4">
                    <div className="card-body p-3 p-md-4">
                        <div className="d-flex justify-content-between align-items-start gap-3 flex-wrap">
                            <div>
                                <div className="text-uppercase small text-muted fw-semibold mb-1">BowlPoint Live Competition</div>
                                <h1 className="h2 mb-2">{competition.name}</h1>
                                <div className="d-flex flex-wrap gap-2 align-items-center">
                                    <StatusBadge status={competition.status} />
                                    {currentRound && <span className="badge bg-light text-dark border">{currentRound.round_name || `Round ${currentRound.round_number}`}</span>}
                                </div>
                            </div>
                            <div className="text-md-end">
                                <div className="small text-muted">Competition code</div>
                                <div className="fs-4 fw-bold font-monospace">{competition.public_code}</div>
                                <div className="small text-muted mt-1">Live updates enabled</div>
                            </div>
                        </div>
                        <div className="mt-4">
                            <div className="d-flex justify-content-between small mb-1">
                                <span className="text-muted">Competition progress</span>
                                <strong>{competitionProgress.completed} / {competitionProgress.total} matches</strong>
                            </div>
                            <div className="progress" style={{ height: 8 }}>
                                <div className="progress-bar bg-success" role="progressbar" style={{ width: `${competitionProgress.percent}%` }} aria-valuenow={competitionProgress.percent} aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>

                {currentRound && (
                    <div className="alert alert-primary border-0 shadow-sm mb-3 mb-md-4">
                        <i className="bi bi-broadcast me-2"></i>
                        <strong>Live now:</strong> {currentRound.round_name || `Round ${currentRound.round_number}`}
                        {currentRound.competition_days?.playing_date ? ` • ${currentRound.competition_days.playing_date}` : ""}
                    </div>
                )}

                {sections.length > 0 && (
                    <>
                        <div className="d-flex justify-content-between align-items-end mb-2">
                            <div>
                                <h2 className="h4 mb-1">Section Standings</h2>
                                <div className="text-muted small">Points first, then aggregate, then shots for.</div>
                            </div>
                        </div>

                        <div className="card shadow-sm border-0 mb-4">
                            <div className="card-header bg-white">
                                <h2 className="h5 mb-1"><i className="bi bi-people me-2"></i>Players by Club</h2>
                                <div className="small text-muted">Number of players representing each club in this competition.</div>
                            </div>
                            <div className="table-responsive">
                                <table className="table table-sm mb-0 align-middle">
                                    <thead className="table-light">
                                        <tr>
                                            <th>Club</th>
                                            <th className="text-center" style={{ width: 180 }}>Players</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {clubPlayerSummary.map(club => (
                                            <tr key={club.id}>
                                                <td>
                                                    <span className="fw-semibold">{club.name}</span>
                                                    {club.code && club.code !== club.name && (
                                                        <span className="text-muted small ms-2">({club.code})</span>
                                                    )}
                                                </td>
                                                <td className="text-center fw-bold">{club.playerCount}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div className="row g-3 mb-4">
                            {sections.map(section => {
                                const standings = calculateStandings(section, matches, competition.scoring);
                                const sectionMatches = matches.filter(match => match.section_id === section.id);
                                const complete = sectionMatches.length > 0 && sectionMatches.every(match => match.completed);

                                return (
                                    <div className="col-12" key={section.id}>
                                        <div className="card shadow-sm border-0 h-100">
                                            <div className="card-header bg-white d-flex justify-content-between align-items-center">
                                                <div>
                                                    <strong>{section.section_name}</strong>
                                                    {getSectionVenueName(section) && <div className="small text-muted mt-1"><i className="bi bi-geo-alt me-1"></i>{getSectionVenueName(section)}</div>}
                                                </div>
                                                <span className={`badge ${complete ? "bg-success" : "bg-secondary"}`}>
                                                    {complete ? "Complete" : `${sectionMatches.filter(match => match.completed).length}/${sectionMatches.length}`}
                                                </span>
                                            </div>
                                            <div className="table-responsive">
                                                <table className="table table-sm mb-0 align-middle">
                                                    <thead className="table-light">
                                                        <tr>
                                                            <th style={{ width: 42 }}>#</th>
                                                            <th>Team</th>
                                                            <th className="text-center">P</th>
                                                            {competition.scoring?.skins?.enabled && <th className="text-center">Skins</th>}
                                                            <th className="text-center">Pts</th>
                                                            <th className="text-center">Agg</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {standings.map((row, index) => (
                                                            <tr key={row.team.id} className={index === 0 && complete ? "table-success" : ""}>
                                                                <td className="fw-semibold">{index + 1}</td>
                                                                <td>
                                                                    <div className="fw-semibold"><TeamDisplay team={row.team} /></div>
                                                                </td>
                                                                <td className="text-center">{row.played}</td>
                                                                {competition.scoring?.skins?.enabled && <td className="text-center">{row.skinsWon}</td>}
                                                                <td className="text-center fw-bold">{row.points}</td>
                                                                <td className="text-center">{row.aggregate > 0 ? `+${row.aggregate}` : row.aggregate}</td>
                                                            </tr>
                                                        ))}
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </>
                )}

                {sectionalRounds.length > 0 && (
                    <div className="card shadow-sm border-0 mb-4">
                        <div className="card-header bg-white d-flex justify-content-between align-items-center">
                            <div>
                                <h2 className="h5 mb-1"><i className="bi bi-grid-3x3-gap me-2"></i>Sectional Fixtures & Results</h2>
                                <div className="small text-muted">Games are grouped by section so spectators can quickly find a specific match.</div>
                            </div>
                            <span className="badge bg-primary">{sectionalRounds.length} rounds</span>
                        </div>
                        <div className="card-body">
                            {sections.map(section => {
                                const sectionMatches = matches
                                    .filter(match => match.section_id === section.id)
                                    .sort((a, b) => (a.round?.round_number || 0) - (b.round?.round_number || 0) || a.match_number - b.match_number);
                                if (!sectionMatches.length) return null;
                                return (
                                    <div className="border rounded mb-3" key={section.id}>
                                        <div className="bg-light border-bottom px-3 py-2 d-flex justify-content-between align-items-center">
                                            <div>
                                                <strong>{section.section_name}</strong>
                                                {getSectionVenueName(section) && <div className="small text-muted mt-1"><i className="bi bi-geo-alt me-1"></i>{getSectionVenueName(section)}</div>}
                                            </div>
                                            <span className="small text-muted">{sectionMatches.filter(m => m.completed).length}/{sectionMatches.length} complete</span>
                                        </div>
                                        <div className="table-responsive">
                                            <table className="table table-sm align-middle mb-0">
                                                <thead className="table-light">
                                                    <tr>
                                                        <th>Round</th>
                                                        <th>Match</th>
                                                        <th className="text-end">Team A</th>
                                                        <th className="text-center">Score</th>
                                                        <th>Team B</th>
                                                        <th className="text-end">Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {sectionMatches.map((match, index) => {
                                                        const isLastMatchOfRound =
                                                            index === sectionMatches.length - 1 ||
                                                            sectionMatches[index + 1]?.round?.id !== match.round?.id;
                                                        const byeTeam = isLastMatchOfRound
                                                            ? getSectionByeTeam(section, match.round, matches)
                                                            : null;

                                                        return (
                                                            <Fragment key={match.id}>
                                                                <tr>
                                                                    <td className="small">{match.round?.round_name || `Round ${match.round?.round_number || ""}`}</td>
                                                                    <td className="small">#{match.match_number}</td>
                                                                    <td className="text-end fw-semibold"><TeamDisplay team={match.teamA} /></td>
                                                                    <td className="text-center fw-bold">
                                                                        {match.completed ? (
                                                                            <div className="bowlpoint-result-display">
                                                                                <div className="bowlpoint-result-score">
                                                                                    {match.score_a} <span className="bowlpoint-result-separator">—</span> {match.score_b}
                                                                                </div>
                                                                                {competition?.scoring?.skins?.enabled && (
                                                                                    <div className="bowlpoint-result-skins">
                                                                                        <span>{match.skins_a ?? 0} {Number(match.skins_a ?? 0) === 1 ? "skin" : "skins"}</span>
                                                                                        <span className="bowlpoint-result-skins-separator">—</span>
                                                                                        <span>{match.skins_b ?? 0} {Number(match.skins_b ?? 0) === 1 ? "skin" : "skins"}</span>
                                                                                    </div>
                                                                                )}
                                                                            </div>
                                                                        ) : "vs"}
                                                                    </td>
                                                                    <td className="fw-semibold"><TeamDisplay team={match.teamB} /></td>
                                                                    <td className="text-end">
                                                                        <span className={`badge ${match.completed ? "bg-success" : match.team_a_id && match.team_b_id ? "bg-primary" : "bg-secondary"}`}>
                                                                            {match.completed ? "Final" : match.team_a_id && match.team_b_id ? "Scheduled" : "TBD"}
                                                                        </span>
                                                                    </td>
                                                                </tr>
                                                                {match.team_a_id && match.team_b_id && (
                                                                    <tr key={`rink-${match.id}`} className="bg-light">
                                                                        <td colSpan={6} className="small text-muted py-1">
                                                                            <i className="bi bi-geo-alt me-1"></i>
                                                                            {getMatchRinkLabel(match)}
                                                                        </td>
                                                                    </tr>
                                                                )}
                                                                {byeTeam && (
                                                                    <tr key={`bye-${section.id}-${match.round_id}`} className="table-warning">
                                                                        <td className="small">{match.round?.round_name || `Round ${match.round?.round_number || ""}`}</td>
                                                                        <td className="small">—</td>
                                                                        <td className="text-end fw-semibold"><TeamDisplay team={byeTeam} /></td>
                                                                        <td className="text-center fw-bold">—</td>
                                                                        <td className="fw-semibold">BYE</td>
                                                                        <td className="text-end"><span className="badge bg-warning text-dark">BYE</span></td>
                                                                    </tr>
                                                                )}
                                                            </Fragment>
                                                        );
                                                    })}
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                )}

                <div className="row g-3 mb-4">
                    <div className="col-12 col-lg-7">
                        <div className="card shadow-sm border-0 h-100">
                            <div className="card-header bg-white">
                                <h2 className="h5 mb-0"><i className="bi bi-clock-history me-2"></i>Recent Results</h2>
                            </div>
                            <div className="card-body p-0">
                                {recentResults.length === 0 ? (
                                    <div className="p-4 text-muted text-center">No results have been recorded yet.</div>
                                ) : (
                                    <div className="list-group list-group-flush">
                                        {recentResults.map(match => (
                                            <div className="list-group-item px-3 px-md-4" key={match.id}>
                                                <div className="row align-items-center g-2">
                                                    <div className="col-5 text-end fw-semibold"><TeamDisplay team={match.teamA} /></div>
                                                    <div className="col-2 text-center"><span className="badge bg-dark fs-6">{match.score_a} — {match.score_b}</span></div>
                                                    <div className="col-5 fw-semibold"><TeamDisplay team={match.teamB} /></div>
                                                </div>
                                                <div className="small text-muted text-center mt-1">{match.round?.round_name || `Round ${match.round?.round_number || ""}`}</div>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>

                    <div className="col-12 col-lg-5">
                        <div className="card shadow-sm border-0 h-100">
                            <div className="card-header bg-white">
                                <h2 className="h5 mb-0"><i className="bi bi-info-circle me-2"></i>Competition</h2>
                            </div>
                            <div className="card-body">
                                <div className="row g-3">
                                    <div className="col-6"><div className="small text-muted">Teams</div><div className="fs-5 fw-bold">{teams.length}</div></div>
                                    <div className="col-6"><div className="small text-muted">Matches</div><div className="fs-5 fw-bold">{matches.length}</div></div>
                                    <div className="col-6"><div className="small text-muted">Completed</div><div className="fs-5 fw-bold">{matches.filter(match => match.completed).length}</div></div>
                                    <div className="col-6"><div className="small text-muted">Remaining</div><div className="fs-5 fw-bold">{matches.filter(match => !match.completed).length}</div></div>
                                </div>
                                {lastUpdated && <div className="small text-muted mt-4">Updated {lastUpdated.toLocaleTimeString()}</div>}
                            </div>
                        </div>
                    </div>
                </div>

                {playoffRounds.length > 0 && (
                    <div className="card shadow-sm border-0 mb-4">
                        <div className="card-header bg-white">
                            <h2 className="h5 mb-0"><i className="bi bi-trophy me-2"></i>Playoffs</h2>
                        </div>
                        <div className="card-body">
                            <div className="row g-3">
                                {playoffRounds.map(round => (
                                    <div className="col-12 col-md-6 col-xl-4" key={round.id}>
                                        <div className="border rounded h-100 p-3">
                                            <div className="fw-bold mb-2">{round.round_name || `Round ${round.round_number}`}</div>
                                            {round.matches.length === 0 ? (
                                                <div className="small text-muted">No fixtures yet.</div>
                                            ) : round.matches.map(match => (
                                                <div className="border rounded p-2 mb-2" key={match.id}>
                                                    <div className="d-flex justify-content-between gap-2">
                                                        <span><TeamDisplay team={match.teamA} /></span>
                                                        <strong>{match.completed ? match.score_a : ""}</strong>
                                                    </div>
                                                    <div className="d-flex justify-content-between gap-2 mt-1">
                                                        <span><TeamDisplay team={match.teamB} /></span>
                                                        <strong>{match.completed ? match.score_b : ""}</strong>
                                                    </div>
                                                    <div className="small text-muted mt-1">
                                                        {match.completed ? "Completed" : match.team_a_id && match.team_b_id ? "Ready" : "Waiting for previous result"}
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                )}

                <div className="text-center text-muted small pb-3">
                    BowlPoint Live • Results update automatically while this page is open.
                </div>
            </div>
        </div>
    );
}

export default CompetitionLive;
