import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { supabase } from "../../lib/supabaseClient";
import { logAuditEvent } from "../../services/auditService";
import { getPlayerDisplayName } from "../../utils/playerDisplay";

function getSectionByeTeam(section, roundNumber) {
    const roundMatches = (section?.matches || []).filter(
        match => (match.round?.round_number || 0) === Number(roundNumber)
    );

    if (!roundMatches.length || !(section?.teams || []).length) return null;

    const playingTeamIds = new Set();
    roundMatches.forEach(match => {
        if (match.team_a_id) playingTeamIds.add(match.team_a_id);
        if (match.team_b_id) playingTeamIds.add(match.team_b_id);
    });

    return (section.teams || []).find(team => !playingTeamIds.has(team.competition_team_id || team.id)) || null;
}
import { generateCompetitionDrawProposal, createRoundRobinRounds, validateRoundRobin } from "./competitionDrawEngine";
import { buildOfficialLadiesDistrictPairsProposal } from "./officialLadiesDistrictPairs";
import { buildCompetitionScheduleProposal } from "./competitionScheduleEngine";
import CompetitionLiveCard from "./CompetitionLiveCard";
import { exportCompetitionFixturesPdf } from "../../lib/fixturesPdf";

function CompetitionWorkspace() {
    const { competitionId } = useParams();
    const navigate = useNavigate();

    const [competition, setCompetition] = useState(null);
    const [clubs, setClubs] = useState([]);
    const [participatingClubs, setParticipatingClubs] = useState([]);
    const [teams, setTeams] = useState([]);
    const [players, setPlayers] = useState([]);
    const [playingDays, setPlayingDays] = useState([]);
    const [rounds, setRounds] = useState([]);

    // Draw proposal state. This stage is deliberately local-only:
    // generating a proposal does NOT write sections, rounds or matches to Supabase.
    const [drawType, setDrawType] = useState("weekend");
    const [drawProposal, setDrawProposal] = useState(null);
    const [showDrawPlanner, setShowDrawPlanner] = useState(false);
    const [isEditingDrawProposal, setIsEditingDrawProposal] = useState(false);
    const [draggedProposalTeamId, setDraggedProposalTeamId] = useState("");
    const [proposalEditMessage, setProposalEditMessage] = useState("");
    const [generatingDraw, setGeneratingDraw] = useState(false);
    const [confirmingDraw, setConfirmingDraw] = useState(false);
    const [confirmedDraw, setConfirmedDraw] = useState(null);
    const [showSectionManager, setShowSectionManager] = useState(false);
    const [swapSectionA, setSwapSectionA] = useState("");
    const [swapSectionB, setSwapSectionB] = useState("");
    const [swapTeamA, setSwapTeamA] = useState("");
    const [swapTeamB, setSwapTeamB] = useState("");
    const [savingSectionSwap, setSavingSectionSwap] = useState(false);
    const [sectionEntryAction, setSectionEntryAction] = useState("swap");
    const [withdrawSectionId, setWithdrawSectionId] = useState("");
    const [withdrawTeamId, setWithdrawTeamId] = useState("");
    const [replacementSectionId, setReplacementSectionId] = useState("");
    const [replacementTeamId, setReplacementTeamId] = useState("");
    const [replacementPosition, setReplacementPosition] = useState("");
    const [replacementPlayerMode, setReplacementPlayerMode] = useState("existing");
    const [replacementPlayerId, setReplacementPlayerId] = useState("");
    const [replacementSearch, setReplacementSearch] = useState("");
    const [replacementNewPlayer, setReplacementNewPlayer] = useState({ first_name: "", last_name: "", nickname: "", bsa_number: "", club_id: "" });
    const [lateEntrySectionId, setLateEntrySectionId] = useState("");
    const [lateEntryClubId, setLateEntryClubId] = useState("");
    const [lateEntryPlayers, setLateEntryPlayers] = useState({});
    const [lateEntryPlayerModes, setLateEntryPlayerModes] = useState({});
    const [lateEntryNewPlayers, setLateEntryNewPlayers] = useState({});
    const [lateEntrySearch, setLateEntrySearch] = useState({});
    const [savingLateEntry, setSavingLateEntry] = useState(false);
    const [sectionManagerMessage, setSectionManagerMessage] = useState("");
    const [scheduleProposal, setScheduleProposal] = useState(null);
    const [scheduleAssignments, setScheduleAssignments] = useState([]);
    const [earlyStartEnabled, setEarlyStartEnabled] = useState(false);
    const [earlyStartSectionId, setEarlyStartSectionId] = useState("");
    const [sectionRoundDateOverrides, setSectionRoundDateOverrides] = useState([]);
    const [scorecardSummary, setScorecardSummary] = useState({ clubs: [], total: 0, unassigned: 0 });

    // Results / live scoring state.
    const [selectedMatch, setSelectedMatch] = useState(null);
    const [resultForm, setResultForm] = useState({ score_a: "", score_b: "", skins_a: "", skins_b: "" });
    const [savingResult, setSavingResult] = useState(false);
    const [resultSavedMessage, setResultSavedMessage] = useState("");
    const [savingSchedule, setSavingSchedule] = useState(false);

    // Progressive workspace navigation. The active stage is determined from the
    // persisted tournament state so the secretary lands where work is needed.
    const [showSetupDetails, setShowSetupDetails] = useState(false);
    const [collapsedScoringSections, setCollapsedScoringSections] = useState({});
    const scoringSectionRefs = useRef({});
    const pendingSectionToggleRef = useRef(null);
    const shouldScrollToTeamFormRef = useRef(false);
    const suppressNextWorkspaceStageScrollRef = useRef(false);

    // Remember the last club used for a team so adding several teams from the
    // same club is quicker. Persist per competition so it survives a reload.
    const lastUsedClubStorageKey = `bowlpoint:last-used-club:${competitionId}`;
    const [lastUsedClubId, setLastUsedClubId] = useState(() => {
        try {
            return localStorage.getItem(`bowlpoint:last-used-club:${competitionId}`) || "";
        } catch {
            return "";
        }
    });

    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    const [showClubForm, setShowClubForm] = useState(false);
    const [showTeamForm, setShowTeamForm] = useState(false);
    const [showDayForm, setShowDayForm] = useState(false);
    const [showRoundForm, setShowRoundForm] = useState(false);

    const [selectedClubIds, setSelectedClubIds] = useState([]);
    const [editingTeam, setEditingTeam] = useState(null);
    const [editingDay, setEditingDay] = useState(null);
    const [editingRound, setEditingRound] = useState(null);

    const [teamForm, setTeamForm] = useState({
        club_id: "",
        team_name: "",
        players: {}
    });

    // Player search text for each team position. Search matches BSA number
    // or player name within the selected club.
    const [playerSearch, setPlayerSearch] = useState({});

    const [dayForm, setDayForm] = useState({
        playing_date: "",
        name: "",
        venue_club_id: "",
        status: "scheduled"
    });

    const [roundForm, setRoundForm] = useState({
        competition_day_id: "",
        round_name: "",
        status: "pending"
    });

    /*
     * Positions for each competition format.
     */
    const getPositions = (format) => {
        const positions = {
            singles: [
                {
                    key: "player",
                    label: "Player",
                    order: 1
                }
            ],

            pairs: [
                {
                    key: "lead",
                    label: "Lead",
                    order: 1
                },
                {
                    key: "skip",
                    label: "Skip",
                    order: 2
                }
            ],

            trips: [
                {
                    key: "lead",
                    label: "Lead",
                    order: 1
                },
                {
                    key: "second",
                    label: "Second",
                    order: 2
                },
                {
                    key: "skip",
                    label: "Skip",
                    order: 3
                }
            ],

            fours: [
                {
                    key: "lead",
                    label: "Lead",
                    order: 1
                },
                {
                    key: "second",
                    label: "Second",
                    order: 2
                },
                {
                    key: "third",
                    label: "Third",
                    order: 3
                },
                {
                    key: "skip",
                    label: "Skip",
                    order: 4
                }
            ]
        };

        return positions[format] || positions.fours;
    };

    /*
     * Load all competition data.
     */
    const loadData = async () => {
        setLoading(true);

        const competitionResult = await supabase
            .from("competitions")
            .select("*")
            .eq("id", competitionId)
            .single();

        if (competitionResult.error) {
            console.error(
                "Error loading competition:",
                competitionResult.error
            );

            alert(
                `Unable to load competition.\n\n${competitionResult.error.message}`
            );

            setLoading(false);
            return;
        }

        const clubsResult = await supabase
            .from("clubs")
            .select("*")
            .eq("active", true)
            .order("name");

        if (clubsResult.error) {
            console.error(
                "Error loading clubs:",
                clubsResult.error
            );

            alert(
                `Unable to load clubs.\n\n${clubsResult.error.message}`
            );

            setLoading(false);
            return;
        }

        const participatingResult = await supabase
            .from("competition_clubs")
            .select(`
                id,
                club_id,
                clubs (
                    id,
                    name,
                    short_name,
                    active
                )
            `)
            .eq("competition_id", competitionId)
            .order("created_at");

        if (participatingResult.error) {
            console.error(
                "Error loading participating clubs:",
                participatingResult.error
            );

            alert(
                `Unable to load participating clubs.\n\n${participatingResult.error.message}`
            );

            setLoading(false);
            return;
        }

        const playersResult = await supabase
            .from("players")
            .select(`
                id,
                first_name,
                nickname,
                last_name,
                display_name,
                club_id,
                second_club_id,
                bsa_number,
                active
            `)
            .eq("active", true)
            .order("last_name")
            .order("first_name");

        if (playersResult.error) {
            console.error(
                "Error loading players:",
                playersResult.error
            );

            alert(
                `Unable to save team.\n\n${error?.message || "An unexpected error occurred."}`
            );

            setLoading(false);
            return;
        }

        const teamsResult = await supabase
            .from("competition_teams")
            .select(`
                id,
                competition_id,
                club_id,
                team_number,
                team_name,
                status,
                created_at,
                clubs (
                    id,
                    name,
                    short_name
                ),
                competition_team_players (
                    id,
                    player_id,
                    position,
                    position_order,
                    players (
                        id,
                        first_name,
                        nickname,
                        last_name,
                        display_name
                    )
                )
            `)
            .eq("competition_id", competitionId)
            .order("team_number");

        if (teamsResult.error) {
            console.error(
                "Error loading teams:",
                teamsResult.error
            );

            alert(
                `Unable to load teams.\n\n${teamsResult.error.message}`
            );

            setLoading(false);
            return;
        }

        const daysResult = await supabase
            .from("competition_days")
            .select(`
                id,
                competition_id,
                day_number,
                playing_date,
                name,
                status,
                venue_club_id,
                clubs (
                    id,
                    name,
                    short_name
                )
            `)
            .eq("competition_id", competitionId)
            .order("day_number");

        if (daysResult.error) {
            console.error(
                "Error loading playing days:",
                daysResult.error
            );

            alert(
                `Unable to load playing days.\n\n${daysResult.error.message}`
            );

            setLoading(false);
            return;
        }

        const roundsResult = await supabase
            .from("competition_rounds")
            .select(`
                id,
                competition_id,
                competition_day_id,
                round_number,
                round_name,
                status,
                competition_days (
                    id,
                    day_number,
                    playing_date,
                    name,
                    venue_club_id,
                    clubs (
                        id,
                        name,
                        short_name
                    )
                )
            `)
            .eq("competition_id", competitionId)
            .order("round_number");

        if (roundsResult.error) {
            console.error(
                "Error loading rounds:",
                roundsResult.error
            );

            alert(
                `Unable to load rounds.\n\n${roundsResult.error.message}`
            );

            setLoading(false);
            return;
        }

        const sectionsResult = await supabase
            .from("competition_sections")
            .select("id, competition_id, section_number, section_name")
            .eq("competition_id", competitionId)
            .order("section_number");

        if (sectionsResult.error) {
            console.error("Error loading draw sections:", sectionsResult.error);
            alert(`Unable to load draw sections.\n\n${sectionsResult.error.message}`);
            setLoading(false);
            return;
        }

        const sectionIds = (sectionsResult.data || []).map(s => s.id);
        const sectionTeamsResult = sectionIds.length
            ? await supabase.from("competition_section_teams").select(`
                id, section_id, competition_team_id,
                competition_teams (id, team_number, team_name, club_id, clubs (id, name, short_name))
              `).in("section_id", sectionIds)
            : { data: [], error: null };

        if (sectionTeamsResult.error) {
            console.error("Error loading section teams:", sectionTeamsResult.error);
            alert(`Unable to load section teams.\n\n${sectionTeamsResult.error.message}`);
            setLoading(false);
            return;
        }

        const matchesResult = await supabase
            .from("competition_matches")
            .select("id, competition_id, round_id, section_id, match_number, team_a_id, team_b_id, score_a, score_b, skins_a, skins_b, completed, next_match_id, next_match_slot")
            .eq("competition_id", competitionId);

        const sectionRoundDatesResult = await supabase
            .from("competition_section_round_dates")
            .select("section_id, round_id, playing_date")
            .eq("competition_id", competitionId);

        if (sectionRoundDatesResult.error) {
            console.error("Error loading section-specific round dates:", sectionRoundDatesResult.error);
            alert(`Unable to load section-specific round dates.\n\n${sectionRoundDatesResult.error.message}`);
            setLoading(false);
            return;
        }
        setSectionRoundDateOverrides(sectionRoundDatesResult.data || []);
        setEarlyStartEnabled((sectionRoundDatesResult.data || []).length > 0);
        setEarlyStartSectionId((sectionRoundDatesResult.data || [])[0]?.section_id || "");

        const sectionVenuesResult = await supabase
            .from("competition_section_venues")
            .select("section_id, club_id")
            .eq("competition_id", competitionId);

        if (sectionVenuesResult.error) {
            console.error("Error loading section host clubs for scorecard totals:", sectionVenuesResult.error);
        }

        if (matchesResult.error) {
            console.error("Error loading draw matches:", matchesResult.error);
            alert(`Unable to load draw matches.\n\n${matchesResult.error.message}`);
            setLoading(false);
            return;
        }

        const teamById = new Map((teamsResult.data || []).map(team => [team.id, team]));
        const roundById = new Map((roundsResult.data || []).map(round => [round.id, round]));
        const persistedSections = sectionsResult.data || [];
        const persistedMatches = matchesResult.data || [];

        // One scorecard is required per fixture. Sectional fixtures use the
        // saved section host; playoff fixtures fall back to the saved day venue.
        const sectionVenueById = new Map(
            (sectionVenuesResult.data || []).map(row => [row.section_id, row.club_id])
        );
        const scorecardsByClub = new Map();
        let unassignedScorecards = 0;
        persistedMatches.forEach(match => {
            if (!match.team_a_id || !match.team_b_id ||
                !teamById.has(match.team_a_id) || !teamById.has(match.team_b_id)) return;

            const round = roundById.get(match.round_id);
            const day = round?.competition_days;
            const hostClubId = match.section_id
                ? sectionVenueById.get(match.section_id)
                : day?.venue_club_id;

            if (!hostClubId) {
                unassignedScorecards += 1;
                return;
            }

            const club = (clubsResult.data || []).find(item => item.id === hostClubId);
            const clubName = club?.name || day?.clubs?.name || "Unknown host club";
            const existing = scorecardsByClub.get(hostClubId) || { clubId: hostClubId, clubName, count: 0 };
            existing.count += 1;
            scorecardsByClub.set(hostClubId, existing);
        });
        const scorecardClubRows = [...scorecardsByClub.values()].sort((a, b) => a.clubName.localeCompare(b.clubName));
        setScorecardSummary({
            clubs: scorecardClubRows,
            total: scorecardClubRows.reduce((sum, row) => sum + row.count, 0),
            unassigned: unassignedScorecards
        });

        setConfirmedDraw(persistedSections.length ? {
            sections: persistedSections.map(section => ({
                ...section,
                allTeams: (sectionTeamsResult.data || [])
                    .filter(row => row.section_id === section.id)
                    .map(row => {
                        const sectionTeam = row.competition_teams;
                        const fullTeam = teamById.get(row.competition_team_id);
                        return fullTeam ? {
                            ...fullTeam,
                            ...(sectionTeam || {}),
                            id: fullTeam.id,
                            competition_team_id: row.competition_team_id,
                            section_id: row.section_id,
                            section_team_id: row.id,
                            competition_team_players: fullTeam.competition_team_players || []
                        } : sectionTeam ? {
                            ...sectionTeam,
                            competition_team_id: row.competition_team_id,
                            section_id: row.section_id,
                            section_team_id: row.id
                        } : null;
                    })
                    .filter(Boolean),
                teams: (sectionTeamsResult.data || [])
                    .filter(row => row.section_id === section.id)
                    .map(row => {
                        const sectionTeam = row.competition_teams;
                        const fullTeam = teamById.get(row.competition_team_id);

                        // The section-team query only needs lightweight team data,
                        // so merge it with the fully-loaded competition team. This
                        // preserves competition_team_players for display-name
                        // fallbacks in standings and other section views.
                        if (fullTeam) {
                            return {
                                ...fullTeam,
                                ...(sectionTeam || {}),
                                // Keep the join-table row identity separately from
                                // the competition team ID. Section membership edits
                                // must target competition_section_teams.id, not
                                // competition_teams.id.
                                id: fullTeam.id,
                                competition_team_id: row.competition_team_id,
                                section_id: row.section_id,
                                section_team_id: row.id,
                                competition_team_players: fullTeam.competition_team_players || []
                            };
                        }

                        return sectionTeam ? {
                            ...sectionTeam,
                            competition_team_id: row.competition_team_id,
                            section_id: row.section_id,
                            section_team_id: row.id
                        } : null;
                    })
                    .filter(Boolean)
                    .filter(entry => (entry.status || "active") !== "withdrawn"),
                matches: persistedMatches
                    .filter(match => match.section_id === section.id)
                    .map(match => ({ ...match, round: roundById.get(match.round_id), teamA: teamById.get(match.team_a_id), teamB: teamById.get(match.team_b_id) }))
            })),
            rounds: roundsResult.data || [],
            matches: persistedMatches.map(match => ({ ...match, round: roundById.get(match.round_id), teamA: teamById.get(match.team_a_id), teamB: teamById.get(match.team_b_id) }))
        } : null);

        setCompetition(competitionResult.data);
        setDrawType(competitionResult.data.schedule_type || "weekend");
        setClubs(clubsResult.data || []);
        setParticipatingClubs(participatingResult.data || []);
        setPlayers(playersResult.data || []);
        setTeams(teamsResult.data || []);
        setPlayingDays(daysResult.data || []);
        setRounds(roundsResult.data || []);

        setLoading(false);
    };

    useEffect(() => {
        loadData();
    }, [competitionId]);

    const scheduleAssigned = Boolean(
        confirmedDraw?.rounds?.length &&
        confirmedDraw.rounds.every(round => round.competition_day_id)
    );

    // Rink allocation must only open when the current date assignments have
    // actually been persisted. This also catches edits made after a previous save.
    const scheduleSaved = Boolean(
        scheduleAssigned &&
        scheduleProposal?.days?.length &&
        scheduleAssignments.length === scheduleProposal.days.length &&
        scheduleAssignments.every(assignment => {
            const savedDay = playingDays.find(day => day.day_number === assignment.dayNumber);
            return Boolean(
                savedDay?.id &&
                assignment.existing_id === savedDay.id &&
                assignment.playing_date &&
                assignment.playing_date === savedDay.playing_date &&
                (assignment.name?.trim() || assignment.label) === (savedDay.name?.trim() || assignment.label)
            );
        })
    );

    // A round is sectional when its fixtures belong to a section.
    // Do not infer this from the round number: a single 5-team round robin
    // legitimately has 5 sectional rounds, so rounds 4 and 5 are still
    // sectional and must not be treated as playoffs.
    const sectionalMatches = confirmedDraw?.matches?.filter(match =>
        match.section_id !== null && match.section_id !== undefined
    ) || [];

    const playoffMatches = confirmedDraw?.matches?.filter(match =>
        match.section_id === null || match.section_id === undefined
    ) || [];

    const sectionalComplete = Boolean(
        confirmedDraw?.sections?.length &&
        confirmedDraw.sections.every(section => {
            const matches = sectionalMatches.filter(match => match.section_id === section.id);
            return matches.length > 0 && matches.every(match => match.completed);
        })
    );

    const workspaceStage = !confirmedDraw
        ? (teams.filter(team => team.status === "active").length >= 3 ? "draw" : "teams")
        : !scheduleAssigned
            ? "schedule"
            : sectionalComplete
                ? (playoffMatches.length > 0 ? "playoffs" : "scoring")
                : "scoring";

    const workspaceStageInfo = {
        teams: { label: "Teams", icon: "bi-people-fill", target: "workspace-teams" },
        draw: { label: "Draw", icon: "bi-diagram-3", target: confirmedDraw ? "workspace-draw-confirmed" : "workspace-draw-planner" },
        schedule: { label: "Schedule", icon: "bi-calendar3", target: "workspace-schedule" },
        scoring: { label: "Scoring", icon: "bi-pencil-square", target: "workspace-results" },
        playoffs: { label: "Playoffs", icon: "bi-trophy", target: "workspace-results" }
    };

    const focusWorkspaceStage = (stage) => {
        const info = workspaceStageInfo[stage];
        if (!info) return;
        const element = document.getElementById(info.target);
        if (element) {
            element.scrollIntoView({ behavior: "smooth", block: "start" });
        }
    };

    useEffect(() => {
        if (loading || !competition) return;

        // A successful team save has its own explicit scroll target. Skip this
        // progressive-stage scroll once so that adding the 3rd team does not
        // immediately move the user to the Draw section.
        if (suppressNextWorkspaceStageScrollRef.current) {
            suppressNextWorkspaceStageScrollRef.current = false;
            return;
        }

        // While the competition is still in the setup/draw phase, land the
        // secretary on the Competition Teams section first. This is more
        // useful than jumping straight to the Draw Planner because teams are
        // still the main thing that needs to be reviewed/added. Once a draw
        // has been confirmed, continue using the normal progressive stage
        // navigation.
        const initialStage = !confirmedDraw ? "teams" : workspaceStage;
        const timer = setTimeout(() => focusWorkspaceStage(initialStage), 120);
    return () => clearTimeout(timer);
    }, [loading, competition, confirmedDraw, workspaceStage]);

    useEffect(() => {
        if (!showTeamForm || !shouldScrollToTeamFormRef.current) return;

        // Wait for the Add Team form to be rendered before scrolling.
        // Scroll to the top of the Competition Teams card rather than the
        // form itself. The form is tall, and scrolling to its DOM position
        // can leave the viewport down at the Players section. The Teams card
        // has the correct scroll offset for the sticky progress header and
        // brings the Club / Team Name fields into view first.
        const timer = setTimeout(() => {
            const element = document.getElementById("workspace-teams");
            if (element) {
                element.scrollIntoView({ behavior: "smooth", block: "start" });
            }
            shouldScrollToTeamFormRef.current = false;
        }, 80);

        return () => clearTimeout(timer);
    }, [showTeamForm, editingTeam]);

    useEffect(() => {
        // Automatically roll up a section once all of its sectional games are
        // complete, but only when the user has not manually chosen a state.
        // Leaving incomplete sections undefined is important: it means the
        // render below can derive their open/closed state from `complete`, so
        // the final saved result immediately causes an untouched section to
        // collapse without overwriting a user's manual expand/collapse choice.
        if (!confirmedDraw?.sections?.length) return;

        setCollapsedScoringSections(prev => {
            const next = { ...prev };
            let changed = false;

            confirmedDraw.sections.forEach(section => {
                if (next[section.id] !== undefined) return;

                const matches = sectionalMatches.filter(match => match.section_id === section.id);
                const complete = matches.length > 0 && matches.every(match => match.completed);

                if (complete) {
                    next[section.id] = true;
                    changed = true;
                }
            });

            return changed ? next : prev;
        });
    }, [confirmedDraw, sectionalMatches.length]);

    // Preserve the exact viewport position when a scoring accordion changes
    // height. Browser scroll anchoring can otherwise jump to the bottom/top
    // of the card when its table is inserted or removed.
    useLayoutEffect(() => {
        const pending = pendingSectionToggleRef.current;
        if (!pending) return;

        const element = scoringSectionRefs.current[pending.sectionId];
        if (!element) {
            pendingSectionToggleRef.current = null;
            return;
        }

        const afterTop = element.getBoundingClientRect().top;
        const delta = afterTop - pending.beforeTop;
        if (Math.abs(delta) > 0.5) {
            window.scrollBy(0, delta);
        }
        pendingSectionToggleRef.current = null;
    }, [collapsedScoringSections]);

    const toggleScoringSection = (sectionId) => {
        const element = scoringSectionRefs.current[sectionId];
        pendingSectionToggleRef.current = {
            sectionId,
            beforeTop: element?.getBoundingClientRect().top ?? 0
        };
        setCollapsedScoringSections(prev => ({
            ...prev,
            [sectionId]: !prev[sectionId]
        }));
    };

    useEffect(() => {
        if (!confirmedDraw?.rounds?.length) {
            setScheduleProposal(null);
            return;
        }

        try {
            setScheduleProposal(
                buildCompetitionScheduleProposal({
                    competitionType: competition?.schedule_type || drawType,
                    rounds: confirmedDraw.rounds,
                    matches: confirmedDraw.matches || []
                })
            );
        } catch (error) {
            console.error("Error building schedule proposal:", error);
            setScheduleProposal(null);
        }
    }, [confirmedDraw, drawType, competition?.schedule_type]);

    const weekdaySectionSizes = (confirmedDraw?.sections || [])
        .map(section => ({ ...section, teamCount: (section.teams || section.allTeams || []).length }))
        .filter(section => section.teamCount > 0);
    const hasUnequalWeekdaySections = new Set(weekdaySectionSizes.map(section => section.teamCount)).size > 1;
    const largestWeekdaySections = weekdaySectionSizes.filter(section =>
        section.teamCount === Math.max(0, ...weekdaySectionSizes.map(item => item.teamCount))
    );
    const earlyStartDate = scheduleAssignments[0]?.playing_date
        ? (() => { const date = new Date(`${scheduleAssignments[0].playing_date}T12:00:00`); date.setDate(date.getDate() - 1); return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${String(date.getDate()).padStart(2,"0")}`; })()
        : "";

    useEffect(() => {
        if (!scheduleProposal?.days?.length) {
            setScheduleAssignments([]);
            return;
        }

        const assignments = scheduleProposal.days.map((day, index) => {
            const existing = playingDays.find(item => item.day_number === index + 1);

            return {
                key: day.key,
                dayNumber: index + 1,
                label: (scheduleProposal.competitionType === "weekend" && existing?.playing_date)
                    ? `${(day.label.match(/^Weekend\\s+\\d+/i) || [])[0] || day.label} — ${new Date(`${existing.playing_date}T12:00:00`).toLocaleDateString("en-ZA", { weekday: "long" })}`
                    : day.label,
                typeLabel: day.typeLabel,
                playing_date: existing?.playing_date || "",
                name: existing?.name || (
                    scheduleProposal.competitionType === "weekend" && existing?.playing_date
                        ? `${(day.label.match(/^Weekend\\s+\\d+/i) || [])[0] || day.label} — ${new Date(`${existing.playing_date}T12:00:00`).toLocaleDateString("en-ZA", { weekday: "long" })}`
                        : day.label
                ),
                venue_club_id: existing?.venue_club_id || "",
                status: existing?.status || "scheduled",
                existing_id: existing?.id || null
            };
        });

        setScheduleAssignments(assignments);
    }, [scheduleProposal, playingDays]);

    const handleScheduleAssignmentChange = (index, field, value) => {
        setScheduleAssignments(prev => prev.map((assignment, itemIndex) => {
            if (itemIndex !== index) return assignment;

            // For weekend competitions, the proposed Saturday/Sunday label is
            // only a suggestion. The secretary may choose either weekend day.
            // Keep the visible/session name in sync when the date changes,
            // without overwriting a custom name entered by the secretary.
            if (field === "playing_date" && scheduleProposal?.competitionType === "weekend") {
                const selectedDate = value ? new Date(`${value}T12:00:00`) : null;
                const selectedDay = selectedDate
                    ? selectedDate.toLocaleDateString("en-ZA", { weekday: "long" })
                    : "";
                const previousDefaultName = assignment.label;
                const hasDefaultWeekendName = /^Weekend\\s+\\d+\\s+—\\s+(Saturday|Sunday)$/i.test(assignment.name || "");
                const weekendPrefix = (assignment.label.match(/^Weekend\\s+\\d+/i) || [])[0]
                    || (assignment.name.match(/^Weekend\\s+\\d+/i) || [])[0]
                    || "Weekend";

                const nextLabel = selectedDay
                    ? `${weekendPrefix} — ${selectedDay}`
                    : assignment.label;

                return {
                    ...assignment,
                    playing_date: value,
                    label: nextLabel,
                    name: (assignment.name === previousDefaultName || hasDefaultWeekendName)
                        ? nextLabel
                        : assignment.name
                };
            }

            return { ...assignment, [field]: value };
        }));
    };

    const isValidScheduleDate = (dateValue, dayLabel, competitionType) => {
        if (!dateValue) return false;

        const date = new Date(`${dateValue}T12:00:00`);
        const dayOfWeek = date.getDay();

        if (competitionType === "weekend") {
            // Any Saturday or Sunday is valid for every weekend session,
            // including playoff sessions.
            return dayOfWeek === 6 || dayOfWeek === 0;
        }

        return dayOfWeek !== 0 && dayOfWeek !== 6;
    };

    const handleSaveSchedule = async () => {
        if (!scheduleProposal?.days?.length) {
            alert("There is no schedule proposal to assign.");
            return;
        }

        const competitionType = scheduleProposal.competitionType;

        if (competitionType === "week" && earlyStartEnabled && !earlyStartSectionId) {
            alert("Please select the section that must start early.");
            return;
        }

        for (const assignment of scheduleAssignments) {
            if (!assignment.playing_date) {
                alert(`Please select a date for ${assignment.label}.`);
                return;
            }

            if (!isValidScheduleDate(assignment.playing_date, assignment.label, competitionType)) {
                if (competitionType === "weekend") {
                    alert(`${assignment.label} must be scheduled on a Saturday or Sunday.`);
                } else {
                    alert(`${assignment.label} must be scheduled on a weekday.`);
                }
                return;
            }
        }

        const dates = scheduleAssignments.map(assignment => assignment.playing_date);
        if (new Set(dates).size !== dates.length) {
            alert("Each tournament playing day must have a different date.");
            return;
        }

        const confirmed = window.confirm(
            `Save this tournament schedule?\n\n` +
            `${scheduleAssignments.length} playing day(s) will be created or updated, and the confirmed rounds will be assigned to those days.\n\n` +
            `Your confirmed draw and fixtures will not be changed.`
        );

        if (!confirmed) return;

        setSavingSchedule(true);

        try {
            const savedDays = [];

            for (const assignment of scheduleAssignments) {
                const payload = {
                    competition_id: competitionId,
                    day_number: assignment.dayNumber,
                    playing_date: assignment.playing_date,
                    name: assignment.name?.trim() || assignment.label,
                    // Venue is intentionally left unset here. The rink allocator
                    // assigns a host club per match after checking shared capacity.
                    venue_club_id: null,
                    status: assignment.status || "scheduled",
                    updated_at: new Date().toISOString()
                };

                let result;

                if (assignment.existing_id) {
                    result = await supabase
                        .from("competition_days")
                        .update(payload)
                        .eq("id", assignment.existing_id)
                        .select(`
                            id,
                            competition_id,
                            day_number,
                            playing_date,
                            name,
                            status,
                            venue_club_id,
                            clubs (id, name, short_name)
                        `)
                        .single();
                } else {
                    result = await supabase
                        .from("competition_days")
                        .insert(payload)
                        .select(`
                            id,
                            competition_id,
                            day_number,
                            playing_date,
                            name,
                            status,
                            venue_club_id,
                            clubs (id, name, short_name)
                        `)
                        .single();
                }

                if (result.error) throw result.error;
                savedDays.push(result.data);
            }

            const dayByRoundNumber = new Map();
            scheduleProposal.days.forEach((day, index) => {
                const savedDay = savedDays[index];
                day.rounds.forEach(round => {
                    dayByRoundNumber.set(round.roundNumber, savedDay.id);
                });
            });

            for (const round of confirmedDraw.rounds) {
                const competitionDayId = dayByRoundNumber.get(round.round_number);

                if (!competitionDayId) {
                    throw new Error(`No playing day was assigned to Round ${round.round_number}.`);
                }

                const { error } = await supabase
                    .from("competition_rounds")
                    .update({
                        competition_day_id: competitionDayId,
                        updated_at: new Date().toISOString()
                    })
                    .eq("id", round.id);

                if (error) throw error;
            }

            // A weekday early start is stored at section + round level. Only
            // Round 1 of the selected larger section is moved to the preceding Monday.
            if (competitionType === "week" && earlyStartEnabled && earlyStartSectionId) {
                const firstRound = confirmedDraw.rounds.find(round => Number(round.round_number) === 1);
                if (!firstRound || !earlyStartDate) throw new Error("The early-start section needs a valid first playing date and Round 1.");
                const monday = new Date(`${earlyStartDate}T12:00:00`).getDay() === 1;
                if (!monday) throw new Error("The early-start date must be a Monday. Set the first normal playing date to Tuesday or later.");
                const { error: overrideError } = await supabase
                    .from("competition_section_round_dates")
                    .upsert({
                        competition_id: competitionId,
                        section_id: earlyStartSectionId,
                        round_id: firstRound.id,
                        playing_date: earlyStartDate,
                        updated_at: new Date().toISOString()
                    }, { onConflict: "competition_id,section_id,round_id" });
                if (overrideError) throw overrideError;
            } else {
                const { error: clearOverrideError } = await supabase
                    .from("competition_section_round_dates")
                    .delete()
                    .eq("competition_id", competitionId);
                if (clearOverrideError) throw clearOverrideError;
            }

            alert("Schedule saved successfully. The confirmed rounds are now assigned to the selected dates and venues.");
            await loadData();
        } catch (error) {
            console.error("Error saving tournament schedule:", error);
            alert(`Unable to save tournament schedule.\\n\\n${error.message}`);
        } finally {
            setSavingSchedule(false);
        }
    };

    /*
     * Open a match for result entry.
     */
    const openResultEditor = (match) => {
        if (!match.team_a_id || !match.team_b_id) {
            alert("This fixture is waiting for the teams to be determined.");
            return;
        }

        setSelectedMatch(match);
        setResultForm({
            score_a: match.score_a ?? "",
            score_b: match.score_b ?? "",
            skins_a: match.skins_a ?? "",
            skins_b: match.skins_b ?? ""
        });
    };

    const closeResultEditor = () => {
        if (savingResult) return;
        setSelectedMatch(null);
        setResultForm({ score_a: "", score_b: "", skins_a: "", skins_b: "" });
    };

    const getMatchTeamName = (match, side) => {
        const teamId = side === "a" ? match?.team_a_id : match?.team_b_id;
        if (!teamId) return "TBD";
        const team = teams.find(item => item.id === teamId);
        return getTeamDisplayName(team);
    };

    const getSectionWinner = (sectionId, matchesOverride = null) => {
        const section = confirmedDraw?.sections?.find(item => item.id === sectionId);
        if (!section) return null;

        const sectionMatches = (matchesOverride || confirmedDraw.matches || [])
            .filter(match => match.section_id === sectionId);

        const sectionTeamIds = new Set((section.teams || []).map(team => team.id));
        const expectedMatches = ((section.teams || []).length * ((section.teams || []).length - 1)) / 2;
        if (!sectionMatches.length || sectionMatches.length !== expectedMatches || sectionMatches.some(match =>
            !match.completed || !match.team_a_id || !match.team_b_id ||
            !sectionTeamIds.has(match.team_a_id) || !sectionTeamIds.has(match.team_b_id)
        )) {
            return null;
        }

        const standings = section.teams.map(team => {
            const row = {
                teamId: team.id,
                team,
                played: 0,
                wins: 0,
                draws: 0,
                losses: 0,
                skinsWon: 0,
                points: 0,
                shotsFor: 0,
                shotsAgainst: 0,
                aggregate: 0
            };

            sectionMatches.forEach(match => {
                if (match.team_a_id !== team.id && match.team_b_id !== team.id) return;
                const isA = match.team_a_id === team.id;
                const sf = Number(isA ? match.score_a : match.score_b);
                const sa = Number(isA ? match.score_b : match.score_a);
                row.played += 1;
                row.shotsFor += sf;
                row.shotsAgainst += sa;
                if (competition.scoring?.skins?.enabled) {
                    row.skinsWon += Number(isA ? match.skins_a : match.skins_b) || 0;
                }
                if (sf > sa) {
                    row.wins += 1;
                    row.points += Number(competition.scoring?.win ?? 2);
                } else if (sf === sa) {
                    row.draws += 1;
                    row.points += Number(competition.scoring?.draw ?? 1);
                } else {
                    row.losses += 1;
                }

                if (competition.scoring?.skins?.enabled) {
                    const skinCount = Number(isA ? match.skins_a : match.skins_b) || 0;
                    row.points += skinCount * Number(competition.scoring?.skins?.pointsPerSkin ?? 1);
                }
            });

            row.aggregate = row.shotsFor - row.shotsAgainst;
            return row;
        }).sort((a, b) =>
            b.points - a.points ||
            b.aggregate - a.aggregate ||
            b.shotsFor - a.shotsFor ||
            a.team.team_number - b.team.team_number
        );

        if (!standings.length || standings.some(row => row.played !== section.teams.length - 1)) return null;
        return standings[0] || null;
    };

    const getSectionStandings = (sectionId) => {
        const section = confirmedDraw?.sections?.find(item => item.id === sectionId);
        if (!section) return [];
        const sectionMatches = (confirmedDraw.matches || []).filter(match => match.section_id === sectionId);

        return section.teams.map(team => {
            const row = {
                teamId: team.id,
                team,
                played: 0,
                wins: 0,
                draws: 0,
                losses: 0,
                skinsWon: 0,
                points: 0,
                shotsFor: 0,
                shotsAgainst: 0,
                aggregate: 0
            };

            sectionMatches.forEach(match => {
                if (!match.completed || (match.team_a_id !== team.id && match.team_b_id !== team.id)) return;
                const isA = match.team_a_id === team.id;
                const sf = Number(isA ? match.score_a : match.score_b);
                const sa = Number(isA ? match.score_b : match.score_a);
                row.played += 1;
                row.shotsFor += sf;
                row.shotsAgainst += sa;
                if (competition.scoring?.skins?.enabled) {
                    row.skinsWon += Number(isA ? match.skins_a : match.skins_b) || 0;
                }
                if (sf > sa) {
                    row.wins += 1;
                    row.points += Number(competition.scoring?.win ?? 2);
                } else if (sf === sa) {
                    row.draws += 1;
                    row.points += Number(competition.scoring?.draw ?? 1);
                } else {
                    row.losses += 1;
                }

                if (competition.scoring?.skins?.enabled) {
                    const skinCount = Number(isA ? match.skins_a : match.skins_b) || 0;
                    row.points += skinCount * Number(competition.scoring?.skins?.pointsPerSkin ?? 1);
                }
            });

            row.aggregate = row.shotsFor - row.shotsAgainst;
            return row;
        }).sort((a, b) =>
            b.points - a.points ||
            b.aggregate - a.aggregate ||
            b.shotsFor - a.shotsFor ||
            a.team.team_number - b.team.team_number
        );
    };

    const isSectionComplete = (section) => {
        const sectionTeams = section?.teams || [];
        if (sectionTeams.length < 2) return false;
        const teamIds = new Set(sectionTeams.map(team => team.id));
        const sectionMatches = (confirmedDraw?.matches || []).filter(match => match.section_id === section.id);
        const expectedMatches = (sectionTeams.length * (sectionTeams.length - 1)) / 2;
        if (sectionMatches.length !== expectedMatches || sectionMatches.some(match =>
            !match.completed || !match.team_a_id || !match.team_b_id ||
            !teamIds.has(match.team_a_id) || !teamIds.has(match.team_b_id)
        )) return false;
        const standings = getSectionStandings(section.id);
        return standings.length === sectionTeams.length &&
            standings.every(row => row.played === sectionTeams.length - 1);
    };

    // Backfill completed section winners into the first applicable playoff round.
    // Eight sections feed quarter-finals; four sections feed semi-finals;
    // two sections feed the final. Only empty slots are filled automatically.
    const playoffSyncInFlight = useRef(false);
    useEffect(() => {
        if (!confirmedDraw?.sections?.length || playoffSyncInFlight.current) return;
        const sectionCount = confirmedDraw.sections.length;
        let targetRound = null;
        let slotMap = {};

        if (sectionCount === 8) {
            targetRound = confirmedDraw.rounds?.find(round => /quarter[ -]?final/i.test(round.round_name || ""));
            slotMap = {
                1: [1, "team_a_id"], 3: [1, "team_b_id"],
                2: [2, "team_a_id"], 4: [2, "team_b_id"],
                5: [3, "team_a_id"], 7: [3, "team_b_id"],
                6: [4, "team_a_id"], 8: [4, "team_b_id"]
            };
        } else if (sectionCount === 4) {
            targetRound = confirmedDraw.rounds?.find(round => /semi[ -]?final/i.test(round.round_name || ""));
            slotMap = {
                1: [1, "team_a_id"], 3: [1, "team_b_id"],
                2: [2, "team_a_id"], 4: [2, "team_b_id"]
            };
        } else if (sectionCount === 2) {
            targetRound = confirmedDraw.rounds?.find(round => /^final$/i.test((round.round_name || "").trim()));
            slotMap = { 1: [1, "team_a_id"], 2: [1, "team_b_id"] };
        }

        if (!targetRound) return;
        const updates = [];
        for (const section of confirmedDraw.sections) {
            const mapping = slotMap[section.section_number];
            if (!mapping || !isSectionComplete(section)) continue;
            const winner = getSectionWinner(section.id);
            if (!winner) continue;
            const [matchNumber, field] = mapping;
            const target = confirmedDraw.matches.find(match =>
                match.round_id === targetRound.id && match.match_number === matchNumber
            );
            if (target && !target[field]) updates.push({ id: target.id, field, teamId: winner.teamId });
        }
        if (!updates.length) return;
        playoffSyncInFlight.current = true;
        (async () => {
            try {
                for (const update of updates) {
                    const { error } = await supabase.from("competition_matches")
                        .update({ [update.field]: update.teamId })
                        .eq("id", update.id)
                        .is(update.field, null);
                    if (error) throw error;
                }
                await loadData();
            } catch (error) {
                console.error("Unable to backfill section winners into playoffs:", error);
            } finally {
                playoffSyncInFlight.current = false;
            }
        })();
    }, [confirmedDraw]);

    const advanceWinner = async (matchId, winnerTeamId) => {
        const source = (confirmedDraw?.matches || []).find(match => match.id === matchId);
        if (!source?.next_match_id) return;

        const target = (confirmedDraw?.matches || []).find(match => match.id === source.next_match_id);
        if (!target) return;

        const field = source.next_match_slot === "B" ? "team_b_id" : "team_a_id";
        const { error } = await supabase
            .from("competition_matches")
            .update({ [field]: winnerTeamId })
            .eq("id", target.id);

        if (error) throw error;
    };

    const populateSectionWinner = async (sectionId, matchesAfterSave) => {
        const winner = getSectionWinner(sectionId, matchesAfterSave);
        if (!winner) return;

        const sectionNumber = confirmedDraw?.sections?.find(section => section.id === sectionId)?.section_number;
        const sectionCount = confirmedDraw?.sections?.length || 0;
        if (!sectionNumber) return;

        let targetRoundPattern = null;
        let slotMap = {};
        if (sectionCount === 8) {
            targetRoundPattern = /quarter[ -]?final/i;
            slotMap = {
                1: { matchNumber: 1, field: "team_a_id" },
                3: { matchNumber: 1, field: "team_b_id" },
                2: { matchNumber: 2, field: "team_a_id" },
                4: { matchNumber: 2, field: "team_b_id" },
                5: { matchNumber: 3, field: "team_a_id" },
                7: { matchNumber: 3, field: "team_b_id" },
                6: { matchNumber: 4, field: "team_a_id" },
                8: { matchNumber: 4, field: "team_b_id" }
            };
        } else if (sectionCount === 4) {
            targetRoundPattern = /semi[ -]?final/i;
            slotMap = {
                1: { matchNumber: 1, field: "team_a_id" },
                3: { matchNumber: 1, field: "team_b_id" },
                2: { matchNumber: 2, field: "team_a_id" },
                4: { matchNumber: 2, field: "team_b_id" }
            };
        } else if (sectionCount === 2) {
            targetRoundPattern = /^final$/i;
            slotMap = {
                1: { matchNumber: 1, field: "team_a_id" },
                2: { matchNumber: 1, field: "team_b_id" }
            };
        }

        const slot = slotMap[sectionNumber];
        if (!slot || !targetRoundPattern) return;
        const targetRound = confirmedDraw.rounds.find(round =>
            targetRoundPattern.test((round.round_name || "").trim())
        );
        if (!targetRound) return;

        const targetMatch = (matchesAfterSave || confirmedDraw.matches || []).find(match =>
            match.round_id === targetRound.id && match.match_number === slot.matchNumber
        );
        if (!targetMatch) return;

        // Do not overwrite an already populated slot; this avoids replacing a
        // manually corrected or previously advanced team.
        const existingTeamId = targetMatch[slot.field];
        if (existingTeamId && existingTeamId !== winner.teamId) {
            console.warn("Playoff slot already contains a different team; leaving it unchanged.", {
                sectionNumber, matchNumber: slot.matchNumber, field: slot.field,
                existingTeamId, winnerTeamId: winner.teamId
            });
            return;
        }
        if (existingTeamId === winner.teamId) return;

        const { error } = await supabase
            .from("competition_matches")
            .update({ [slot.field]: winner.teamId })
            .eq("id", targetMatch.id)
            .is(slot.field, null);
        if (error) throw error;
    };


    const handleSaveResult = async (event) => {
        event.preventDefault();
        if (!selectedMatch) return;

        const scoreA = Number(resultForm.score_a);
        const scoreB = Number(resultForm.score_b);
        const skinsA = competition?.scoring?.skins?.enabled ? Number(resultForm.skins_a) : null;
        const skinsB = competition?.scoring?.skins?.enabled ? Number(resultForm.skins_b) : null;

        if (!Number.isInteger(scoreA) || !Number.isInteger(scoreB) || scoreA < 0 || scoreB < 0) {
            alert("Please enter valid non-negative whole-number scores for both teams.");
            return;
        }

        if (competition?.scoring?.skins?.enabled &&
            (!Number.isInteger(skinsA) || !Number.isInteger(skinsB) || skinsA < 0 || skinsB < 0)) {
            alert("Please enter valid non-negative whole-number skin scores for both teams.");
            return;
        }

        setSavingResult(true);

        try {
            const selectedRound = confirmedDraw.rounds.find(round => round.id === selectedMatch.round_id);
            const isPlayoff = Boolean(selectedRound && !selectedRound.round_name?.toLowerCase().includes("sectional"));

            if (isPlayoff && scoreA === scoreB) {
                alert("Playoff matches cannot finish level. Enter a result with a winning team.");
                setSavingResult(false);
                return;
            }

            const winPoints = Number(competition?.scoring?.win ?? 2);
            const drawPoints = Number(competition?.scoring?.draw ?? (winPoints / 2));
            const lossPoints = Number(competition?.scoring?.loss ?? 0);
            const pointsA = scoreA > scoreB ? winPoints : scoreA === scoreB ? drawPoints : lossPoints;
            const pointsB = scoreB > scoreA ? winPoints : scoreA === scoreB ? drawPoints : lossPoints;

            const { error } = await supabase
                .from("competition_matches")
                .update({
                    score_a: scoreA,
                    score_b: scoreB,
                    skins_a: skinsA,
                    skins_b: skinsB,
                    points_a: pointsA,
                    points_b: pointsB,
                    shots_for_a: scoreA,
                    shots_for_b: scoreB,
                    completed: true,
                    completed_at: new Date().toISOString()
                })
                .eq("id", selectedMatch.id);

            if (error) throw error;

            // Audit the final competition score only.
            const previousScoreA = selectedMatch.score_a;
            const previousScoreB = selectedMatch.score_b;
            const wasPreviouslyCompleted = selectedMatch.completed === true;

            const teamAName = getMatchTeamName(selectedMatch, "a");
            const teamBName = getMatchTeamName(selectedMatch, "b");

            const roundName = selectedRound?.round_name || "Unknown round";
            const matchNumber = selectedMatch.match_number ?? "Unknown";

            const scoreAction = wasPreviouslyCompleted
                ? "SCORE AMENDED"
                : "SCORE ENTERED";

            const scoreSummary = wasPreviouslyCompleted
                ? `Score amended: ${teamAName} ${previousScoreA} - ${previousScoreB} ${teamBName} changed to ${teamAName} ${scoreA} - ${scoreB} ${teamBName}.`
                : `Final score entered: ${teamAName} ${scoreA} - ${scoreB} ${teamBName}.`;

            try {
                await logAuditEvent(
                    "WORKFLOW_ACTION",
                    `${scoreAction}: ${competition?.name || "Competition"} | ${roundName} | Match ${matchNumber}. ${scoreSummary}`,
                    {
                        operation: wasPreviouslyCompleted
                            ? "score_amended"
                            : "score_entered",
                        competition_name: competition?.name || null,
                        round_name: roundName,
                        match_number: matchNumber,
                        team_a: teamAName,
                        team_b: teamBName,
                        previous_score_a: wasPreviouslyCompleted ? previousScoreA : null,
                        previous_score_b: wasPreviouslyCompleted ? previousScoreB : null,
                        final_score_a: scoreA,
                        final_score_b: scoreB
                    },
                    competitionId
                );
            } catch (auditError) {
                console.error("Score saved, but audit logging failed:", auditError);
            }


            // Refresh all matches before deciding the competition status.
            // A competition is completed when every real competition match
            // has a result. Do not rely on a round being named "Final":
            // round-robin competitions (including single-group events) may
            // have no Final round at all.
            const refreshedMatchesResult = await supabase
                .from("competition_matches")
                .select("id, competition_id, round_id, section_id, match_number, team_a_id, team_b_id, score_a, score_b, skins_a, skins_b, points_a, points_b, shots_for_a, shots_for_b, completed, completed_at, next_match_id, next_match_slot")
                .eq("competition_id", competitionId);

            if (refreshedMatchesResult.error) throw refreshedMatchesResult.error;

            let refreshedMatches = refreshedMatchesResult.data || [];

            const hasMatches = refreshedMatches.length > 0;
            const allMatchesCompleted = hasMatches && refreshedMatches.every(match => match.completed === true);
            const newCompetitionStatus = allMatchesCompleted ? "completed" : "in_progress";

            const { error: competitionStatusError } = await supabase
                .from("competitions")
                .update({ status: newCompetitionStatus })
                .eq("id", competitionId);

            if (competitionStatusError) {
                console.warn("Unable to update competition status:", competitionStatusError);
            }

            const isSectional = Boolean(selectedRound?.round_name?.toLowerCase().includes("sectional"));
            let bracketChanged = false;

            if (selectedMatch.section_id && isSectional) {
                const beforeWinner = getSectionWinner(selectedMatch.section_id, refreshedMatches);
                await populateSectionWinner(selectedMatch.section_id, refreshedMatches);
                bracketChanged = Boolean(beforeWinner);
            } else {
                const winnerTeamId = scoreA > scoreB ? selectedMatch.team_a_id : scoreB > scoreA ? selectedMatch.team_b_id : null;
                if (winnerTeamId && selectedMatch.next_match_id) {
                    await advanceWinner(selectedMatch.id, winnerTeamId);
                    bracketChanged = true;
                }
            }

            // If a sectional winner or playoff winner was advanced, fetch the
            // match list once more so the local bracket reflects that change.
            if (bracketChanged) {
                const latestMatchesResult = await supabase
                    .from("competition_matches")
                    .select("id, competition_id, round_id, section_id, match_number, team_a_id, team_b_id, score_a, score_b, skins_a, skins_b, points_a, points_b, shots_for_a, shots_for_b, completed, completed_at, next_match_id, next_match_slot")
                    .eq("competition_id", competitionId);

                if (latestMatchesResult.error) throw latestMatchesResult.error;
                refreshedMatches = latestMatchesResult.data || [];
            }

            // Update only the scoring data in memory. This preserves the
            // current page position/section state and avoids a full workspace
            // reload after every result.
            const roundById = new Map((confirmedDraw.rounds || []).map(round => [round.id, round]));
            const teamById = new Map((teams || []).map(team => [team.id, team]));
            const enrichMatch = match => ({
                ...match,
                round: roundById.get(match.round_id),
                teamA: teamById.get(match.team_a_id),
                teamB: teamById.get(match.team_b_id)
            });

            setConfirmedDraw(prev => {
                if (!prev) return prev;

                const updatedMatches = refreshedMatches.map(enrichMatch);
                return {
                    ...prev,
                    matches: updatedMatches,
                    sections: prev.sections.map(section => ({
                        ...section,
                        matches: updatedMatches.filter(match => match.section_id === section.id)
                    }))
                };
            });

            setCompetition(prev => prev ? { ...prev, status: newCompetitionStatus } : prev);
            setSelectedMatch(null);
            setResultForm({ score_a: "", score_b: "", skins_a: "", skins_b: "" });
            setResultSavedMessage("Result saved successfully.");
            window.setTimeout(() => setResultSavedMessage(""), 1800);
        } catch (error) {
            console.error("Error saving result:", error);
            alert(`Unable to save result.\n\n${error.message}`);
        } finally {
            setSavingResult(false);
        }
    };

    /*
     * Reset team form.
     */
    const resetTeamForm = (clubId = lastUsedClubId) => {
        setTeamForm({
            club_id: clubId || "",
            team_name: "",
            players: {}
        });

        setPlayerSearch({});
        setEditingTeam(null);
    };

    /*
     * Reset playing day form.
     */
    const resetDayForm = () => {
        setDayForm({
            playing_date: "",
            name: "",
            venue_club_id: "",
            status: "scheduled"
        });

        setEditingDay(null);
    };

    /*
     * Reset round form.
     */
    const resetRoundForm = () => {
        setRoundForm({
            competition_day_id: "",
            round_name: "",
            status: "pending"
        });

        setEditingRound(null);
    };

    /*
     * Add participating club.
     */
    const handleAddClub = async () => {
        if (!selectedClubIds.length) {
            alert("Please select at least one club.");
            return;
        }

        const availableClubIds = new Set(
            availableClubs.map(club => club.id)
        );

        const clubIdsToAdd = selectedClubIds.filter(
            clubId => availableClubIds.has(clubId)
        );

        if (!clubIdsToAdd.length) {
            alert("The selected clubs are already in this competition.");
            return;
        }

        setSaving(true);

        const rows = clubIdsToAdd.map(clubId => ({
            competition_id: competitionId,
            club_id: clubId
        }));

        const { error } = await supabase
            .from("competition_clubs")
            .insert(rows);

        setSaving(false);

        if (error) {
            console.error(
                "Error adding clubs:",
                error
            );

            alert(
                `Unable to add clubs.\n\n${error.message}`
            );

            return;
        }

        setSelectedClubIds([]);
        setShowClubForm(false);

        await loadData();
    };

    /*
     * Remove participating club.
     */
    const handleRemoveClub = async (entry) => {
        const clubName =
            entry.clubs?.name || "this club";

        const clubTeams = teams.filter(
            team =>
                team.club_id === entry.club_id
        );

        if (clubTeams.length > 0) {
            alert(
                `${clubName} has ${clubTeams.length} team(s) entered in this competition.\n\nRemove or withdraw those teams before removing the club.`
            );

            return;
        }

        const confirmed = window.confirm(
            `Remove ${clubName} from this competition?`
        );

        if (!confirmed) {
            return;
        }

        const { error } = await supabase
            .from("competition_clubs")
            .delete()
            .eq("id", entry.id);

        if (error) {
            console.error(
                "Error removing club:",
                error
            );

            alert(
                `Unable to remove club.\n\n${error.message}`
            );

            return;
        }

        await loadData();
    };

    /*
     * Start new team.
     */
    const handleAddTeam = () => {
        resetTeamForm();
        shouldScrollToTeamFormRef.current = true;
        setShowTeamForm(true);
    };

    /*
     * Edit existing team.
     */
    const handleEditTeam = (team) => {
        const playerMap = {};

        (team.competition_team_players || [])
            .forEach(item => {
                playerMap[item.position] =
                    item.player_id;
            });

        // The edit form is rendered near the top of the Teams section. Set the
        // same scroll flag used by Add Team so Edit visibly opens the form,
        // even when the secretary clicked a team much farther down the page.
        shouldScrollToTeamFormRef.current = true;
        setEditingTeam(team);

        setTeamForm({
            club_id: team.club_id || "",
            team_name: team.team_name || "",
            players: playerMap
        });

        setPlayerSearch({});
        setShowTeamForm(true);
    };

    /*
     * Team form change.
     */
    const handleTeamFormChange = (e) => {
        const {
            name,
            value
        } = e.target;

        setTeamForm(prev => ({
            ...prev,
            [name]: value,
            // A team moved to another club must be rebuilt from that club's
            // eligible players; do not accidentally retain the old roster.
            ...(name === "club_id" && String(prev.club_id || "") !== String(value || "")
                ? { players: {} }
                : {})
        }));

        if (name === "club_id") {
            setPlayerSearch({});
        }
    };

    /*
     * Select player for position.
     */
    const handlePlayerChange = (
        position,
        playerId
    ) => {
        setTeamForm(prev => {
            const updatedPlayers = {
                ...prev.players
            };

            if (playerId) {
                updatedPlayers[position] =
                    playerId;
            } else {
                delete updatedPlayers[position];
            }

            return {
                ...prev,
                players: updatedPlayers
            };
        });
    };

    /*
     * Save team.
     */
    const handleSaveTeam = async (e) => {
        e.preventDefault();

        if (!teamForm.club_id) {
            alert("Please select a club.");
            return;
        }

        const positions =
            getPositions(competition.format);

        for (const position of positions) {
            if (!teamForm.players[position.key]) {
                alert(
                    `Please select a player for ${position.label}.`
                );

                return;
            }
        }

        const selectedPlayers =
            Object.values(teamForm.players);

        const uniquePlayers =
            new Set(selectedPlayers);

        if (
            uniquePlayers.size !==
            selectedPlayers.length
        ) {
            alert(
                "A player cannot be assigned to more than one position in the same team."
            );

            return;
        }

        // After a draw has been confirmed, editing a team changes the roster
        // occupying that existing draw position. Keep the competition_team id
        // and team_number stable so fixture references, section membership,
        // scheduled dates, venues and rink bookings are not regenerated.
        if (editingTeam && confirmedDraw) {
            const existingNames = (editingTeam.competition_team_players || [])
                .map(item => item.players ? playerName(item.players) : "")
                .filter(Boolean);
            const selectedNames = positions
                .map(position => {
                    const player = clubPlayers.find(item => String(item.id) === String(teamForm.players[position.key]));
                    return player ? playerName(player) : "a selected player";
                });
            const changed = String(editingTeam.club_id || "") !== String(teamForm.club_id || "") ||
                editingTeam.status !== "active" ||
                positions.some(position => String(
                    (editingTeam.competition_team_players || []).find(item => item.position === position.key)?.player_id || ""
                ) !== String(teamForm.players[position.key] || ""));

            if (changed) {
                const confirmed = window.confirm(
                    `Update ${editingTeam.team_name || `Team ${editingTeam.team_number}`} after the draw has been confirmed?\n\n` +
                    `Current players: ${existingNames.join(" / ") || "not available"}\n` +
                    `New players: ${selectedNames.join(" / ")}\n\n` +
                    `The team will keep its existing draw position and fixtures. Section, opponents, dates, venues and rink bookings will not be redrawn. ` +
                    `If this is a replacement team, its status will be set to Active.`
                );
                if (!confirmed) return;
            }
        }

        setSaving(true);

        try {
            let competitionTeamId;

            if (!editingTeam) {
                const nextTeamNumber =
                    teams.length > 0
                        ? Math.max(
                            ...teams.map(
                                team =>
                                    team.team_number || 0
                            )
                        ) + 1
                        : 1;

                const teamResult =
                    await supabase
                        .from("competition_teams")
                        .insert({
                            competition_id:
                                competitionId,

                            club_id:
                                teamForm.club_id,

                            team_number:
                                nextTeamNumber,

                            team_name:
                                teamForm.team_name.trim() ||
                                null,

                            status:
                                "active"
                        })
                        .select("id")
                        .single();

                if (teamResult.error) {
                    throw teamResult.error;
                }

                competitionTeamId =
                    teamResult.data.id;

            } else {
                competitionTeamId = editingTeam.id;

                const teamResult = await supabase
                    .from("competition_teams")
                    .update({
                        club_id: teamForm.club_id,
                        team_name: teamForm.team_name.trim() || null,
                        // Editing a withdrawn team is the supported way to
                        // install a replacement into that same draw position.
                        status: "active"
                    })
                    .eq("id", editingTeam.id);

                if (teamResult.error) throw teamResult.error;

                const deleteResult = await supabase
                    .from("competition_team_players")
                    .delete()
                    .eq("competition_team_id", editingTeam.id);

                if (deleteResult.error) {
                    // Restore the team's previous metadata if roster removal fails.
                    await supabase.from("competition_teams").update({
                        club_id: editingTeam.club_id,
                        team_name: editingTeam.team_name || null,
                        status: editingTeam.status || "active"
                    }).eq("id", editingTeam.id);
                    throw deleteResult.error;
                }
            }

            const playerRows =
                positions.map(position => ({
                    competition_team_id:
                        competitionTeamId,

                    player_id:
                        teamForm.players[
                            position.key
                        ],

                    position:
                        position.key,

                    position_order:
                        position.order
                }));

            const playersResult =
                await supabase
                    .from("competition_team_players")
                    .insert(playerRows);

            if (playersResult.error) {
                if (!editingTeam) {
                    await supabase.from("competition_teams").delete().eq("id", competitionTeamId);
                } else {
                    // Best-effort rollback so a failed roster save does not leave
                    // the confirmed team with no players.
                    const previousRows = (editingTeam.competition_team_players || []).map(item => ({
                        competition_team_id: editingTeam.id,
                        player_id: item.player_id,
                        position: item.position,
                        position_order: item.position_order
                    }));
                    if (previousRows.length) {
                        await supabase.from("competition_team_players").insert(previousRows);
                    }
                    await supabase.from("competition_teams").update({
                        club_id: editingTeam.club_id,
                        team_name: editingTeam.team_name || null,
                        status: editingTeam.status || "active"
                    }).eq("id", editingTeam.id);
                }

                throw playersResult.error;
            }

            // Remember the club used for this team so the next Add Team form
            // can preselect it. Persisting per competition keeps this useful
            // even after a page refresh.
            setLastUsedClubId(teamForm.club_id);
            try {
                localStorage.setItem(
                    lastUsedClubStorageKey,
                    teamForm.club_id
                );
            } catch {
                // localStorage may be unavailable in some browser/privacy modes.
            }

            // Keep the user at the top of Competition Teams after saving.
            // Suppress the normal progressive-stage jump because saving the
            // third team can otherwise immediately move the page to Draw.
            suppressNextWorkspaceStageScrollRef.current = true;
            setShowTeamForm(false);
            resetTeamForm(teamForm.club_id);

            await loadData();

            window.setTimeout(() => {
                focusWorkspaceStage("teams");
            }, 120);

        } catch (error) {
            console.error(
                "Error saving team:",
                error
            );

            alert(
                `Unable to save team.\n\n${error.message}`
            );

        } finally {
            setSaving(false);
        }
    };

    /*
     * Change team status.
     */
    const handleChangeTeamStatus = async (team, status) => {
        const statusText = { active: "active", withdrawn: "withdrawn", eliminated: "eliminated" };
        if ((status === "withdrawn" || status === "active") && hasCompetitionScoringStarted()) {
            alert("Players/teams cannot be withdrawn or reinstated after scoring has started.");
            return;
        }

        const membershipResult = (status === "withdrawn" || status === "active")
            ? await supabase.from("competition_section_teams")
                .select("id, section_id").eq("competition_team_id", team.id).maybeSingle()
            : { data: null, error: null };
        if (membershipResult.error) {
            alert(`Unable to check the section membership.\n\n${membershipResult.error.message}`);
            return;
        }

        const sectionId = membershipResult.data?.section_id || null;
        const section = sectionId ? confirmedDraw?.sections?.find(item => item.id === sectionId) : null;
        const shouldRegenerate = Boolean(section && (status === "withdrawn" || status === "active"));
        if (status === "withdrawn" && shouldRegenerate && section.teams.length <= 3) {
            alert("This withdrawal would leave fewer than three active entries in the section.");
            return;
        }

        if (!window.confirm(status === "withdrawn" && shouldRegenerate
            ? `Withdraw ${getTeamBaseName(team)}? The sectional fixtures will be updated atomically. Bookings for obsolete matches will be removed.`
            : `Set Team ${team.team_number} to ${statusText[status]}?`)) return;

        setSavingSectionSwap(true);
        try {
            if (shouldRegenerate) {
                const activeEntries = section.teams.filter(entry =>
                    String(entry.competition_team_id || entry.id) !== String(team.id)
                );
                if (status === "active") {
                    activeEntries.push({
                        ...team,
                        competition_team_id: team.id,
                        section_id: sectionId,
                        section_team_id: membershipResult.data.id
                    });
                }
                await regenerateSavedSectionFixtures(
                    new Map([[sectionId, activeEntries]]),
                    [],
                    [{ team_id: team.id, status }]
                );
            } else {
                const { error } = await supabase.from("competition_teams")
                    .update({ status }).eq("id", team.id);
                if (error) throw error;
            }
            await loadData();
            if (status === "withdrawn" && shouldRegenerate) {
                setSectionManagerMessage(`${getTeamBaseName(team)} has been withdrawn and the sectional fixtures have been synchronized.`);
            }
        } catch (error) {
            console.error("Error changing team status:", error);
            await loadData();
            alert(`Unable to update team status. No partial section/fixture change was committed.\n\n${error.message}`);
        } finally {
            setSavingSectionSwap(false);
        }
    };

    /*
     * Replace a withdrawn entry with a player from the same club.
     * The competition team and section membership IDs remain unchanged so
     * the replacement inherits the existing draw position.
     */
    
    const handleAddLateEntry = async () => {
        if (hasCompetitionScoringStarted()) {
            alert("A late entry cannot be added after sectional scoring has started.");
            return;
        }
        const section = confirmedDraw?.sections?.find(item => item.id === lateEntrySectionId);
        if (!section || !lateEntryClubId) {
            alert("Choose a section and a participating club.");
            return;
        }
        const participating = participatingClubs.some(item => String(item.club_id) === String(lateEntryClubId));
        if (!participating) {
            alert("The selected club is not registered as a participating club in this competition.");
            return;
        }
        const positions = getPositions(competition.format);
        const alreadyEntered = new Set(teams.flatMap(team => (team.competition_team_players || []).map(row => String(row.player_id))));
        const rosterInput = [];
        const seenExisting = new Set();
        for (const position of positions) {
            const mode = lateEntryPlayerModes[position.key] || "existing";
            if (mode === "new") {
                const person = lateEntryNewPlayers[position.key] || {};
                if (!String(person.first_name || "").trim() || !String(person.last_name || "").trim()) {
                    alert(`Enter the first name and surname for ${position.label}.`);
                    return;
                }
                rosterInput.push({ position: position.key, position_order: position.order, new_player: {
                    first_name: person.first_name.trim(), last_name: person.last_name.trim(),
                    nickname: String(person.nickname || "").trim() || null,
                    bsa_number: String(person.bsa_number || "").trim() || null
                }});
            } else {
                const id = lateEntryPlayers[position.key];
                const person = players.find(player => String(player.id) === String(id));
                if (!person || alreadyEntered.has(String(id)) || seenExisting.has(String(id))) {
                    alert(`Choose an eligible, unused existing player for ${position.label}.`);
                    return;
                }
                if (!(String(person.club_id) === String(lateEntryClubId) || String(person.second_club_id) === String(lateEntryClubId))) {
                    alert(`The selected ${position.label.toLowerCase()} must belong to the selected club.`);
                    return;
                }
                seenExisting.add(String(id));
                rosterInput.push({ position: position.key, position_order: position.order, player_id: id });
            }
        }

        const newTeamId = crypto.randomUUID();
        const newTeamNumber = Math.max(0, ...teams.map(team => Number(team.team_number) || 0)) + 1;
        const selectedClub = participatingClubs.find(item => String(item.club_id) === String(lateEntryClubId));
        const club = selectedClub?.clubs || clubs.find(item => String(item.id) === String(lateEntryClubId));
        const provisionalTeam = {
            id: newTeamId,
            team_number: newTeamNumber,
            team_name: null,
            club_id: lateEntryClubId,
            clubs: club || null,
            status: "active"
        };
        const newEntry = { id: newTeamId, competition_team_id: newTeamId, ...provisionalTeam };
        const nextEntries = [...(section.teams || []), newEntry];
        const drawTeams = nextEntries.map(entry => {
            const teamId = entry.competition_team_id || entry.id;
            const fullTeam = teamId === newTeamId ? provisionalTeam : (teams.find(team => team.id === teamId) || entry);
            return {
                id: teamId,
                name: getTeamBaseName(fullTeam),
                clubId: fullTeam.club_id || null,
                clubName: fullTeam.clubs?.name || ""
            };
        });

        let generatedRounds;
        try {
            generatedRounds = createRoundRobinRounds(drawTeams);
            validateRoundRobin(drawTeams, generatedRounds);
        } catch (error) {
            alert(`The late-entry draw could not be generated: ${error.message}`);
            return;
        }
        const maxSavedRound = Math.max(0, ...(confirmedDraw.rounds || []).map(round => Number(round.round_number) || 0));
        if (generatedRounds.length > maxSavedRound) {
            alert(`Adding this entry requires ${generatedRounds.length} sectional rounds, but the competition currently has only ${maxSavedRound} saved rounds. Add the missing competition rounds first, then try again. No changes have been made.`);
            return;
        }

        const fixtureUpdates = [];
        const fixtureInserts = [];
        const obsoleteIds = new Set();
        const activeIds = new Set(drawTeams.map(team => String(team.id)));
        const sectionMatches = (confirmedDraw.matches || []).filter(match => match.section_id === section.id);
        for (const generatedRound of generatedRounds) {
            const roundRecord = confirmedDraw.rounds.find(round => Number(round.round_number) === Number(generatedRound.number));
            if (!roundRecord) {
                alert(`Saved Round ${generatedRound.number} is missing. No changes have been made.`);
                return;
            }
            const existing = sectionMatches.filter(match => match.round_id === roundRecord.id)
                .sort((a,b) => Number(a.match_number)-Number(b.match_number));
            const matchBase = Math.max(0, ...(confirmedDraw.matches || [])
                .filter(match => match.round_id === roundRecord.id)
                .map(match => Number(match.match_number) || 0));
            generatedRound.matches.forEach((match, index) => {
                if (!activeIds.has(String(match.teamAId)) || !activeIds.has(String(match.teamBId)) || String(match.teamAId) === String(match.teamBId)) {
                    throw new Error(`Invalid opponent pairing in ${section.section_name}, round ${generatedRound.number}.`);
                }
                if (existing[index]) {
                    fixtureUpdates.push({ id: existing[index].id, section_id: section.id, round_id: roundRecord.id, team_a_id: match.teamAId, team_b_id: match.teamBId });
                } else {
                    fixtureInserts.push({ section_id: section.id, round_id: roundRecord.id, match_number: matchBase + (index - existing.length) + 1, team_a_id: match.teamAId, team_b_id: match.teamBId });
                }
            });
            existing.slice(generatedRound.matches.length).forEach(match => obsoleteIds.add(match.id));
        }
        sectionMatches.forEach(match => {
            const roundNumber = confirmedDraw.rounds.find(round => round.id === match.round_id)?.round_number;
            if (Number(roundNumber) > generatedRounds.length) obsoleteIds.add(match.id);
        });

        if (!window.confirm(`Add this ${competition.format} entry to ${section.section_name} for ${club?.name || "the selected club"} and regenerate only this section's fixtures?\n\nExisting fixture IDs and bookings will be retained wherever possible. Other sections and playoff fixtures will not be changed.`)) return;
        setSavingLateEntry(true);
        setSectionManagerMessage("");
        try {
            const roster = rosterInput;
            const { data, error } = await supabase.rpc("add_late_competition_entry_atomic", {
                p_competition_id: competitionId,
                p_new_team_id: newTeamId,
                p_section_id: section.id,
                p_club_id: lateEntryClubId,
                p_roster: roster,
                p_fixture_updates: fixtureUpdates,
                p_fixture_inserts: fixtureInserts,
                p_obsolete_match_ids: [...obsoleteIds]
            });
            if (error) throw error;
            if (!data?.success) throw new Error("Supabase did not confirm the late entry.");
            await loadData();
            setLateEntryPlayers({});
            setLateEntrySearch({});
            setLateEntrySectionId("");
            setLateEntryClubId("");
            setSectionManagerMessage(`Late entry added successfully as Team ${data.team_number}. Only ${section.section_name} was redrawn.`);
        } catch (error) {
            console.error("Unable to add late entry:", error);
            await loadData();
            alert(`Unable to add late entry. The database transaction was rolled back; no partial entry or draw change was committed.\n\n${error.message}`);
        } finally {
            setSavingLateEntry(false);
        }
    };

const handleAddReplacement = async () => {
        if (hasCompetitionScoringStarted()) {
            alert("Replacements cannot be made after scoring has started.");
            return;
        }

        const section = confirmedDraw?.sections?.find(item => item.id === replacementSectionId);
        const entry = (section?.allTeams || section?.teams || []).find(item => String(item.competition_team_id || item.id) === String(replacementTeamId));
        const team = teams.find(item => String(item.id) === String(replacementTeamId));
        if (!section || !entry || !team) {
            alert("Choose a section and entry to replace first.");
            return;
        }
        if (team.status !== "active" && team.status !== "withdrawn") {
            alert("Only active or withdrawn entries can be replaced.");
            return;
        }
        if (!entry.section_team_id) {
            alert("The saved section membership could not be identified. Refresh the competition and try again.");
            return;
        }

        const positions = getPositions(competition.format);
        const positionKey = competition.format === "singles" ? "player" : replacementPosition;
        if (!positionKey || !positions.some(position => position.key === positionKey)) {
            alert("Select the team position being replaced.");
            return;
        }
        const oldRosterRow = (team.competition_team_players || []).find(row => row.position === positionKey);
        if (!oldRosterRow) {
            alert("The existing player in that position could not be found.");
            return;
        }

        const clubId = team.club_id;
        if (!clubId) {
            alert("The withdrawn entry does not have a club assigned.");
            return;
        }

        const enteredPlayerIds = new Set(
            teams.filter(item => {
                const allocatedTeamIds = new Set((confirmedDraw?.sections || []).flatMap(section => [...(section.allTeams || []), ...(section.teams || [])].map(sectionEntry => String(sectionEntry.competition_team_id || sectionEntry.id))));
                return allocatedTeamIds.has(String(item.id));
            }).flatMap(item => (item.competition_team_players || [])
                .filter(row => !(item.id === team.id && row.id === oldRosterRow.id))
                .map(row => String(row.player_id)))
        );
        let replacementPlayerIdToUse = replacementPlayerId;
        let newlyCreatedPlayerId = null;

        if (replacementPlayerMode === "new") {
            const firstName = replacementNewPlayer.first_name.trim();
            const lastName = replacementNewPlayer.last_name.trim();
            if (!firstName || !lastName) {
                alert("Enter the replacement player's first name and surname.");
                return;
            }
            const replacementClubId = replacementNewPlayer.club_id || clubId;
            const participatingClubIds = new Set(participatingClubs.map(item => String(item.club_id)));
            if (!participatingClubIds.has(String(replacementClubId))) {
                alert("Choose a club that is participating in this competition.");
                return;
            }
            const insertPayload = {
                first_name: firstName,
                last_name: lastName,
                nickname: replacementNewPlayer.nickname.trim() || null,
                bsa_number: replacementNewPlayer.bsa_number.trim() || null,
                club_id: replacementClubId,
                active: true
            };
            setSavingSectionSwap(true);
            try {
                const { data, error } = await supabase.from("players").insert(insertPayload).select("id").single();
                if (error) throw error;
                replacementPlayerIdToUse = data.id;
                newlyCreatedPlayerId = data.id;
            } catch (error) {
                setSavingSectionSwap(false);
                alert(`Unable to create the replacement player.\n\n${error.message}`);
                return;
            }
        } else {
            const selectedPlayer = players.find(player => String(player.id) === String(replacementPlayerIdToUse));
            if (!selectedPlayer || selectedPlayer.active === false) {
                alert("Choose an existing active player.");
                return;
            }
        }

        if (!replacementPlayerIdToUse || enteredPlayerIds.has(String(replacementPlayerIdToUse))) {
            if (newlyCreatedPlayerId) await supabase.from("players").delete().eq("id", newlyCreatedPlayerId);
            setSavingSectionSwap(false);
            alert("That player is already entered in this competition. A player can only be entered once.");
            return;
        }

        const oldPlayerId = oldRosterRow.player_id;
        const replacementPlayer = replacementPlayerMode === "new"
            ? { ...replacementNewPlayer, first_name: replacementNewPlayer.first_name.trim(), last_name: replacementNewPlayer.last_name.trim() }
            : players.find(player => String(player.id) === String(replacementPlayerIdToUse));
        const oldPlayer = oldRosterRow.players;
        const oldName = playerName(oldPlayer);
        const newName = playerName(replacementPlayer);
        if (!window.confirm(
            `Replace ${oldName} with ${newName} in ${getTeamBaseName(team)}?\n\n` +
            `The replacement may be from any club participating in this competition. The team number, section, draw position and retained fixture IDs will remain unchanged. ` +
            `Affected sectional fixtures will be synchronized; playoff fixtures and allocations will not be changed.`
        )) {
            if (newlyCreatedPlayerId) await supabase.from("players").delete().eq("id", newlyCreatedPlayerId);
            setSavingSectionSwap(false);
            return;
        }

        try {
            const rosterUpdate = await supabase.from("competition_team_players")
                .update({ player_id: replacementPlayerIdToUse })
                .eq("id", oldRosterRow.id);
            if (rosterUpdate.error) throw rosterUpdate.error;

            const activeEntries = section.teams.filter(item => {
                const itemTeamId = item.competition_team_id || item.id;
                const fullTeam = teams.find(candidate => candidate.id === itemTeamId) || item;
                return fullTeam.status !== "withdrawn" || String(itemTeamId) === String(team.id);
            });
            await regenerateSavedSectionFixtures(
                new Map([[section.id, activeEntries]]),
                [],
                team.status === "withdrawn" ? [{ team_id: team.id, status: "active" }] : []
            );

            await loadData();
            setSectionManagerMessage(`${newName} has replaced ${oldName} in ${getTeamBaseName(team)}. The existing draw position was retained.`);
            setReplacementTeamId("");
            setReplacementPlayerId("");
            setReplacementPosition("");
            setReplacementSearch("");
            setReplacementNewPlayer({ first_name: "", last_name: "", nickname: "", bsa_number: "", club_id: "" });
        } catch (error) {
            console.error("Unable to add replacement:", error);
            // Restore the previous roster member if the fixture transaction fails.
            const rollback = await supabase.from("competition_team_players")
                .update({ player_id: oldPlayerId })
                .eq("id", oldRosterRow.id);
            if (rollback.error) console.error("Replacement roster rollback failed:", rollback.error);
            await loadData();
            alert(`Unable to complete the replacement. The original roster member was restored where possible.\n\n${error.message}`);
        } finally {
            setSavingSectionSwap(false);
        }
    };

    /*
     * Start adding a playing day.
     */
    const handleAddDay = () => {
        resetDayForm();
        setShowDayForm(true);
    };

    /*
     * Edit playing day.
     */
    const handleEditDay = (day) => {
        setEditingDay(day);

        setDayForm({
            playing_date:
                day.playing_date || "",

            name:
                day.name || "",

            venue_club_id:
                day.venue_club_id || "",

            status:
                day.status || "scheduled"
        });

        setShowDayForm(true);
    };

    /*
     * Playing day form change.
     */
    const handleDayFormChange = (e) => {
        const {
            name,
            value
        } = e.target;

        setDayForm(prev => ({
            ...prev,
            [name]: value
        }));
    };

    /*
     * Save playing day.
     */
    const handleSaveDay = async (e) => {
        e.preventDefault();

        if (!dayForm.playing_date) {
            alert("Please select a playing date.");
            return;
        }

        const duplicateDate =
            playingDays.some(
                day =>
                    day.playing_date ===
                        dayForm.playing_date &&
                    day.id !==
                        editingDay?.id
            );

        if (duplicateDate) {
            alert(
                "There is already a playing day scheduled for this date."
            );

            return;
        }

        setSaving(true);

        try {
            if (editingDay) {
                const { error } =
                    await supabase
                        .from("competition_days")
                        .update({
                            playing_date:
                                dayForm.playing_date,

                            name:
                                dayForm.name.trim() ||
                                null,

                            venue_club_id:
                                dayForm.venue_club_id ||
                                null,

                            status:
                                dayForm.status,

                            updated_at:
                                new Date().toISOString()
                        })
                        .eq(
                            "id",
                            editingDay.id
                        );

                if (error) {
                    throw error;
                }

            } else {
                const nextDayNumber =
                    playingDays.length > 0
                        ? Math.max(
                            ...playingDays.map(
                                day =>
                                    day.day_number || 0
                            )
                        ) + 1
                        : 1;

                const { error } =
                    await supabase
                        .from("competition_days")
                        .insert({
                            competition_id:
                                competitionId,

                            day_number:
                                nextDayNumber,

                            playing_date:
                                dayForm.playing_date,

                            name:
                                dayForm.name.trim() ||
                                null,

                            venue_club_id:
                                dayForm.venue_club_id ||
                                null,

                            status:
                                dayForm.status
                        });

                if (error) {
                    throw error;
                }
            }

            setShowDayForm(false);
            resetDayForm();

            await loadData();

        } catch (error) {
            console.error(
                "Error saving playing day:",
                error
            );

            alert(
                `Unable to save playing day.\n\n${error.message}`
            );

        } finally {
            setSaving(false);
        }
    };

    /*
     * Delete playing day.
     */
    const handleDeleteDay = async (day) => {
        const {
            count,
            error: countError
        } = await supabase
            .from("competition_rounds")
            .select(
                "id",
                {
                    count: "exact",
                    head: true
                }
            )
            .eq(
                "competition_day_id",
                day.id
            );

        if (countError) {
            console.error(
                "Error checking rounds:",
                countError
            );

            alert(
                `Unable to check whether this playing day can be deleted.\n\n${countError.message}`
            );

            return;
        }

        if (count > 0) {
            alert(
                `Day ${day.day_number} cannot be deleted because it already has ${count} round(s) assigned to it.\n\nRemove the rounds first.`
            );

            return;
        }

        const confirmed =
            window.confirm(
                `Delete Day ${day.day_number}${day.name ? ` (${day.name})` : ""}?`
            );

        if (!confirmed) {
            return;
        }

        const { error } =
            await supabase
                .from("competition_days")
                .delete()
                .eq(
                    "id",
                    day.id
                );

        if (error) {
            console.error(
                "Error deleting playing day:",
                error
            );

            alert(
                `Unable to delete playing day.\n\n${error.message}`
            );

            return;
        }

        await loadData();
    };

    /*
     * Add round.
     */
    const handleAddRound = () => {
        resetRoundForm();
        setShowRoundForm(true);
    };

    /*
     * Edit round.
     */
    const handleEditRound = (round) => {
        setEditingRound(round);

        setRoundForm({
            competition_day_id:
                round.competition_day_id || "",

            round_name:
                round.round_name || "",

            status:
                round.status || "pending"
        });

        setShowRoundForm(true);
    };

    /*
     * Round form change.
     */
    const handleRoundFormChange = (e) => {
        const {
            name,
            value
        } = e.target;

        setRoundForm(prev => ({
            ...prev,
            [name]: value
        }));
    };

    /*
     * Save round.
     */
    const handleSaveRound = async (e) => {
        e.preventDefault();

        if (!roundForm.competition_day_id) {
            alert(
                "Please select a playing day."
            );

            return;
        }

        let roundNumber;

        if (editingRound) {
            roundNumber =
                editingRound.round_number;

        } else {
            roundNumber =
                rounds.length > 0
                    ? Math.max(
                        ...rounds.map(
                            round =>
                                round.round_number || 0
                        )
                    ) + 1
                    : 1;
        }

        setSaving(true);

        try {
            if (editingRound) {
                const { error } =
                    await supabase
                        .from("competition_rounds")
                        .update({
                            competition_day_id:
                                roundForm.competition_day_id,

                            round_name:
                                roundForm.round_name.trim() ||
                                null,

                            status:
                                roundForm.status,

                            updated_at:
                                new Date().toISOString()
                        })
                        .eq(
                            "id",
                            editingRound.id
                        );

                if (error) {
                    throw error;
                }

            } else {
                const { error } =
                    await supabase
                        .from("competition_rounds")
                        .insert({
                            competition_id:
                                competitionId,

                            competition_day_id:
                                roundForm.competition_day_id,

                            round_number:
                                roundNumber,

                            round_name:
                                roundForm.round_name.trim() ||
                                null,

                            status:
                                "pending"
                        });

                if (error) {
                    throw error;
                }
            }

            setShowRoundForm(false);
            resetRoundForm();

            await loadData();

        } catch (error) {
            console.error(
                "Error saving round:",
                error
            );

            alert(
                `Unable to save round.\n\n${error.message}`
            );

        } finally {
            setSaving(false);
        }
    };

    /*
     * Delete round safely.
     */
    const handleDeleteRound = async (round) => {
        const {
            count,
            error: countError
        } = await supabase
            .from("competition_matches")
            .select(
                "id",
                {
                    count: "exact",
                    head: true
                }
            )
            .eq(
                "round_id",
                round.id
            );

        if (countError) {
            console.error(
                "Error checking matches:",
                countError
            );

            alert(
                `Unable to check whether this round can be deleted.\n\n${countError.message}`
            );

            return;
        }

        if (count > 0) {
            alert(
                `Round ${round.round_number} cannot be deleted because it already has ${count} match(es) assigned to it.`
            );

            return;
        }

        const confirmed =
            window.confirm(
                `Delete Round ${round.round_number}${round.round_name ? ` (${round.round_name})` : ""}?`
            );

        if (!confirmed) {
            return;
        }

        const { error } =
            await supabase
                .from("competition_rounds")
                .delete()
                .eq(
                    "id",
                    round.id
                );

        if (error) {
            console.error(
                "Error deleting round:",
                error
            );

            alert(
                `Unable to delete round.\n\n${error.message}`
            );

            return;
        }

        await loadData();
    };

    /*
     * Generate a draw proposal from the teams currently entered.
     * This is intentionally a preview step only. Nothing is written to Supabase.
     */
    const handleGenerateDraw = () => {
        const activeTeams = teams
            .filter(team => team.status === "active")
            .map(team => ({
                id: team.id,
                name: getTeamBaseName(team),
                playerNames: getTeamPlayerNames(team),
                clubId: team.club_id || null,
                clubName: team.clubs?.name || team.clubs?.short_name || null
            }));

        if (activeTeams.length < 3) {
            alert("At least 3 active teams are required before a draw can be generated.");
            return;
        }

        setGeneratingDraw(true);

        try {
            const proposal = generateCompetitionDrawProposal({
                teams: activeTeams,
                competitionType: drawType
            });

            setDrawProposal(proposal);
            setIsEditingDrawProposal(false);
            setDraggedProposalTeamId("");
            setProposalEditMessage("");
            setShowDrawPlanner(true);
        } catch (error) {
            console.error("Error generating draw proposal:", error);
            alert(`Unable to generate draw proposal.\n\n${error.message}`);
        } finally {
            setGeneratingDraw(false);
        }
    };

    const handleLoadOfficialLadiesDraw = () => {
        const activeTeams = teams
            .filter(team => team.status === "active")
            .map(team => ({
                id: team.id,
                name: getTeamBaseName(team),
                playerNames: getTeamPlayerNames(team),
                clubId: team.club_id || null,
                clubName: team.clubs?.name || team.clubs?.short_name || null
            }));
        try {
            const proposal = buildOfficialLadiesDistrictPairsProposal(activeTeams, drawType);
            setDrawProposal(proposal);
            setIsEditingDrawProposal(false);
            setDraggedProposalTeamId("");
            setProposalEditMessage("");
            setShowDrawPlanner(true);
        } catch (error) {
            console.error("Unable to load official ladies draw proposal:", error);
            alert(`Unable to load the official ladies draw.\n\n${error.message}`);
        }
    };

    const clearDrawProposal = () => {
        setDrawProposal(null);
        setShowDrawPlanner(false);
        setIsEditingDrawProposal(false);
        setDraggedProposalTeamId("");
        setProposalEditMessage("");
    };

    /*
     * Edit the recommended draw while it is still a proposal.
     * Dropping one entry onto another swaps their section memberships so
     * every section retains its original size. This edits only local proposal
     * state; Supabase is not touched until Confirm Draw is pressed.
     */
    const handleProposalEntryDrop = (targetSectionNumber, targetTeamId) => {
        const sourceTeamId = draggedProposalTeamId;
        setDraggedProposalTeamId("");

        if (!sourceTeamId || sourceTeamId === targetTeamId || !drawProposal?.recommendedPlan) return;

        const sourceSectionNumber = drawProposal.recommendedPlan.sections.find(section =>
            section.teams.some(team => String(team.id) === String(sourceTeamId))
        )?.number;
        if (sourceSectionNumber === undefined) return;
        if (Number(sourceSectionNumber) === Number(targetSectionNumber)) {
            setProposalEditMessage("To move an entry, drop it onto an entry in a different section.");
            return;
        }

        setDrawProposal(current => {
            if (!current?.recommendedPlan?.sections) return current;

            const sections = current.recommendedPlan.sections.map(section => ({
                ...section,
                teams: [...section.teams]
            }));

            let sourceSection = null;
            let targetSection = null;
            let sourceIndex = -1;
            let targetIndex = -1;

            sections.forEach(section => {
                const sourceIndexInSection = section.teams.findIndex(team => String(team.id) === String(sourceTeamId));
                const targetIndexInSection = section.teams.findIndex(team => String(team.id) === String(targetTeamId));
                if (sourceIndexInSection >= 0) {
                    sourceSection = section;
                    sourceIndex = sourceIndexInSection;
                }
                if (targetIndexInSection >= 0) {
                    targetSection = section;
                    targetIndex = targetIndexInSection;
                }
            });

            if (!sourceSection || !targetSection || Number(sourceSection.number) === Number(targetSection.number)) return current;

            const sourceEntry = sourceSection.teams[sourceIndex];
            const targetEntry = targetSection.teams[targetIndex];

            sourceSection.teams[sourceIndex] = targetEntry;
            targetSection.teams[targetIndex] = sourceEntry;

            return {
                ...current,
                recommendedPlan: {
                    ...current.recommendedPlan,
                    sections
                }
            };
        });

        setProposalEditMessage("Entries swapped. Section sizes are unchanged. Confirm Draw will save this adjusted proposal.");
    };

    /*
     * Build and persist round-robin fixtures for the supplied active section
     * memberships. Existing match IDs are retained wherever a fixture remains,
     * so saved dates and facility bookings stay attached to those fixtures.
     * Obsolete matches (e.g. rounds 4 and 5 in a four-player section) have only
     * their own facility bookings and match rows removed.
     */
    const regenerateSavedSectionFixtures = async (
        sectionEntries,
        membershipChanges = [],
        teamStatusChanges = []
    ) => {
        const fixtureUpdates = [];
        const fixtureInserts = [];
        const obsoleteIds = new Set();

        for (const [sectionId, entries] of sectionEntries.entries()) {
            const section = confirmedDraw.sections.find(item => item.id === sectionId);
            if (!section) throw new Error("A selected section could not be found.");

            const drawTeams = entries.map(entry => {
                const teamId = entry.competition_team_id || entry.id;
                const fullTeam = teams.find(team => team.id === teamId) || entry;
                return {
                    id: teamId,
                    name: getTeamBaseName(fullTeam),
                    clubId: fullTeam.club_id || null,
                    clubName: fullTeam.clubs?.name || ""
                };
            });
            // Validate the complete round-robin before preparing any database changes.
            // This prevents a stale/mismatched section entry list from saving opponents
            // that do not belong to this section, repeat pairings, or missing byes.
            const generatedRounds = createRoundRobinRounds(drawTeams);
            validateRoundRobin(drawTeams, generatedRounds);
            const activeTeamIds = new Set(drawTeams.map(team => String(team.id)));
            const sectionMatches = confirmedDraw.matches.filter(match => match.section_id === sectionId);
            const activeRoundNumbers = new Set(generatedRounds.map(round => Number(round.number)));

            for (const generatedRound of generatedRounds) {
                const roundRecord = confirmedDraw.rounds.find(round =>
                    Number(round.round_number) === Number(generatedRound.number)
                );
                if (!roundRecord) throw new Error(`${section.section_name} is missing saved round ${generatedRound.number}.`);

                const existingMatches = sectionMatches
                    .filter(match => match.round_id === roundRecord.id)
                    .sort((a, b) => Number(a.match_number) - Number(b.match_number));
                const roundMatchNumberBase = Math.max(
                    0,
                    ...confirmedDraw.matches
                        .filter(match => match.round_id === roundRecord.id)
                        .map(match => Number(match.match_number) || 0)
                );

                generatedRound.matches.forEach((generatedMatch, index) => {
                    if (
                        !activeTeamIds.has(String(generatedMatch.teamAId)) ||
                        !activeTeamIds.has(String(generatedMatch.teamBId)) ||
                        String(generatedMatch.teamAId) === String(generatedMatch.teamBId)
                    ) {
                        throw new Error(
                            `${section.section_name}, round ${generatedRound.number} contains an invalid opponent pairing. No changes were saved.`
                        );
                    }
                    const savedMatch = existingMatches[index];
                    if (savedMatch) {
                        fixtureUpdates.push({
                            id: savedMatch.id,
                            section_id: sectionId,
                            round_id: roundRecord.id,
                            team_a_id: generatedMatch.teamAId,
                            team_b_id: generatedMatch.teamBId
                        });
                    } else {
                        fixtureInserts.push({
                            section_id: sectionId,
                            round_id: roundRecord.id,
                            match_number: roundMatchNumberBase + (index - existingMatches.length) + 1,
                            team_a_id: generatedMatch.teamAId,
                            team_b_id: generatedMatch.teamBId
                        });
                    }
                });

                existingMatches.slice(generatedRound.matches.length).forEach(match => obsoleteIds.add(match.id));
            }

            sectionMatches.forEach(match => {
                const roundNumber = confirmedDraw.rounds.find(round => round.id === match.round_id)?.round_number;
                if (!activeRoundNumbers.has(Number(roundNumber))) obsoleteIds.add(match.id);
            });
        }

        const { data, error } = await supabase.rpc("sync_section_fixtures_atomic", {
            p_competition_id: competitionId,
            p_membership_changes: membershipChanges,
            p_team_status_changes: teamStatusChanges,
            p_fixture_updates: fixtureUpdates,
            p_fixture_inserts: fixtureInserts,
            p_obsolete_match_ids: [...obsoleteIds]
        });
        if (error) throw error;
        if (!data?.success) throw new Error("Supabase did not confirm the sectional fixture update.");
        return data;
    };

    const hasCompetitionScoringStarted = () => Boolean(
        confirmedDraw?.matches?.some(match =>
            match.completed ||
            ["score_a", "score_b", "points_a", "points_b", "skins_a", "skins_b", "shots_for_a", "shots_for_b"]
                .some(field => match[field] !== null && match[field] !== undefined && match[field] !== "")
        )
    );

    const handleMoveSectionEntry = async () => {
        if (!confirmedDraw?.sections?.length) return;
        if (hasCompetitionScoringStarted()) {
            alert("Entries cannot be moved after scoring has started.");
            return;
        }
        const sourceSection = confirmedDraw.sections.find(section => section.id === swapSectionA);
        const targetSection = confirmedDraw.sections.find(section => section.id === swapSectionB);
        if (!sourceSection || !targetSection || sourceSection.id === targetSection.id || !swapTeamA) {
            alert("Choose an entry and two different sections."); return;
        }
        const entry = sourceSection.teams.find(item => String(item.competition_team_id || item.id) === String(swapTeamA));
        if (!entry) { alert("The selected entry could not be found. Refresh the draw and try again."); return; }
        const sourceEntries = sourceSection.teams.filter(item => item.section_team_id !== entry.section_team_id);
        const targetEntries = [...targetSection.teams, entry];
        if (sourceEntries.length < 3) { alert("A section must retain at least three active entries."); return; }
        if (targetEntries.length > 7) { alert("The destination section would exceed the supported section size."); return; }
        if (!entry.section_team_id) { alert("The saved section membership ID could not be identified. Refresh the draw and try again."); return; }
        const team = teams.find(item => item.id === (entry.competition_team_id || entry.id)) || entry;
        if (!window.confirm(`Move ${getTeamBaseName(team)} from ${sourceSection.section_name} to ${targetSection.section_name}?\n\nMembership and sectional fixtures will be saved in one database transaction. Existing match IDs and bookings for retained fixtures will be preserved.`)) return;

        setSavingSectionSwap(true);
        setSectionManagerMessage("");
        try {
            await regenerateSavedSectionFixtures(
                new Map([[sourceSection.id, sourceEntries], [targetSection.id, targetEntries]]),
                [{ id: entry.section_team_id, section_id: targetSection.id }]
            );
            await loadData();
            setSectionManagerMessage(`${getTeamBaseName(team)} moved successfully. Section memberships and fixtures were committed together.`);
            setSwapTeamA(""); setSwapTeamB("");
        } catch (error) {
            console.error("Unable to move section entry:", error);
            await loadData();
            alert(`Unable to move entry. The database transaction was rolled back; no partial change was committed.\n\n${error.message}`);
        } finally {
            setSavingSectionSwap(false);
        }
    };

    /*
     * Persist the reviewed draw proposal.
     * The proposal is the source of truth here: we do not recalculate it.
     * Dates/competition_days remain untouched and can be scheduled later.
     */
    const handleSwapSectionEntries = async () => {
        if (!confirmedDraw?.sections?.length) return;
        const sectionA = confirmedDraw.sections.find(section => section.id === swapSectionA);
        const sectionB = confirmedDraw.sections.find(section => section.id === swapSectionB);
        if (!sectionA || !sectionB || sectionA.id === sectionB.id) { alert("Choose two different sections."); return; }
        if (!swapTeamA || !swapTeamB || swapTeamA === swapTeamB) { alert("Choose one entry from each section to swap."); return; }
        const entryA = sectionA.teams.find(entry => String(entry.competition_team_id || entry.id) === String(swapTeamA));
        const entryB = sectionB.teams.find(entry => String(entry.competition_team_id || entry.id) === String(swapTeamB));
        if (!entryA || !entryB) { alert("The selected entries could not be found. Refresh the draw and try again."); return; }
        if (hasCompetitionScoringStarted()) { alert("Section entries cannot be changed after scoring has started."); return; }
        if (!entryA.section_team_id || !entryB.section_team_id) { alert("Saved section membership IDs are missing. Refresh the draw and try again."); return; }

        const confirmed = window.confirm(
            `Swap these entries?\n\n${sectionA.section_name}: ${getTeamBaseName(teams.find(team => team.id === entryA.competition_team_id) || entryA)}\n` +
            `with\n${sectionB.section_name}: ${getTeamBaseName(teams.find(team => team.id === entryB.competition_team_id) || entryB)}\n\n` +
            "Both membership changes and all affected sectional fixtures will be committed atomically."
        );
        if (!confirmed) return;

        setSavingSectionSwap(true);
        setSectionManagerMessage("");
        const nextA = sectionA.teams.map(entry => entry.section_team_id === entryA.section_team_id ? entryB : entry);
        const nextB = sectionB.teams.map(entry => entry.section_team_id === entryB.section_team_id ? entryA : entry);
        try {
            await regenerateSavedSectionFixtures(
                new Map([[sectionA.id, nextA], [sectionB.id, nextB]]),
                [
                    { id: entryA.section_team_id, section_id: sectionB.id },
                    { id: entryB.section_team_id, section_id: sectionA.id }
                ]
            );
            await loadData();
            setSectionManagerMessage("Entries swapped and sectional fixtures synchronized in one database transaction. Existing match IDs and retained rink bookings were preserved.");
            setSwapTeamA(""); setSwapTeamB("");
        } catch (error) {
            console.error("Unable to swap section entries:", error);
            await loadData();
            alert(`Unable to swap entries. The database transaction was rolled back; no partial change was committed.\n\n${error.message}`);
        } finally {
            setSavingSectionSwap(false);
        }
    };

    const handleConfirmDraw = async () => {
        if (!drawProposal?.recommendedPlan) {
            alert("Please calculate a draw proposal first.");
            return;
        }

        const plan = drawProposal.recommendedPlan;
        const confirmed = window.confirm(
            `Confirm this draw for ${plan.teamCount} teams?\n\n` +
            `${plan.sectionCount === 1 ? "Single round robin" : `${plan.sectionCount} sections`}\n` +
            `${plan.sectionalRounds} sectional round(s) + ${plan.playoffStages.length} playoff round(s).\n\n` +
            `This will create the sections, section memberships, rounds and fixtures. Dates will NOT be created yet.`
        );

        if (!confirmed) return;

        setConfirmingDraw(true);

        const createdSectionIds = [];
        const createdRoundIds = [];
        const createdMatchIds = [];

        try {
            // Never silently overwrite an existing draw.
            const [sectionsCheck, roundsCheck, matchesCheck] = await Promise.all([
                supabase
                    .from("competition_sections")
                    .select("id", { count: "exact", head: true })
                    .eq("competition_id", competitionId),
                supabase
                    .from("competition_rounds")
                    .select("id", { count: "exact", head: true })
                    .eq("competition_id", competitionId),
                supabase
                    .from("competition_matches")
                    .select("id", { count: "exact", head: true })
                    .eq("competition_id", competitionId)
            ]);

            const checkError = sectionsCheck.error || roundsCheck.error || matchesCheck.error;
            if (checkError) throw checkError;

            if ((sectionsCheck.count || 0) > 0 || (roundsCheck.count || 0) > 0 || (matchesCheck.count || 0) > 0) {
                throw new Error(
                    "This competition already has draw/scheduling records. The existing draw was not changed."
                );
            }

            // Create sections.
            const sectionRows = plan.sections.map(section => ({
                competition_id: competitionId,
                section_number: section.number,
                section_name: `Section ${section.number}`
            }));

            const { data: sectionData, error: sectionError } = await supabase
                .from("competition_sections")
                .insert(sectionRows)
                .select("id, section_number");

            if (sectionError) throw sectionError;
            createdSectionIds.push(...(sectionData || []).map(row => row.id));

            const sectionIdByNumber = new Map(
                (sectionData || []).map(row => [row.section_number, row.id])
            );

            // Create section memberships.
            const sectionTeamRows = [];
            for (const section of plan.sections) {
                const sectionId = sectionIdByNumber.get(section.number);
                for (const team of section.teams) {
                    sectionTeamRows.push({
                        section_id: sectionId,
                        competition_team_id: team.id
                    });
                }
            }

            if (sectionTeamRows.length) {
                const { error } = await supabase
                    .from("competition_section_teams")
                    .insert(sectionTeamRows);
                if (error) throw error;
            }

            // Create one competition_round per playing round. A round can contain
            // matches from multiple sections. No dates are assigned at this stage.
            const roundRows = [];
            for (let roundNumber = 1; roundNumber <= plan.totalRounds; roundNumber++) {
                const isSectional = roundNumber <= plan.sectionalRounds;
                let roundName = isSectional
                    ? `Sectional Round ${roundNumber}`
                    : plan.playoffStages[roundNumber - plan.sectionalRounds - 1]
                        .replaceAll("_", " ")
                        .replace(/\b\w/g, c => c.toUpperCase());

                roundRows.push({
                    competition_id: competitionId,
                    competition_day_id: null,
                    round_number: roundNumber,
                    round_name: roundName,
                    status: "pending"
                });
            }

            const { data: roundData, error: roundError } = await supabase
                .from("competition_rounds")
                .insert(roundRows)
                .select("id, round_number");

            if (roundError) throw roundError;
            createdRoundIds.push(...(roundData || []).map(row => row.id));

            const roundIdByNumber = new Map(
                (roundData || []).map(row => [row.round_number, row.id])
            );

            // Create sectional fixtures exactly as generated by the proposal.
            const sectionalMatchRows = [];
            for (const section of plan.sections) {
                const sectionId = sectionIdByNumber.get(section.number);
                for (const round of section.rounds) {
                    const roundId = roundIdByNumber.get(round.number);
                    for (const match of round.matches) {
                        sectionalMatchRows.push({
                            competition_id: competitionId,
                            round_id: roundId,
                            section_id: sectionId,
                            match_number: sectionalMatchRows.filter(m => m.round_id === roundId).length + 1,
                            team_a_id: match.teamAId,
                            team_b_id: match.teamBId,
                            score_a: null,
                            score_b: null,
                            skins_a: null,
                            skins_b: null,
                            points_a: null,
                            points_b: null,
                            shots_for_a: null,
                            shots_for_b: null,
                            completed: false,
                            completed_at: null,
                            next_match_id: null,
                            next_match_slot: null
                        });
                    }
                }
            }

            if (sectionalMatchRows.length) {
                const { data, error } = await supabase
                    .from("competition_matches")
                    .insert(sectionalMatchRows)
                    .select("id");
                if (error) throw error;
                createdMatchIds.push(...(data || []).map(row => row.id));
            }

            // Create playoff fixtures with unresolved team IDs. Their sources are
            // represented by next_match_id / next_match_slot so later results can
            // advance section/knockout winners into the correct slot.
            const playoffMatchRows = [];
            const playoffMatchKeys = [];

            for (let i = 0; i < plan.playoffStages.length; i++) {
                const stage = plan.playoffStages[i];
                const roundNumber = plan.sectionalRounds + i + 1;
                const roundId = roundIdByNumber.get(roundNumber);
                const stageMatches = plan.playoffMatches.filter(m => m.stage === stage);

                for (const match of stageMatches) {
                    playoffMatchRows.push({
                        competition_id: competitionId,
                        round_id: roundId,
                        section_id: null,
                        match_number: match.matchNumber,
                        team_a_id: null,
                        team_b_id: null,
                        score_a: null,
                        score_b: null,
                        points_a: null,
                        points_b: null,
                        shots_for_a: null,
                        shots_for_b: null,
                        completed: false,
                        completed_at: null,
                        next_match_id: null,
                        next_match_slot: null
                    });
                    playoffMatchKeys.push({ stage, matchNumber: match.matchNumber });
                }
            }

            let playoffData = [];
            if (playoffMatchRows.length) {
                const { data, error } = await supabase
                    .from("competition_matches")
                    .insert(playoffMatchRows)
                    .select("id, round_id, match_number");
                if (error) throw error;
                playoffData = data || [];
                createdMatchIds.push(...playoffData.map(row => row.id));
            }

            const playoffIdByKey = new Map();
            for (let i = 0; i < playoffData.length; i++) {
                const key = playoffMatchKeys[i];
                playoffIdByKey.set(`${key.stage}:${key.matchNumber}`, playoffData[i].id);
            }

            // Link each playoff match to the next playoff match and slot.
            for (const match of plan.playoffMatches) {
                const sourceId = playoffIdByKey.get(`${match.stage}:${match.matchNumber}`);
                if (!sourceId) continue;

                const target = plan.playoffMatches.find(candidate => {
                    return (
                        candidate.sourceA?.type === `${match.stage}_winner` &&
                        candidate.sourceA?.matchNumber === match.matchNumber
                    ) || (
                        candidate.sourceB?.type === `${match.stage}_winner` &&
                        candidate.sourceB?.matchNumber === match.matchNumber
                    );
                });

                if (target) {
                    const targetId = playoffIdByKey.get(`${target.stage}:${target.matchNumber}`);
                    const slot =
                        target.sourceA?.type === `${match.stage}_winner` &&
                        target.sourceA?.matchNumber === match.matchNumber
                            ? "A"
                            : "B";

                    const { error } = await supabase
                        .from("competition_matches")
                        .update({
                            next_match_id: targetId,
                            next_match_slot: slot
                        })
                        .eq("id", sourceId);

                    if (error) throw error;
                }
            }

            const { error: competitionError } = await supabase
                .from("competitions")
                .update({ status: "draw_generated" })
                .eq("id", competitionId);

            if (competitionError) throw competitionError;

            await logAuditEvent(
                "DRAW_GENERATED",
                `Confirmed competition draw: ${competition?.name || "Competition"}. Created ${plan.sectionCount} section(s), ${plan.totalRounds} round(s) and ${createdMatchIds.length} fixture(s).`,
                {
                    competition_name: competition?.name || null,
                    sections: plan.sectionCount,
                    rounds: plan.totalRounds,
                    fixtures: createdMatchIds.length,
                    teams: plan.teamCount
                },
                competitionId
            );

            setDrawProposal(null);
            setIsEditingDrawProposal(false);
            setDraggedProposalTeamId("");
            setShowDrawPlanner(false);
            await loadData();

            alert(
                `Draw confirmed successfully.\n\n${plan.sectionCount === 1 ? "Single round robin" : `${plan.sectionCount} sections`}\n${plan.totalRounds} round(s) created.\nDates and venues can now be scheduled.`
            );
        } catch (error) {
            console.error("Error confirming draw:", error);

            // Best-effort rollback of records created by this confirmation.
            try {
                if (createdMatchIds.length) {
                    await supabase
                        .from("competition_matches")
                        .delete()
                        .in("id", createdMatchIds);
                }
                if (createdRoundIds.length) {
                    await supabase
                        .from("competition_rounds")
                        .delete()
                        .in("id", createdRoundIds);
                }
                if (createdSectionIds.length) {
                    await supabase
                        .from("competition_section_teams")
                        .delete()
                        .in("section_id", createdSectionIds);
                    await supabase
                        .from("competition_sections")
                        .delete()
                        .in("id", createdSectionIds);
                }
            } catch (rollbackError) {
                console.error("Draw rollback error:", rollbackError);
            }

            alert(`Unable to confirm draw.\n\n${error.message}`);
        } finally {
            setConfirmingDraw(false);
        }
    };

    /*
     * Player counts by participating club. Counts are based on the player
     * assignments actually entered into competition teams. Each team-player
     * row counts as one player entry, so 4 pairs teams correctly show 8
     * player entries. This also works when a player is registered with a
     * second club and represents that club in this competition.
     */
    const getClubPlayerCounts = () => {
        const counts = new Map();

        participatingClubs.forEach(entry => {
            const club = entry.clubs || entry.club || {};
            const clubId = entry.club_id || club.id;

            if (!clubId) return;

            counts.set(clubId, {
                clubId,
                name: club.name || entry.name || "Unknown Club",
                shortName: club.short_name || "",
                playerCount: 0
            });
        });

        teams.forEach(team => {
            const clubId = team.club_id;
            if (!clubId) return;

            if (!counts.has(clubId)) {
                const club = team.clubs || {};
                counts.set(clubId, {
                    clubId,
                    name: club.name || "Unknown Club",
                    shortName: club.short_name || "",
                    playerCount: 0
                });
            }

            const entry = counts.get(clubId);
            entry.playerCount += (team.competition_team_players || []).filter(
                teamPlayer => Boolean(teamPlayer.player_id)
            ).length;
        });

        return Array.from(counts.values())
            .sort((a, b) =>
                a.name.localeCompare(b.name, undefined, { sensitivity: "base" })
            );
    };

    const clubPlayerCounts = getClubPlayerCounts();

    /*
     * Available clubs.
     */
    const availableClubs =
        clubs.filter(
            club =>
                !participatingClubs.some(
                    entry =>
                        entry.club_id ===
                        club.id
                )
        );

    /*
     * Players for selected club.
     */
    const clubPlayers =
        players.filter(player =>
            player.club_id === teamForm.club_id ||
            player.second_club_id === teamForm.club_id
        );

    const getFilteredClubPlayers = (positionKey) => {
        const search = String(
            playerSearch[positionKey] || ""
        )
            .trim()
            .toLowerCase();

        const filteredPlayers = search
            ? clubPlayers.filter(player => {
                  const bsaNumber = String(player.bsa_number || "").toLowerCase();
                  const name = playerName(player).toLowerCase();

                  return (
                      bsaNumber.includes(search) ||
                      name.includes(search)
                  );
              })
            : clubPlayers;

        // Sort by the player's given name first: nickname when one is set,
        // otherwise first name. Then use surname as a tie-breaker. This keeps
        // the dropdown in true Firstname/Nickname alphabetical order instead
        // of sorting by BSA number or the full display string.
        return [...filteredPlayers].sort((a, b) => {
            const getGivenName = (player) =>
                String(player?.nickname || player?.first_name || "")
                    .trim()
                    .toLocaleLowerCase();

            const getSurname = (player) =>
                String(player?.last_name || "")
                    .trim()
                    .toLocaleLowerCase();

            const givenNameCompare = getGivenName(a).localeCompare(
                getGivenName(b),
                undefined,
                { sensitivity: "base", numeric: true }
            );

            if (givenNameCompare !== 0) return givenNameCompare;

            return getSurname(a).localeCompare(
                getSurname(b),
                undefined,
                { sensitivity: "base", numeric: true }
            );
        });
    };

    const handlePlayerSearchChange = (positionKey, value) => {
        setPlayerSearch(prev => ({
            ...prev,
            [positionKey]: value
        }));
    };

    /*
     * Get player display name.
     */
    const playerName = (player) => {
        if (!player) {
            return "—";
        }

        return getPlayerDisplayName(player) || "—";
    };

    /*
     * Return the players belonging to a competition team in their configured
     * position order.
     */
    const getTeamPlayerNames = (team) => {
        if (!team) return [];

        return (team.competition_team_players || [])
            .slice()
            .sort((a, b) => (a.position_order || 0) - (b.position_order || 0))
            .map(item => playerName(item.players))
            .filter(name => name && name !== "—");
    };

    /*
     * Generate the automatic competition team name.
     *
     * If the secretary leaves Team Name blank, the name becomes the club
     * short code followed by that club's sequence number, e.g. HBC1, HBC2.
     * The sequence is based on the team's order within that club, not the
     * overall competition team number.
     */
    const getTeamBaseName = (team, allTeams = teams) => {
        if (!team) return "TBD";

        const explicitName = team.team_name?.trim();
        if (explicitName) return explicitName;

        const clubCode =
            team.clubs?.short_name?.trim() ||
            team.club_short_name?.trim() ||
            team.clubs?.name?.trim() ||
            team.clubName?.trim() ||
            "TEAM";

        const clubTeams = (allTeams || [])
            .filter(item => item?.club_id && team.club_id && item.club_id === team.club_id)
            .slice()
            .sort((a, b) => {
                const numberA = a.team_number || 0;
                const numberB = b.team_number || 0;
                if (numberA !== numberB) return numberA - numberB;
                return String(a.id || "").localeCompare(String(b.id || ""));
            });

        const sequenceIndex = clubTeams.findIndex(item => item.id === team.id);
        const sequenceNumber = sequenceIndex >= 0
            ? sequenceIndex + 1
            : clubTeams.length + 1;

        // If a club has no short code, use its name as a last resort.
        // This keeps the generated name useful without requiring database
        // changes for clubs that pre-date the short-code field.
        const fallbackCode = clubCode === "TEAM"
            ? (team.team_number ? "TEAM" : "TEAM")
            : clubCode;

        return `${fallbackCode}${sequenceNumber}`;
    };

    /*
     * Plain-text team name used where a string is required by the draw/result
     * logic. Visual team labels should use TeamDisplay below so player names
     * can be rendered in a smaller font.
     */
    
    // Entry label for section management dropdowns. Keep the team identifier
    // visible, but include the roster so secretaries can identify players.
    const getSectionEntryOptionLabel = (team) => {
        if (!team) return "Unknown entry";

        const teamName = getTeamBaseName(team);
        const roster = (team.competition_team_players || [])
            .slice()
            .sort((a, b) => (a.position_order || 0) - (b.position_order || 0))
            .map(item => {
                const player = item.players || item.player || {};
                const name = player.display_name?.trim()
                    || [player.nickname?.trim() || player.first_name?.trim(), player.last_name?.trim()]
                        .filter(Boolean)
                        .join(" ");
                return name;
            })
            .filter(Boolean);

        const clubCode = team.clubs?.short_name?.trim()
            || team.club_short_name?.trim()
            || team.clubs?.name?.trim()
            || "";

        const rosterLabel = roster.length ? roster.join(" / ") : "No players listed";
        return `${teamName} — ${rosterLabel}${clubCode ? ` (${clubCode})` : ""}`;
    };

const getTeamDisplayName = (team) => {
        return getTeamBaseName(team);
    };

    /*
     * Consistent visual team label: generated/custom team name in the normal
     * font, followed by all players in a smaller muted font.
     */
    const TeamDisplay = ({ team, className = "" }) => {
        if (!team) return <span className={className}>TBD</span>;

        const sourceTeam = teams.find(item => item.id === team.id) || team;
        const baseName = getTeamBaseName(sourceTeam, teams);
        const playerNames = getTeamPlayerNames(sourceTeam).length
            ? getTeamPlayerNames(sourceTeam)
            : (team.playerNames || []);

        return (
            <span className={className}>
                <strong>{baseName}</strong>
                {playerNames.length > 0 && (
                    <span className="small text-muted fw-normal ms-1">
                        ({playerNames.join(", ")})
                    </span>
                )}
            </span>
        );
    };

    /*
     * Competition format label.
     */
    const formatLabel = (format) => {
        const labels = {
            singles: "Singles",
            pairs: "Pairs",
            trips: "Trips",
            fours: "Fours"
        };

        return labels[format] || format;
    };

    /*
     * Competition structure label.
     */
    const structureLabel = (structure) => {
        const labels = {
            sectional: "Sectional",
            round_robin: "Round Robin",
            knockout: "Knockout"
        };

        return labels[structure] || structure;
    };

    /*
     * Team status badge.
     */
    const statusBadge = (status) => {
        const badges = {
            active: {
                className: "bg-success",
                label: "Active"
            },

            withdrawn: {
                className: "bg-secondary",
                label: "Withdrawn"
            },

            eliminated: {
                className: "bg-danger",
                label: "Eliminated"
            }
        };

        const badge =
            badges[status] ||
            badges.active;

        return (
            <span
                className={`badge ${badge.className}`}
            >
                {badge.label}
            </span>
        );
    };

    /*
     * Playing day status badge.
     */
    const dayStatusBadge = (status) => {
        const badges = {
            scheduled: {
                className: "bg-primary",
                label: "Scheduled"
            },

            in_progress: {
                className: "bg-warning text-dark",
                label: "In Progress"
            },

            completed: {
                className: "bg-success",
                label: "Completed"
            },

            cancelled: {
                className: "bg-danger",
                label: "Cancelled"
            }
        };

        const badge =
            badges[status] ||
            badges.scheduled;

        return (
            <span
                className={`badge ${badge.className}`}
            >
                {badge.label}
            </span>
        );
    };

    /*
     * Round status badge.
     */
    const roundStatusBadge = (status) => {
        const badges = {
            pending: {
                className: "bg-secondary",
                label: "Pending"
            },

            in_progress: {
                className: "bg-warning text-dark",
                label: "In Progress"
            },

            completed: {
                className: "bg-success",
                label: "Completed"
            }
        };

        const badge =
            badges[status] ||
            badges.pending;

        return (
            <span
                className={`badge ${badge.className}`}
            >
                {badge.label}
            </span>
        );
    };

    /*
     * Format date.
     */
    const formatDate = (dateString) => {
        if (!dateString) {
            return "—";
        }

        const date =
            new Date(
                `${dateString}T00:00:00`
            );

        return date.toLocaleDateString(
            "en-ZA",
            {
                weekday: "long",
                day: "2-digit",
                month: "long",
                year: "numeric"
            }
        );
    };

    /*
     * Final competition podium. Gold/Silver come from the completed final.
     * Bronze is shared by the two losing semi-finalists; no third-place match
     * is used to determine bronze.
     */
    const competitionPodium = (() => {
        if (competition?.status !== "completed" || !confirmedDraw?.matches?.length) return null;

        const matches = confirmedDraw.matches;
        const completedResult = match =>
            match?.completed === true &&
            match.team_a_id && match.team_b_id &&
            match.score_a !== null && match.score_a !== undefined && match.score_a !== "" &&
            match.score_b !== null && match.score_b !== undefined && match.score_b !== "" &&
            Number.isFinite(Number(match.score_a)) &&
            Number.isFinite(Number(match.score_b)) &&
            Number(match.score_a) !== Number(match.score_b);

        const roundName = match =>
            String(match?.round?.round_name || "").trim().toLowerCase();

        const finalMatches = matches.filter(match => {
            const name = roundName(match);
            return /final/.test(name) && !/semi|quarter|third.?place/.test(name);
        });
        const semiFinalMatches = matches.filter(match => /semi[\s-]*final/.test(roundName(match)));

        if (finalMatches.length !== 1 || !completedResult(finalMatches[0])) return null;

        const finalMatch = finalMatches[0];
        const finalWinnerId = Number(finalMatch.score_a) > Number(finalMatch.score_b)
            ? finalMatch.team_a_id : finalMatch.team_b_id;
        const finalRunnerUpId = finalWinnerId === finalMatch.team_a_id
            ? finalMatch.team_b_id : finalMatch.team_a_id;

        const bronzeTeamIds = semiFinalMatches
            .filter(completedResult)
            .map(match => Number(match.score_a) < Number(match.score_b)
                ? match.team_a_id : match.team_b_id)
            .filter(teamId => teamId !== finalWinnerId && teamId !== finalRunnerUpId);

        const uniqueBronzeIds = [...new Set(bronzeTeamIds)];
        if (uniqueBronzeIds.length !== 2) return null;

        const teamById = new Map(teams.map(team => [team.id, team]));
        const toPodiumTeam = teamId => {
            const team = teamById.get(teamId);
            if (!team) return null;
            const teamName = team.team_name?.trim() ||
                `${team.clubs?.short_name || team.clubs?.name || "Team"} ${team.team_number || ""}`.trim();
            return {
                id: team.id,
                name: teamName,
                clubName: team.clubs?.name || team.clubs?.short_name || "",
                playerNames: getTeamPlayerNames(team)
            };
        };

        const gold = toPodiumTeam(finalWinnerId);
        const silver = toPodiumTeam(finalRunnerUpId);
        const bronze = uniqueBronzeIds.map(toPodiumTeam).filter(Boolean);
        if (!gold || !silver || bronze.length !== 2) return null;

        return { gold, silver, bronze };
    })();

    /*
     * Loading.
     */
    if (loading) {
        return (
            <div className="container-fluid py-5">
                <div className="text-center">

                    <div
                        className="spinner-border text-primary"
                    ></div>

                    <div className="text-muted mt-3">
                        Loading competition...
                    </div>

                </div>
            </div>
        );
    }

    /*
     * Competition not found.
     */
    if (!competition) {
        return (
            <div className="container-fluid py-5">
                <div className="text-center">

                    <i className="bi bi-exclamation-triangle display-4 text-warning"></i>

                    <h4 className="mt-3">
                        Competition not found
                    </h4>

                    <button
                        className="btn btn-primary mt-3"
                        onClick={() =>
                            navigate("/competitions")
                        }
                    >
                        Back to Competitions
                    </button>

                </div>
            </div>
        );
    }

    const positions =
        getPositions(
            competition.format
        );

    // In Singles, a player receiving a bye is assigned marking duties.
    // Team formats retain the normal BYE wording.
    const byeDisplayLabel = String(competition?.format || "").toLowerCase() === "singles"
        ? "MARK"
        : "BYE";

    // For team selection, show bowling positions in the order a team is
    // normally built from the skip backwards: Skip, Third, Second, Lead.
    // Pairs therefore naturally become Skip, Lead. Keep the canonical
    // position order above unchanged for saving/database/display logic.
    const playerSelectionPositions = [...positions].sort(
        (a, b) => b.order - a.order
    );

    const handleExportDrawPdf = async (includeRinkAllocations) => {
        try {
            let exportDraw = confirmedDraw;

            // Venue assignments are independent of rink allocations. Load the
            // approved section host clubs for BOTH PDF versions so the no-rinks
            // export still shows where each sectional round is being played.
            const { data: sectionVenueRows, error: sectionVenuesError } = await supabase
                .from("competition_section_venues")
                .select("section_id,club_id,clubs(id,name,short_name)")
                .eq("competition_id", competitionId);
            if (sectionVenuesError) throw sectionVenuesError;

            const sectionVenueById = new Map(
                (sectionVenueRows || []).map(row => [String(row.section_id), row.clubs || null])
            );

            exportDraw = {
                ...confirmedDraw,
                matches: (confirmedDraw.matches || []).map(match => ({
                    ...match,
                    section_venue: match.section_id
                        ? sectionVenueById.get(String(match.section_id)) || null
                        : null
                }))
            };

            if (includeRinkAllocations) {
                // Only fetch facility data when the user requests the allocated version.
                const { data: bookings, error: bookingsError } = await supabase
                    .from("facility_bookings")
                    .select("match_id,competition_id,green_id,rink_id,playing_date,session_name,direction,status")
                    .eq("competition_id", competitionId)
                    .neq("status", "cancelled");
                if (bookingsError) throw bookingsError;

                const activeBookings = bookings || [];
                const greenIds = [...new Set(activeBookings.map(item => item.green_id).filter(Boolean))];
                const rinkIds = [...new Set(activeBookings.map(item => item.rink_id).filter(Boolean))];
                const [greensResult, rinksResult] = await Promise.all([
                    greenIds.length
                        ? supabase.from("club_greens").select("id,name,club_id,clubs(id,short_name,name)").in("id", greenIds)
                        : Promise.resolve({ data: [], error: null }),
                    rinkIds.length
                        ? supabase.from("green_rinks").select("id,green_id,label").in("id", rinkIds)
                        : Promise.resolve({ data: [], error: null })
                ]);
                if (greensResult.error) throw greensResult.error;
                if (rinksResult.error) throw rinksResult.error;

                const greenById = new Map((greensResult.data || []).map(item => [String(item.id), item]));
                const rinkById = new Map((rinksResult.data || []).map(item => [String(item.id), item]));
                const bookingByMatchId = new Map(activeBookings.map(item => [String(item.match_id), item]));

                exportDraw = {
                    ...confirmedDraw,
                    matches: (confirmedDraw.matches || []).map(match => {
                        const booking = bookingByMatchId.get(String(match.id));
                        if (!booking) return match;
                        const green = greenById.get(String(booking.green_id)) || null;
                        const rink = rinkById.get(String(booking.rink_id)) || null;
                        return {
                            ...match,
                            facility_booking: {
                                ...booking,
                                green,
                                rink,
                                rink_label: rink?.label || rink?.name || "",
                                green_label: green?.name || "",
                                club: green?.clubs || null
                            }
                        };
                    })
                };
            }

            exportCompetitionFixturesPdf({
                competition,
                confirmedDraw: exportDraw,
                playingDays,
                sectionRoundDateOverrides,
                includeRinkAllocations
            });
        } catch (error) {
            console.error("Download Draw PDF failed:", error);
            window.alert(`Unable to download the draw PDF: ${error?.message || "An unexpected error occurred."}`);
        }
    };

    return (
        <>
            <style>{`
                .workspace-progress { position: sticky; top: 12px; z-index: 20; }
                .workspace-stage-card { scroll-margin-top: 110px; transition: box-shadow .2s ease, opacity .2s ease; }
                /* The sticky Competition Progress bar is tall enough to cover the top of
                   the Teams card when its generic scroll offset is used. Give the Teams
                   section its own larger offset so the full header and Add Team button
                   are visible after navigation/saving. */
                #workspace-teams { scroll-margin-top: 180px; }
                .workspace-stage-card.workspace-collapsed > .card-body { display: none; }
                .workspace-stage-card.workspace-collapsed > .card-header { border-bottom: 0; }
                .workspace-stage-card.workspace-collapsed { opacity: .86; }
                .workspace-section-collapsed .table-responsive { display: none; }
                .workspace-section-collapsed { opacity: .92; }
            `}</style>
            <div className="container-fluid py-4">

            {/* Back */}

            <button
                type="button"
                className="btn btn-link text-decoration-none px-0 mb-3"
                onClick={() =>
                    navigate("/competitions")
                }
            >

                <i className="bi bi-arrow-left me-2"></i>

                Back to Competitions

            </button>


            {/* Header */}

            <div className="d-flex justify-content-between align-items-start mb-4">

                <div>

                    <h1 className="mb-1">
                        {competition.name}
                    </h1>

                    <div className="text-muted">

                        {formatLabel(
                            competition.format
                        )}

                        {" • "}

                        {structureLabel(
                            competition.structure
                        )}

                        {competition.start_date && (
                            <>
                                {" • "}
                                {formatDate(
                                    competition.start_date
                                )}

                                {competition.end_date && (
                                    <>
                                        {" – "}
                                        {formatDate(
                                            competition.end_date
                                        )}
                                    </>
                                )}
                            </>
                        )}

                    </div>

                </div>

                <span className="badge bg-secondary fs-6">

                    {competition.status === "draft"
                        ? "Draft"
                        : competition.status
                    }

                </span>

            </div>


            {competitionPodium && (
                <div className="card shadow-sm border-0 mb-4">
                    <div className="card-header bg-white">
                        <div className="fw-semibold">Competition Results</div>
                        <div className="small text-muted">Final standings — Gold, Silver and shared Bronze</div>
                    </div>
                    <div className="card-body">
                        <div className="row g-3 align-items-stretch">
                            {[
                                { medal: "Gold", icon: "bi-award-fill", tone: "text-warning", team: competitionPodium.gold },
                                { medal: "Silver", icon: "bi-award-fill", tone: "text-secondary", team: competitionPodium.silver },
                                ...competitionPodium.bronze.map((team, index) => ({
                                    medal: "Bronze",
                                    icon: "bi-award-fill",
                                    tone: "text-danger",
                                    team,
                                    key: `bronze-${index}`
                                }))
                            ].map((place, index) => (
                                <div className="col-12 col-sm-6 col-xl-3" key={place.key || place.medal}>
                                    <div className="border rounded p-3 h-100 d-flex align-items-center gap-3">
                                        <i className={`bi ${place.icon} ${place.tone}`} style={{ fontSize: "2rem" }}></i>
                                        <div className="min-w-0">
                                            <div className="small text-muted fw-semibold">{place.medal}</div>
                                            <div className="fw-bold text-break">{place.team.name}</div>
                                            {place.team.clubName && <div className="small text-muted">{place.team.clubName}</div>}
                                            {place.team.playerNames.length > 0 && (
                                                <div className="small mt-1">{place.team.playerNames.join(", ")}</div>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            )}

            {/* Progressive workspace navigation */}
            <div className="card shadow-sm border-0 mb-4 workspace-progress" id="workspace-progress">
                <div className="card-body py-3">
                    <div className="d-flex flex-wrap align-items-center justify-content-between gap-3">
                        <div>
                            <div className="fw-semibold">Competition Progress</div>
                            <div className="small text-muted">Next action: <strong>{workspaceStageInfo[workspaceStage]?.label || "Setup"}</strong></div>
                        </div>
                        <button type="button" className="btn btn-sm btn-outline-secondary" onClick={() => setShowSetupDetails(value => !value)}>
                            <i className={`bi ${showSetupDetails ? "bi-arrows-collapse" : "bi-arrows-expand"} me-1`}></i>
                            {showSetupDetails ? "Collapse setup" : "Show setup"}
                        </button>
                    </div>
                    <div className="d-flex flex-wrap align-items-center gap-1 mt-3">
                        {["teams", "draw", "schedule", "scoring", "playoffs"].map((stage, index) => {
                            const info = workspaceStageInfo[stage];
                            const active = workspaceStage === stage;
                            const stageOrder = ["teams", "draw", "schedule", "scoring", "playoffs"];
                            const completed = stageOrder.indexOf(stage) < stageOrder.indexOf(workspaceStage);
                            return (
                                <div key={stage} className="d-flex align-items-center">
                                    {index > 0 && <i className="bi bi-chevron-right text-muted mx-1"></i>}
                                    <button type="button" className={`btn btn-sm ${active ? "btn-primary" : completed ? "btn-outline-success" : "btn-outline-secondary"}`} onClick={() => focusWorkspaceStage(stage)}>
                                        <i className={`bi ${info.icon} me-1`}></i>{info.label}
                                        {completed && <i className="bi bi-check-lg ms-1"></i>}
                                    </button>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </div>

            {confirmedDraw && (
                <div className="d-flex justify-content-end mb-3">
                    <button
                        type="button"
                        className="btn btn-outline-primary"
                        onClick={() => {
                            setShowSetupDetails(true);
                            setShowSectionManager(true);
                            window.setTimeout(() => {
                                document.getElementById("manage-section-entries")?.scrollIntoView({
                                    behavior: "smooth",
                                    block: "start"
                                });
                            }, 100);
                        }}
                    >
                        <i className="bi bi-arrow-left-right me-2"></i>
                        Manage Section Entries
                    </button>
                </div>
            )}

            {/* Overview */}

            <div className="row g-3 mb-4">

                <div className="col-md-3">

                    <div className="card shadow-sm border-0 h-100">

                        <div className="card-body">

                            <div className="text-muted small">
                                Participating Clubs
                            </div>

                            <div className="fs-2 fw-bold">
                                {participatingClubs.length}
                            </div>

                        </div>

                    </div>

                </div>


                <div className="col-md-3">

                    <div className="card shadow-sm border-0 h-100">

                        <div className="card-body">

                            <div className="text-muted small">
                                Teams
                            </div>

                            <div className="fs-2 fw-bold">
                                {teams.length}
                            </div>

                        </div>

                    </div>

                </div>


                <div className="col-md-3">

                    <div className="card shadow-sm border-0 h-100">

                        <div className="card-body">

                            <div className="text-muted small">
                                Draw Status
                            </div>

                            <div className="fs-4 fw-bold">
                                {confirmedDraw ? "Confirmed" : drawProposal ? "Proposed" : "Not generated"}
                            </div>

                        </div>

                    </div>

                </div>


                <div className="col-md-3">

                    <div className="card shadow-sm border-0 h-100">

                        <div className="card-body">

                            <div className="text-muted small">
                                Required Rounds
                            </div>

                            <div className="fs-2 fw-bold">
                                {confirmedDraw?.rounds?.length ?? drawProposal?.recommendedPlan?.totalRounds ?? "—"}
                            </div>

                        </div>

                    </div>

                </div>

            </div>


            {/* Scorecards required, calculated from saved fixtures and approved host venues */}
            {confirmedDraw && (
                <div className="card shadow-sm border-0 mb-4">
                    <div className="card-header bg-white">
                        <h5 className="mb-1">Scorecards Required</h5>
                        <div className="text-muted small">
                            One scorecard per fixture, grouped by the saved host club.
                        </div>
                    </div>
                    <div className="card-body">
                        {scorecardSummary.clubs.length ? (
                            <>
                                <div className="row g-3">
                                    {scorecardSummary.clubs.map(club => (
                                        <div className="col-sm-6 col-lg-4" key={club.clubId}>
                                            <div className="border rounded p-3 h-100 d-flex justify-content-between align-items-center gap-3">
                                                <span>{club.clubName}</span>
                                                <span className="fs-3 fw-bold">{club.count}</span>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                                <div className="d-flex justify-content-between align-items-center border-top mt-3 pt-3">
                                    <span className="fw-semibold">Total scorecards required</span>
                                    <span className="fs-2 fw-bold">{scorecardSummary.total}</span>
                                </div>
                                {scorecardSummary.unassigned > 0 && (
                                    <div className="alert alert-warning mt-3 mb-0">
                                        {scorecardSummary.unassigned} fixture(s) have both teams assigned but no saved host venue, so they are not included in the club totals yet.
                                    </div>
                                )}
                            </>
                        ) : (
                            <div className="text-muted">
                                No scorecard totals are available yet. Approve the section host clubs and assign venues to any playoff rounds to calculate the totals.
                            </div>
                        )}
                    </div>
                </div>
            )}

            {/* Players by Club */}

            <div className="card shadow-sm border-0 mb-4">

                <div className="card-header bg-white d-flex justify-content-between align-items-center">
                    <div>
                        <h5 className="mb-0">
                            <i className="bi bi-people me-2"></i>
                            Players by Club
                        </h5>
                        <div className="small text-muted mt-1">
                            Players currently entered into competition teams.
                        </div>
                    </div>
                </div>

                <div className="card-body py-3">
                    {clubPlayerCounts.length === 0 ? (
                        <div className="text-muted small">
                            No participating clubs have been added yet.
                        </div>
                    ) : (
                        <div className="row g-3">
                            {clubPlayerCounts.map(club => (
                                <div className="col-sm-6 col-lg-4 col-xl-3" key={club.clubId}>
                                    <div className="border rounded p-3 h-100 d-flex justify-content-between align-items-center">
                                        <div className="me-3">
                                            <div className="fw-semibold">{club.name}</div>
                                            {club.shortName && (
                                                <div className="small text-muted">{club.shortName}</div>
                                            )}
                                        </div>
                                        <div className="text-end">
                                            <div className="fs-4 fw-bold">{club.playerCount}</div>
                                            <div className="small text-muted">players</div>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

            </div>


            {/* Participating Clubs */}

            <div id="workspace-clubs" className={`card shadow-sm border-0 mb-4 workspace-stage-card ${!showSetupDetails && confirmedDraw && workspaceStage !== "teams" ? "workspace-collapsed" : ""}`}>

                <div className="card-header bg-white d-flex justify-content-between align-items-center">

                    <div>

                        <h5 className="mb-0">

                            <i className="bi bi-buildings me-2"></i>

                            Participating Clubs

                        </h5>

                        <div className="small text-muted mt-1">
                            Clubs entering teams into this competition.
                        </div>

                    </div>


                    <button
                        type="button"
                        className="btn btn-primary"
                        onClick={() => {

                            setSelectedClubIds([]);

                            setShowClubForm(
                                !showClubForm
                            );

                        }}
                    >

                        <i className="bi bi-plus-lg me-2"></i>

                        Add Club

                    </button>

                </div>


                {showClubForm && (
                    <div className="card-body border-bottom">

                        <div className="row g-2 align-items-end">

                            <div className="col-md-8">

                                <label className="form-label">
                                    Select Clubs
                                </label>

                                {availableClubs.length === 0 ? (
                                    <div className="text-muted small border rounded p-3">
                                        All available clubs have already been added to this competition.
                                    </div>
                                ) : (
                                    <div className="border rounded p-3">

                                        <div className="d-flex justify-content-between align-items-center mb-2">
                                            <span className="small text-muted">
                                                Select one or more clubs to add together.
                                            </span>

                                            <button
                                                type="button"
                                                className="btn btn-sm btn-outline-secondary"
                                                onClick={() => {
                                                    if (selectedClubIds.length === availableClubs.length) {
                                                        setSelectedClubIds([]);
                                                    } else {
                                                        setSelectedClubIds(
                                                            availableClubs.map(club => club.id)
                                                        );
                                                    }
                                                }}
                                                disabled={saving}
                                            >
                                                {selectedClubIds.length === availableClubs.length
                                                    ? "Clear all"
                                                    : "Select all"}
                                            </button>
                                        </div>

                                        <div className="row g-2">
                                            {availableClubs.map(club => (
                                                <div
                                                    key={club.id}
                                                    className="col-12 col-md-6"
                                                >
                                                    <div className="form-check">
                                                        <input
                                                            id={`competition-club-${club.id}`}
                                                            className="form-check-input"
                                                            type="checkbox"
                                                            checked={selectedClubIds.includes(club.id)}
                                                            onChange={() => {
                                                                setSelectedClubIds(prev =>
                                                                    prev.includes(club.id)
                                                                        ? prev.filter(id => id !== club.id)
                                                                        : [...prev, club.id]
                                                                );
                                                            }}
                                                            disabled={saving}
                                                        />

                                                        <label
                                                            className="form-check-label"
                                                            htmlFor={`competition-club-${club.id}`}
                                                        >
                                                            {club.name}
                                                        </label>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>

                                    </div>
                                )}

                            </div>


                            <div className="col-md-4">

                                <button
                                    type="button"
                                    className="btn btn-success me-2"
                                    onClick={handleAddClub}
                                    disabled={saving || selectedClubIds.length === 0}
                                >

                                    {saving ? (
                                        <>
                                            <span
                                                className="spinner-border spinner-border-sm me-2"
                                            ></span>

                                            Adding...
                                        </>
                                    ) : (
                                        <>
                                            <i className="bi bi-check-lg me-2"></i>
                                            Add {selectedClubIds.length || "Selected"} Club{selectedClubIds.length === 1 ? "" : "s"}
                                        </>
                                    )}

                                </button>


                                <button
                                    type="button"
                                    className="btn btn-outline-secondary"
                                    onClick={() => {
                                        setSelectedClubIds([]);
                                        setShowClubForm(false);
                                    }}
                                    disabled={saving}
                                >
                                    Cancel
                                </button>

                            </div>

                        </div>

                    </div>
                )}


                <div className="card-body p-0">

                    {participatingClubs.length === 0 ? (

                        <div className="text-center py-5">

                            <i
                                className="bi bi-buildings display-4 text-muted"
                            ></i>

                            <h5 className="mt-3">
                                No clubs added yet
                            </h5>

                            <p className="text-muted mb-0">
                                Add the clubs that will be entering teams.
                            </p>

                        </div>

                    ) : (

                        <div className="table-responsive">

                            <table className="table table-hover mb-0">

                                <thead>

                                    <tr>

                                        <th>
                                            Club
                                        </th>

                                        <th>
                                            Short Name
                                        </th>

                                        <th className="text-end">
                                            Action
                                        </th>

                                    </tr>

                                </thead>

                                <tbody>

                                    {participatingClubs.map(
                                        entry => (

                                            <tr key={entry.id}>

                                                <td>
                                                    <strong>
                                                        {entry.clubs?.name ||
                                                            "Unknown Club"}
                                                    </strong>
                                                </td>

                                                <td>
                                                    {entry.clubs?.short_name ||
                                                        "—"}
                                                </td>

                                                <td className="text-end">

                                                    <button
                                                        type="button"
                                                        className="btn btn-sm btn-outline-danger"
                                                        onClick={() =>
                                                            handleRemoveClub(
                                                                entry
                                                            )
                                                        }
                                                    >

                                                        <i className="bi bi-trash me-1"></i>

                                                        Remove

                                                    </button>

                                                </td>

                                            </tr>

                                        )
                                    )}

                                </tbody>

                            </table>

                        </div>

                    )}

                </div>

            </div>


            {/* Competition Teams */}

            <div id="workspace-teams" className={`card shadow-sm border-0 mb-4 workspace-stage-card ${!showSetupDetails && confirmedDraw && workspaceStage !== "teams" ? "workspace-collapsed" : ""}`}>

                <div className="card-header bg-white d-flex justify-content-between align-items-center">

                    <div>

                        <h5 className="mb-0">

                            <i className="bi bi-people-fill me-2"></i>

                            Competition Teams

                        </h5>

                        <div className="small text-muted mt-1">
                            Build teams from registered players.
                        </div>

                    </div>


                    <button
                        type="button"
                        className="btn btn-primary"
                        onClick={handleAddTeam}
                        disabled={
                            participatingClubs.length === 0
                        }
                    >

                        <i className="bi bi-plus-lg me-2"></i>

                        Add Team

                    </button>

                </div>


                {showTeamForm && (

                    <div
                        id="workspace-team-form"
                        className="card-body border-bottom"
                    >

                        <form onSubmit={handleSaveTeam}>

                            <h6 className="text-primary mb-3">
                                {editingTeam
                                    ? (confirmedDraw ? `Edit / Replace Team ${editingTeam.team_number}` : `Edit Team ${editingTeam.team_number}`)
                                    : "Add Competition Team"
                                }
                            </h6>

                            {editingTeam && confirmedDraw && (
                                <div className="alert alert-warning" role="note">
                                    <strong>Draw already confirmed.</strong> You can replace one or more players, or replace this whole team by changing its club and players. The existing team number, section, opponents, dates, venues and rink bookings are retained. Saving a withdrawn team reactivates it in the same draw position. Review the change carefully before saving.
                                </div>
                            )}

                            <div className="row g-3 mb-4">

                                <div className="col-md-6">

                                    <label className="form-label">
                                        Club
                                    </label>

                                    <select
                                        name="club_id"
                                        className="form-select"
                                        value={teamForm.club_id}
                                        onChange={handleTeamFormChange}
                                        required
                                    >

                                        <option value="">
                                            Select club...
                                        </option>

                                        {participatingClubs.map(
                                            entry => (

                                                <option
                                                    key={entry.club_id}
                                                    value={entry.club_id}
                                                >

                                                    {entry.clubs?.name}

                                                </option>

                                            )
                                        )}

                                    </select>

                                </div>


                                <div className="col-md-6">

                                    <label className="form-label">
                                        Team Name
                                        <span className="text-muted">
                                            {" "} (optional)
                                        </span>
                                    </label>

                                    <input
                                        type="text"
                                        name="team_name"
                                        className="form-control"
                                        placeholder={`e.g. ${competition.name} Team`}
                                        value={teamForm.team_name}
                                        onChange={handleTeamFormChange}
                                    />

                                </div>

                            </div>


                            <h6 className="text-primary mb-3">
                                Players
                            </h6>


                            <div className="row g-3">

                                {playerSelectionPositions.map(position => {

                                    const selectedPlayerId =
                                        teamForm.players[
                                            position.key
                                        ] || "";

                                    return (
                                        <div
                                            className="col-md-6"
                                            key={position.key}
                                        >

                                            <label className="form-label">
                                                {position.label}
                                            </label>

                                            <div className="input-group mb-2">
                                                <span className="input-group-text">
                                                    <i className="bi bi-search"></i>
                                                </span>
                                                <input
                                                    type="text"
                                                    className="form-control"
                                                    placeholder="Search by BSA number or name..."
                                                    value={playerSearch[position.key] || ""}
                                                    onChange={(e) =>
                                                        handlePlayerSearchChange(
                                                            position.key,
                                                            e.target.value
                                                        )
                                                    }
                                                    disabled={!teamForm.club_id}
                                                />
                                            </div>

                                            {teamForm.club_id && String(playerSearch[position.key] || "").trim() ? (
                                                <div
                                                    className="list-group mt-2"
                                                    style={{
                                                        maxHeight: "220px",
                                                        overflowY: "auto"
                                                    }}
                                                >
                                                    {getFilteredClubPlayers(position.key)
                                                        .filter(player =>
                                                            !Object.entries(teamForm.players).some(
                                                                ([key, value]) =>
                                                                    key !== position.key &&
                                                                    value === player.id
                                                            )
                                                        )
                                                        .map(player => (
                                                            <button
                                                                key={player.id}
                                                                type="button"
                                                                className="list-group-item list-group-item-action d-flex justify-content-between align-items-center"
                                                                onClick={() => {
                                                                    handlePlayerChange(position.key, player.id);
                                                                    setPlayerSearch(prev => ({
                                                                        ...prev,
                                                                        [position.key]: ""
                                                                    }));
                                                                }}
                                                            >
                                                                <span>{playerName(player)}</span>
                                                                {player.bsa_number ? (
                                                                    <small className="text-muted">
                                                                        {player.bsa_number}
                                                                    </small>
                                                                ) : null}
                                                            </button>
                                                        ))}

                                                    {getFilteredClubPlayers(position.key).filter(player =>
                                                        !Object.entries(teamForm.players).some(
                                                            ([key, value]) =>
                                                                key !== position.key &&
                                                                value === player.id
                                                        )
                                                    ).length === 0 && (
                                                        <div className="list-group-item text-muted">
                                                            No matching players found.
                                                        </div>
                                                    )}
                                                </div>
                                            ) : (
                                            <select
                                                className="form-select"
                                                value={selectedPlayerId}
                                                onChange={(e) =>
                                                    handlePlayerChange(
                                                        position.key,
                                                        e.target.value
                                                    )
                                                }
                                                disabled={
                                                    !teamForm.club_id
                                                }
                                                required
                                            >

                                                <option value="">

                                                    {teamForm.club_id
                                                        ? `Select ${position.label.toLowerCase()}...`
                                                        : "Select club first..."
                                                    }

                                                </option>


                                                {getFilteredClubPlayers(position.key).map(
                                                    player => {

                                                        const alreadySelected =
                                                            Object.entries(
                                                                teamForm.players
                                                            ).some(
                                                                ([key, value]) =>
                                                                    key !==
                                                                        position.key &&
                                                                    value ===
                                                                        player.id
                                                            );

                                                        return (
                                                            <option
                                                                key={player.id}
                                                                value={player.id}
                                                                disabled={
                                                                    alreadySelected
                                                                }
                                                            >
                                                                {player.bsa_number
                                                                    ? `${player.bsa_number} — ${playerName(player)}`
                                                                    : playerName(player)}
                                                            </option>
                                                        );

                                                    }
                                                )}

                                            </select>
                                            )}

                                        </div>
                                    );

                                })}

                            </div>


                            {teamForm.club_id &&
                                clubPlayers.length === 0 && (

                                    <div className="alert alert-warning mt-3 mb-0">

                                        <i className="bi bi-exclamation-triangle me-2"></i>

                                        There are no active registered players
                                        for this club (including players who have it as their second club).

                                    </div>

                                )}


                            <div className="d-flex justify-content-end gap-2 mt-4">

                                <button
                                    type="button"
                                    className="btn btn-outline-secondary"
                                    onClick={() => {

                                        setShowTeamForm(false);
                                        resetTeamForm();

                                    }}
                                    disabled={saving}
                                >
                                    Cancel
                                </button>


                                <button
                                    type="submit"
                                    className="btn btn-success"
                                    disabled={saving}
                                >

                                    {saving ? (
                                        <>
                                            <span
                                                className="spinner-border spinner-border-sm me-2"
                                            ></span>

                                            Saving...
                                        </>
                                    ) : (
                                        <>
                                            <i className="bi bi-check-lg me-2"></i>

                                            {editingTeam
                                                ? "Save Changes"
                                                : "Save Team"
                                            }
                                        </>
                                    )}

                                </button>

                            </div>

                        </form>

                    </div>

                )}


                <div className="card-body p-0">

                    {teams.length === 0 ? (

                        <div className="text-center py-5">

                            <i
                                className="bi bi-people display-4 text-muted"
                            ></i>

                            <h5 className="mt-3">
                                No teams created yet
                            </h5>

                            <p className="text-muted mb-0">
                                Add teams using registered players from the participating clubs.
                            </p>

                        </div>

                    ) : (

                        <div className="table-responsive">

                            <table className="table table-hover mb-0">

                                <thead>

                                    <tr>

                                        <th>
                                            Team
                                        </th>

                                        <th>
                                            Club
                                        </th>

                                        {positions.map(
                                            position => (
                                                <th
                                                    key={position.key}
                                                >
                                                    {position.label}
                                                </th>
                                            )
                                        )}

                                        <th>
                                            Status
                                        </th>

                                        <th className="text-end">
                                            Action
                                        </th>

                                    </tr>

                                </thead>


                                <tbody>

                                    {teams.map(team => (

                                        <tr
                                            key={team.id}
                                        >

                                            <td>

                                                <TeamDisplay team={team} />

                                                {team.team_name && (
                                                    <div className="small text-muted mt-1">
                                                        Team {team.team_number}
                                                    </div>
                                                )}

                                            </td>


                                            <td>

                                                {team.clubs?.short_name ||
                                                    team.clubs?.name ||
                                                    "—"}

                                            </td>


                                            {positions.map(
                                                position => {

                                                    const player =
                                                        (
                                                            team.competition_team_players ||
                                                            []
                                                        ).find(
                                                            item =>
                                                                item.position ===
                                                                position.key
                                                        )?.players;

                                                    return (
                                                        <td
                                                            key={
                                                                position.key
                                                            }
                                                        >
                                                            {playerName(
                                                                player
                                                            )}
                                                        </td>
                                                    );

                                                }
                                            )}


                                            <td>

                                                {statusBadge(
                                                    team.status
                                                )}

                                            </td>


                                            <td className="text-end">

                                                <div className="d-flex justify-content-end gap-1">

                                                    <button
                                                        type="button"
                                                        className="btn btn-sm btn-outline-primary"
                                                        onClick={() =>
                                                            handleEditTeam(
                                                                team
                                                            )
                                                        }
                                                    >

                                                        <i className="bi bi-pencil me-1"></i>

                                                        Edit

                                                    </button>


                                                    {team.status === "active" && (

                                                        <button
                                                            type="button"
                                                            className="btn btn-sm btn-outline-warning"
                                                            onClick={() =>
                                                                handleChangeTeamStatus(
                                                                    team,
                                                                    "withdrawn"
                                                                )
                                                            }
                                                        >

                                                            <i className="bi bi-box-arrow-right me-1"></i>

                                                            Withdraw

                                                        </button>

                                                    )}


                                                    {team.status !== "active" && (

                                                        <button
                                                            type="button"
                                                            className="btn btn-sm btn-outline-success"
                                                            onClick={() =>
                                                                handleChangeTeamStatus(
                                                                    team,
                                                                    "active"
                                                                )
                                                            }
                                                        >

                                                            <i className="bi bi-arrow-counterclockwise me-1"></i>

                                                            Activate

                                                        </button>

                                                    )}

                                                </div>

                                            </td>

                                        </tr>

                                    ))}

                                </tbody>

                            </table>

                        </div>

                    )}

                </div>

            </div>


            {confirmedDraw ? (
                <div id="workspace-draw-confirmed" className={`card shadow-sm border-0 mb-4 workspace-stage-card ${!showSetupDetails && !["draw"].includes(workspaceStage) ? "workspace-collapsed" : ""}`}>
                    <div className="card-header bg-white d-flex justify-content-between align-items-center">
                        <div><h5 className="mb-0"><i className="bi bi-check-circle-fill text-success me-2"></i>Draw Confirmed</h5><div className="small text-muted mt-1">This is the persisted draw loaded from the database.</div></div>
                        <span className="badge bg-success">Confirmed</span>
                    </div>
                    <div className="card-body">
                        <div className="row g-3 mb-4">
                            {[
                                ["Teams", teams.filter(t => t.status === "active").length],
                                ["Sections", confirmedDraw.sections.length],
                                ["Rounds", confirmedDraw.rounds.length],
                                ["Matches", confirmedDraw.matches.length]
                            ].map(([label,value]) => <div className="col-md-3" key={label}><div className="card border h-100"><div className="card-body"><div className="text-muted small">{label}</div><div className="fs-3 fw-bold">{value}</div></div></div></div>)}
                        </div>
                        <div className="alert alert-success"><strong>Draw is confirmed.</strong><div className="small mt-1">Sections, fixtures and playoff rounds below are read directly from Supabase. Dates and venues have not been assigned yet.</div></div>
                        <div id="manage-section-entries" className="card border mb-4" style={{ scrollMarginTop: "150px" }}>
                            <div className="card-header bg-white d-flex flex-wrap justify-content-between align-items-center gap-2">
                                <div>
                                    <strong><i className="bi bi-arrow-left-right me-2"></i>Manage Section Entries</strong>
                                    <div className="small text-muted mt-1">Swap or move entries, withdraw Singles entries or replace a player before scoring starts. Pairs, Trips and Fours retain their team identity when an individual player is replaced.</div>
                                </div>
                                <button type="button" className="btn btn-outline-primary btn-sm" onClick={() => setShowSectionManager(value => !value)}>
                                    {showSectionManager ? "Close" : "Open"}
                                </button>
                            </div>
                            {showSectionManager && <div className="card-body">
                                <div className="alert alert-warning py-2 small">
                                    Entry changes are available only before scoring starts. Select any entry in the section and replace its player; Singles entries do not need to be withdrawn first. Team identity is retained for Pairs, Trips and Fours. BowlPoint preserves round dates and fixture IDs. Review and rerun rink allocation afterwards to refresh team rink-repeat optimisation.
                                </div>
                                {sectionManagerMessage && <div className="alert alert-success py-2">{sectionManagerMessage}</div>}
                                <div className="btn-group btn-group-sm mb-3" role="group" aria-label="Section entry action">
                                    <button type="button" className={`btn ${sectionEntryAction === "swap" ? "btn-primary" : "btn-outline-primary"}`} onClick={() => setSectionEntryAction("swap")}>Swap Entries</button>
                                    <button type="button" className={`btn ${sectionEntryAction === "move" ? "btn-primary" : "btn-outline-primary"}`} onClick={() => { setSectionEntryAction("move"); setSwapTeamB(""); }}>Move Entry</button>
                                    <button type="button" className={`btn ${sectionEntryAction === "withdraw" ? "btn-primary" : "btn-outline-primary"}`} onClick={() => { setSectionEntryAction("withdraw"); setWithdrawSectionId(""); setWithdrawTeamId(""); }}>Withdraw Entry</button>
                                    <button type="button" className={`btn ${sectionEntryAction === "replacement" ? "btn-primary" : "btn-outline-primary"}`} onClick={() => { setSectionEntryAction("replacement"); setReplacementSectionId(""); setReplacementTeamId(""); setReplacementPlayerId(""); setReplacementPosition(""); }}>Add Replacement</button>
                                    <button type="button" className={`btn ${sectionEntryAction === "lateEntry" ? "btn-primary" : "btn-outline-primary"}`} onClick={() => { setSectionEntryAction("lateEntry"); setLateEntrySectionId(""); setLateEntryClubId(""); setLateEntryPlayers({}); setLateEntrySearch({}); setLateEntryPlayerModes({}); setLateEntryNewPlayers({}); }}>Add Late Entry</button>
                                </div>
                                {sectionEntryAction === "lateEntry" ? (
                                    <div className="border rounded p-3">
                                        <div className="alert alert-info py-2 small">
                                            Add a new entry to one section only. The club must already participate in this competition. Existing entries and other sections are not moved.
                                        </div>
                                        <div className="row g-3">
                                            <div className="col-md-4">
                                                <label className="form-label fw-semibold">Section</label>
                                                <select className="form-select" value={lateEntrySectionId} onChange={event => { setLateEntrySectionId(event.target.value); setLateEntryPlayers({}); }} disabled={savingLateEntry || hasCompetitionScoringStarted()}>
                                                    <option value="">Choose section</option>
                                                    {confirmedDraw.sections.map(section => <option key={section.id} value={section.id}>{section.section_name}</option>)}
                                                </select>
                                            </div>
                                            <div className="col-md-4">
                                                <label className="form-label fw-semibold">Participating club</label>
                                                <select className="form-select" value={lateEntryClubId} onChange={event => { setLateEntryClubId(event.target.value); setLateEntryPlayers({}); }} disabled={savingLateEntry || hasCompetitionScoringStarted()}>
                                                    <option value="">Choose club</option>
                                                    {participatingClubs.map(item => <option key={item.club_id} value={item.club_id}>{item.clubs?.name || clubs.find(club => club.id === item.club_id)?.name || item.club_id}</option>)}
                                                </select>
                                            </div>
                                        </div>
                                        {lateEntryClubId && <div className="row g-3 mt-1">
                                            {getPositions(competition.format).map(position => {
                                                const eligible = players.filter(player =>
                                                    (String(player.club_id || "") === String(lateEntryClubId) || String(player.second_club_id || "") === String(lateEntryClubId)) &&
                                                    !teams.some(team => (team.competition_team_players || []).some(row => String(row.player_id) === String(player.id))) &&
                                                    `${playerName(player)} ${player.bsa_number || ""}`.toLowerCase().includes((lateEntrySearch[position.key] || "").toLowerCase())
                                                );
                                                const mode = lateEntryPlayerModes[position.key] || "existing";
                                                const person = lateEntryNewPlayers[position.key] || {};
                                                return <div className="col-12 col-lg-6" key={position.key}>
                                                    <div className="border rounded p-3 h-100">
                                                        <div className="d-flex align-items-center justify-content-between mb-2">
                                                            <label className="form-label fw-semibold mb-0">{position.label}</label>
                                                            <div className="btn-group btn-group-sm" role="group">
                                                                <button type="button" className={`btn ${mode === "existing" ? "btn-primary" : "btn-outline-primary"}`} onClick={() => setLateEntryPlayerModes(prev => ({...prev, [position.key]: "existing"}))}>Existing player</button>
                                                                <button type="button" className={`btn ${mode === "new" ? "btn-primary" : "btn-outline-primary"}`} onClick={() => setLateEntryPlayerModes(prev => ({...prev, [position.key]: "new"}))}>Create player</button>
                                                            </div>
                                                        </div>
                                                        {mode === "existing" ? <>
                                                            <input className="form-control mb-2" value={lateEntrySearch[position.key] || ""} onChange={event => setLateEntrySearch(prev => ({...prev, [position.key]: event.target.value}))} placeholder={`Search ${position.label.toLowerCase()} by name or BSA number`} disabled={savingLateEntry}/>
                                                            <select className="form-select" value={lateEntryPlayers[position.key] || ""} onChange={event => setLateEntryPlayers(prev => ({...prev, [position.key]: event.target.value}))} disabled={savingLateEntry}>
                                                                <option value="">Choose player</option>
                                                                {eligible.map(player => <option key={player.id} value={player.id}>{playerName(player)}{player.bsa_number ? ` (${player.bsa_number})` : ""}</option>)}
                                                            </select>
                                                        </> : <div className="row g-2">
                                                            <div className="col-sm-6"><input className="form-control" value={person.first_name || ""} onChange={event => setLateEntryNewPlayers(prev => ({...prev, [position.key]: {...(prev[position.key] || {}), first_name: event.target.value}}))} placeholder="First name" disabled={savingLateEntry}/></div>
                                                            <div className="col-sm-6"><input className="form-control" value={person.last_name || ""} onChange={event => setLateEntryNewPlayers(prev => ({...prev, [position.key]: {...(prev[position.key] || {}), last_name: event.target.value}}))} placeholder="Surname" disabled={savingLateEntry}/></div>
                                                            <div className="col-sm-6"><input className="form-control" value={person.nickname || ""} onChange={event => setLateEntryNewPlayers(prev => ({...prev, [position.key]: {...(prev[position.key] || {}), nickname: event.target.value}}))} placeholder="Nickname (optional)" disabled={savingLateEntry}/></div>
                                                            <div className="col-sm-6"><input className="form-control" value={person.bsa_number || ""} onChange={event => setLateEntryNewPlayers(prev => ({...prev, [position.key]: {...(prev[position.key] || {}), bsa_number: event.target.value}}))} placeholder="BSA number (optional)" disabled={savingLateEntry}/></div>
                                                            <div className="col-12"><small className="text-muted">The new player will be added to the selected club and entered in this team in one database transaction.</small></div>
                                                        </div>}
                                                    </div>
                                                </div>;
                                            })}
                                        </div>}
                                        <div className="d-flex justify-content-end mt-3">
                                            <button type="button" className="btn btn-primary" onClick={handleAddLateEntry} disabled={savingLateEntry || hasCompetitionScoringStarted() || !lateEntrySectionId || !lateEntryClubId || getPositions(competition.format).some(position => (lateEntryPlayerModes[position.key] || "existing") === "existing" ? !lateEntryPlayers[position.key] : !(lateEntryNewPlayers[position.key]?.first_name || "").trim() || !(lateEntryNewPlayers[position.key]?.last_name || "").trim())}>
                                                {savingLateEntry ? "Adding entry..." : "Add Late Entry & Redraw Section"}
                                            </button>
                                        </div>
                                        {hasCompetitionScoringStarted() && <div className="small text-danger mt-2">Late entries are disabled because scoring has started.</div>}
                                    </div>
                                ) : sectionEntryAction === "replacement" ? (
                                    <>
                                        <div className="row g-3 align-items-end">
                                            <div className="col-md-4">
                                                <label className="form-label fw-semibold">Section</label>
                                                <select className="form-select" value={replacementSectionId} onChange={event => { setReplacementSectionId(event.target.value); setReplacementTeamId(""); setReplacementPlayerId(""); setReplacementPosition(""); }} disabled={hasCompetitionScoringStarted()}>
                                                    <option value="">Choose section</option>
                                                    {confirmedDraw.sections.map(section => <option key={section.id} value={section.id}>{section.section_name}</option>)}
                                                </select>
                                            </div>
                                            <div className="col-md-4">
                                                <label className="form-label fw-semibold">{competition.format === "singles" ? "Player to replace" : "Team containing player to replace"}</label>
                                                <select className="form-select" value={replacementTeamId} onChange={event => { setReplacementTeamId(event.target.value); setReplacementPlayerId(""); setReplacementPosition(""); }} disabled={!replacementSectionId || hasCompetitionScoringStarted()}>
                                                    <option value="">Choose entry</option>
                                                    {((confirmedDraw.sections.find(section => section.id === replacementSectionId)?.allTeams)
                                                        || confirmedDraw.sections.find(section => section.id === replacementSectionId)?.teams || []).filter(entry => {
                                                        const teamId = entry.competition_team_id || entry.id;
                                                        const entryTeam = teams.find(team => team.id === teamId);
                                                        return ["active", "withdrawn"].includes(entryTeam?.status);
                                                    }).map(entry => {
                                                        const teamId = entry.competition_team_id || entry.id;
                                                        const fullTeam = teams.find(team => team.id === teamId) || entry;
                                                        return <option key={teamId} value={teamId}>{getTeamBaseName(fullTeam)} — {fullTeam.clubs?.name || "Club not set"}</option>;
                                                    })}
                                                </select>
                                            </div>
                                            {competition.format !== "singles" && <div className="col-md-4">
                                                <label className="form-label fw-semibold">Player position to replace</label>
                                                <select className="form-select" value={replacementPosition} onChange={event => setReplacementPosition(event.target.value)} disabled={!replacementTeamId || hasCompetitionScoringStarted()}>
                                                    <option value="">Choose position</option>
                                                    {getPositions(competition.format).map(position => <option key={position.key} value={position.key}>{position.label}</option>)}
                                                </select>
                                            </div>}
                                        </div>
                                        {replacementTeamId && (() => {
                                            const selectedTeam = teams.find(team => team.id === replacementTeamId);
                                            const positionKey = competition.format === "singles" ? "player" : replacementPosition;
                                            const currentRosterRow = (selectedTeam?.competition_team_players || []).find(row => row.position === positionKey);
                                            const allocatedTeamIds = new Set((confirmedDraw?.sections || []).flatMap(section => [...(section.allTeams || []), ...(section.teams || [])].map(entry => String(entry.competition_team_id || entry.id))));
                                            const allocatedPlayerIds = new Set(teams.filter(team => allocatedTeamIds.has(String(team.id))).flatMap(team => (team.competition_team_players || []).filter(row => !(team.id === replacementTeamId && row.id === currentRosterRow?.id)).map(row => String(row.player_id))));
                                            const eligiblePlayers = players.filter(player => player.active !== false && !allocatedPlayerIds.has(String(player.id)) && String(player.id) !== String(currentRosterRow?.player_id || ""));
                                            const filteredPlayers = eligiblePlayers.filter(player => `${playerName(player)} ${player.bsa_number || ""} ${clubs.find(club => String(club.id) === String(player.club_id))?.name || ""} ${clubs.find(club => String(club.id) === String(player.second_club_id))?.name || ""}`.toLowerCase().includes(replacementSearch.toLowerCase()));
                                            return <div className="border rounded p-3 mt-3">
                                                <div className="small text-muted mb-2">Choose an eligible player from any club participating in this competition. Players already entered elsewhere in this competition are excluded.</div>
                                                <div className="btn-group mb-3" role="group">
                                                    <button type="button" className={`btn btn-sm ${replacementPlayerMode === "existing" ? "btn-primary" : "btn-outline-primary"}`} onClick={() => setReplacementPlayerMode("existing")}>Existing player</button>
                                                    <button type="button" className={`btn btn-sm ${replacementPlayerMode === "new" ? "btn-primary" : "btn-outline-primary"}`} onClick={() => setReplacementPlayerMode("new")}>Create new player</button>
                                                </div>
                                                {replacementPlayerMode === "existing" ? <>
                                                    <label className="form-label fw-semibold">Search all club players</label>
                                                    <input className="form-control mb-2" value={replacementSearch} onChange={event => setReplacementSearch(event.target.value)} placeholder="Search by player name or BSA number" />
                                                    <select className="form-select" value={replacementPlayerId} onChange={event => setReplacementPlayerId(event.target.value)} disabled={competition.format !== "singles" && !replacementPosition}>
                                                        <option value="">Choose replacement player</option>
                                                        {filteredPlayers.map(player => {
                                                            const playerClub = clubs.find(club => String(club.id) === String(player.club_id)) || clubs.find(club => String(club.id) === String(player.second_club_id));
                                                            return <option key={player.id} value={player.id}>{player.bsa_number ? `${player.bsa_number} — ` : ""}{playerName(player)}{playerClub?.short_name ? ` (${playerClub.short_name})` : ""}</option>;
                                                        })}
                                                    </select>
                                                    {!filteredPlayers.length && <div className="small text-muted mt-2">No eligible existing players match this search.</div>}
                                                </> : <>
                                                    <div className="row g-2">
                                                        <div className="col-md-6"><label className="form-label">First name *</label><input className="form-control" value={replacementNewPlayer.first_name} onChange={event => setReplacementNewPlayer(prev => ({ ...prev, first_name: event.target.value }))} /></div>
                                                        <div className="col-md-6"><label className="form-label">Surname *</label><input className="form-control" value={replacementNewPlayer.last_name} onChange={event => setReplacementNewPlayer(prev => ({ ...prev, last_name: event.target.value }))} /></div>
                                                        <div className="col-md-6"><label className="form-label">Nickname</label><input className="form-control" value={replacementNewPlayer.nickname} onChange={event => setReplacementNewPlayer(prev => ({ ...prev, nickname: event.target.value }))} /></div>
                                                        <div className="col-md-6"><label className="form-label">BSA number</label><input className="form-control" value={replacementNewPlayer.bsa_number} onChange={event => setReplacementNewPlayer(prev => ({ ...prev, bsa_number: event.target.value }))} /></div>
                                                        <div className="col-md-6"><label className="form-label">Player's club</label><select className="form-select" value={replacementNewPlayer.club_id || selectedTeam?.club_id || ""} onChange={event => setReplacementNewPlayer(prev => ({ ...prev, club_id: event.target.value }))}><option value="">Choose participating club</option>{participatingClubs.map(club => <option key={club.club_id} value={club.club_id}>{club.clubs?.name || "Unknown club"}</option>)}</select></div>
                                                    </div>
                                                    <div className="small text-muted mt-2">The new player will be added to the master player database under the selected participating club.</div>
                                                </>}
                                                <div className="d-flex justify-content-end mt-3"><button type="button" className="btn btn-primary" onClick={handleAddReplacement} disabled={savingSectionSwap || hasCompetitionScoringStarted() || (competition.format !== "singles" && !replacementPosition) || (replacementPlayerMode === "existing" && !replacementPlayerId) || (replacementPlayerMode === "new" && (!replacementNewPlayer.first_name.trim() || !replacementNewPlayer.last_name.trim()))}>{savingSectionSwap ? "Adding replacement…" : "Replace Withdrawn Entry"}</button></div>
                                            </div>;
                                        })()}
                                        {hasCompetitionScoringStarted() && <div className="text-danger small mt-2">Scoring has started. Replacements are no longer allowed.</div>}
                                    </>
                                ) : sectionEntryAction === "withdraw" ? (
                                    <>
                                        <div className="alert alert-warning py-2 small">
                                            Withdrawals are only permitted before scoring starts. The entry will be removed from the active draw, and the affected section's fixtures will be regenerated. Other sections and their bookings will be left unchanged.
                                        </div>
                                        <div className="row g-3 align-items-end">
                                            <div className="col-md-5">
                                                <label className="form-label fw-semibold">Section</label>
                                                <select className="form-select" value={withdrawSectionId} onChange={event => { setWithdrawSectionId(event.target.value); setWithdrawTeamId(""); }} disabled={hasCompetitionScoringStarted()}>
                                                    <option value="">Choose section</option>
                                                    {confirmedDraw.sections.map(section => <option key={section.id} value={section.id}>{section.section_name}</option>)}
                                                </select>
                                            </div>
                                            <div className="col-md-5">
                                                <label className="form-label fw-semibold">Entry to withdraw</label>
                                                <select className="form-select" value={withdrawTeamId} onChange={event => setWithdrawTeamId(event.target.value)} disabled={!withdrawSectionId || hasCompetitionScoringStarted()}>
                                                    <option value="">Choose entry</option>
                                                    {(confirmedDraw.sections.find(section => section.id === withdrawSectionId)?.teams || []).map(entry => {
                                                        const teamId = entry.competition_team_id || entry.id;
                                                        const fullTeam = teams.find(team => String(team.id) === String(teamId)) || entry;
                                                        return <option key={teamId} value={teamId}>{getSectionEntryOptionLabel(fullTeam)}</option>;
                                                    })}
                                                </select>
                                            </div>
                                            <div className="col-md-2 d-grid">
                                                <button type="button" className="btn btn-warning" disabled={!withdrawTeamId || savingSectionSwap || hasCompetitionScoringStarted()} onClick={() => {
                                                    const selectedTeam = teams.find(team => String(team.id) === String(withdrawTeamId));
                                                    if (!selectedTeam) {
                                                        alert("The selected entry could not be found. Refresh the competition and try again.");
                                                        return;
                                                    }
                                                    handleChangeTeamStatus(selectedTeam, "withdrawn");
                                                }}>
                                                    {savingSectionSwap ? "Withdrawing…" : "Withdraw Entry"}
                                                </button>
                                            </div>
                                        </div>
                                        {hasCompetitionScoringStarted() && <div className="text-danger small mt-2">Scoring has started. Entries can no longer be withdrawn or reinstated.</div>}
                                    </>
                                ) : (
                                    <>
                                <div className="row g-3 align-items-end">
                                    <div className="col-md-3">
                                        <label className="form-label fw-semibold">From section</label>
                                        <select className="form-select" value={swapSectionA} onChange={event => { setSwapSectionA(event.target.value); setSwapTeamA(""); }}>
                                            <option value="">Choose section</option>
                                            {confirmedDraw.sections.map(section => <option key={section.id} value={section.id}>{section.section_name}</option>)}
                                        </select>
                                    </div>
                                    <div className="col-md-3">
                                        <label className="form-label fw-semibold">Entry to move</label>
                                        <select className="form-select" value={swapTeamA} onChange={event => setSwapTeamA(event.target.value)} disabled={!swapSectionA}>
                                            <option value="">Choose entry</option>
                                            {(confirmedDraw.sections.find(section => section.id === swapSectionA)?.teams || []).map(entry => {
                                                const teamId = entry.competition_team_id || entry.id;
                                                const fullTeam = teams.find(team => team.id === teamId) || entry;
                                                return <option key={teamId} value={teamId}>{getSectionEntryOptionLabel(fullTeam)}</option>;
                                            })}
                                        </select>
                                    </div>
                                    <div className="col-md-3">
                                        <label className="form-label fw-semibold">To section</label>
                                        <select className="form-select" value={swapSectionB} onChange={event => { setSwapSectionB(event.target.value); setSwapTeamB(""); }}>
                                            <option value="">Choose section</option>
                                            {confirmedDraw.sections.filter(section => section.id !== swapSectionA).map(section => <option key={section.id} value={section.id}>{section.section_name}</option>)}
                                        </select>
                                    </div>
                                    {sectionEntryAction === "swap" && <div className="col-md-3">
                                        <label className="form-label fw-semibold">Entry to swap</label>
                                        <select className="form-select" value={swapTeamB} onChange={event => setSwapTeamB(event.target.value)} disabled={!swapSectionB}>
                                            <option value="">Choose entry</option>
                                            {(confirmedDraw.sections.find(section => section.id === swapSectionB)?.teams || []).map(entry => {
                                                const teamId = entry.competition_team_id || entry.id;
                                                const fullTeam = teams.find(team => team.id === teamId) || entry;
                                                return <option key={teamId} value={teamId}>{getSectionEntryOptionLabel(fullTeam)}</option>;
                                            })}
                                        </select>
                                    </div>}
                                </div>
                                <div className="d-flex justify-content-end mt-3">
                                    <button type="button" className="btn btn-primary"
                                        onClick={sectionEntryAction === "move" ? handleMoveSectionEntry : handleSwapSectionEntries}
                                        disabled={savingSectionSwap || !swapTeamA || !swapSectionA || !swapSectionB || (sectionEntryAction === "swap" && !swapTeamB)}>
                                        {savingSectionSwap ? "Updating draw…" : sectionEntryAction === "move" ? "Move Entry & Regenerate Fixtures" : "Swap Entries & Regenerate Fixtures"}
                                    </button>
                                </div>
                                    </>
                                )}
                            </div>}
                        </div>
                        <div className="row g-4">
                            <div className="col-lg-8">
                                <div className="card border"><div className="card-header bg-white"><strong>Sections & Sectional Fixtures</strong></div><div className="card-body">
                                    {confirmedDraw.sections.map(section => {
                                        const roundNumbers=[...new Set((section.matches||[]).map(m=>m.round?.round_number).filter(Boolean))].sort((a,b)=>a-b);
                                        return <div className="border rounded p-3 mb-3" key={section.id}>
                                            <div className="d-flex justify-content-between align-items-center mb-3"><strong>{section.section_name}</strong><span className="badge bg-secondary">{section.teams.length} teams</span></div>
                                            <div className="row g-2 mb-3">{section.teams.map(team=><div className="col-md-6" key={team.id}><div className="small border rounded px-2 py-1 bg-light"><TeamDisplay team={team} />{team.clubs?.name && <span className="text-muted"> — {team.clubs.name}</span>}</div></div>)}</div>
                                            {roundNumbers.map(n=>{ const roundMatches=section.matches.filter(m=>m.round?.round_number===n).sort((a,b)=>a.match_number-b.match_number); const byeTeam=getSectionByeTeam(section,n); return <div className="mb-3" key={n}><div className="fw-semibold small mb-2">Sectional Round {n}</div><div className="table-responsive"><table className="table table-sm table-bordered mb-0"><tbody>{roundMatches.map(m=><tr key={m.id}><td>{m.teamA ? <TeamDisplay team={m.teamA} /> : "TBC"}</td><td className="text-center fw-semibold">vs</td><td>{m.teamB ? <TeamDisplay team={m.teamB} /> : "TBC"}</td></tr>)}{byeTeam && <tr className="table-warning"><td className="fw-semibold"><TeamDisplay team={byeTeam} /></td><td className="text-center fw-semibold">—</td><td className="fw-semibold">{byeDisplayLabel}</td></tr>}</tbody></table></div></div>;})}
                                        </div>;
                                    })}
                                </div></div>
                            </div>
                            <div className="col-lg-4">
                                <div className="card border mb-3"><div className="card-header bg-white"><strong>Rounds</strong></div><div className="card-body">{confirmedDraw.rounds.map(round=><div className="d-flex justify-content-between align-items-center border-bottom py-2" key={round.id}><strong>{round.round_number}. {round.round_name}</strong><span className="badge bg-light text-dark border">{confirmedDraw.matches.filter(m=>m.round_id===round.id).length} matches</span></div>)}</div></div>
                                <div className="card border"><div className="card-header bg-white"><strong>Playoff Path</strong></div><div className="card-body">{confirmedDraw.rounds.filter(r=>playoffMatches.some(m=>m.round_id===r.id)).map(round=><div className="mb-3" key={round.id}><div className="fw-semibold mb-2">{round.round_name}</div>{confirmedDraw.matches.filter(m=>m.round_id===round.id).sort((a,b)=>a.match_number-b.match_number).map(m=><div className="small border rounded p-2 mb-2" key={m.id}><div>{m.teamA ? <TeamDisplay team={m.teamA} /> : "Winner of previous stage"}</div><div className="text-muted text-center">vs</div><div>{m.teamB ? <TeamDisplay team={m.teamB} /> : "Winner of previous stage"}</div></div>)}</div>)}</div></div>
                            </div>
                        </div>
                    </div>
                </div>
            ) : (
                <>
                    {/* Draw Planner */}

            <div id="workspace-draw-planner" className={`card shadow-sm border-0 mb-4 workspace-stage-card ${!showSetupDetails && workspaceStage !== "draw" ? "workspace-collapsed" : ""}`}>

                <div className="card-header bg-white d-flex justify-content-between align-items-center">

                    <div>

                        <h5 className="mb-0">

                            <i className="bi bi-diagram-3 me-2"></i>

                            Draw Planner

                        </h5>

                        <div className="small text-muted mt-1">

                            Calculate the recommended competition structure from the teams entered. Dates and rounds are scheduled after the draw is accepted.

                        </div>

                    </div>


                    <button
                        type="button"
                        className="btn btn-primary"
                        onClick={() => setShowDrawPlanner(!showDrawPlanner)}
                        disabled={teams.filter(team => team.status === "active").length < 3}
                    >

                        <i className="bi bi-magic me-2"></i>

                        Plan Draw

                    </button>

                </div>


                {showDrawPlanner && (

                    <div className="card-body">

                        <div className="alert alert-info mb-4">

                            <div className="fw-semibold mb-1">

                                Draw proposal only

                            </div>

                            <div>

                                BowlPoint will calculate the section structure, sectional rounds,
                                playoff structure and expected playing days. Nothing is saved until
                                the proposed draw is reviewed and confirmed.

                            </div>

                        </div>


                        <div className="row g-3 align-items-end mb-4">

                            <div className="col-md-5">

                                <label className="form-label fw-semibold">

                                    Competition Type

                                </label>

                                <select
                                    className="form-select"
                                    value={drawType}
                                    onChange={e => {
                                        setDrawType(e.target.value);
                                        setDrawProposal(null);
                                    }}
                                >

                                    <option value="weekend">Weekend Tournament</option>

                                    <option value="midweek">Midweek Tournament</option>

                                    <option value="week">Weekday Tournament</option>

                                </select>

                            </div>


                            {(competition?.name || "").toLowerCase().includes("ladies") &&
                                (competition?.name || "").toLowerCase().includes("pairs") && (
                                <div className="col-md-5">
                                    <button
                                        type="button"
                                        className="btn btn-outline-primary"
                                        onClick={handleLoadOfficialLadiesDraw}
                                        disabled={confirmingDraw || teams.filter(team => team.status === "active").length !== 27}
                                    >
                                        Load Official Ladies Draw (27 teams)
                                    </button>
                                    <div className="form-text">Loads the secretary's section assignments, opponents and byes into a local proposal for review. It does not save anything.</div>
                                </div>
                            )}

                            <div className="col-md-4">

                                <div className="text-muted small">

                                    Active Teams

                                </div>

                                <div className="fs-4 fw-bold">

                                    {teams.filter(team => team.status === "active").length}

                                </div>

                            </div>


                            <div className="col-md-3 text-md-end">

                                <button
                                    type="button"
                                    className="btn btn-success"
                                    onClick={handleGenerateDraw}
                                    disabled={generatingDraw || teams.filter(team => team.status === "active").length < 3}
                                >

                                    {generatingDraw ? (
                                        <>
                                            <span className="spinner-border spinner-border-sm me-2"></span>
                                            Calculating...
                                        </>
                                    ) : (
                                        <>
                                            <i className="bi bi-magic me-2"></i>
                                            Calculate Proposal
                                        </>
                                    )}

                                </button>

                            </div>

                        </div>


                        {!drawProposal && (

                            <div className="text-center py-4 text-muted">

                                <i className="bi bi-diagram-3 display-5"></i>

                                <div className="mt-3">

                                    Select the competition type and calculate the first draw proposal.

                                </div>

                            </div>

                        )}


                        {drawProposal && (

                            <>

                                <div className="row g-3 mb-4">

                                    <div className="col-md-3">
                                        <div className="card border h-100">
                                            <div className="card-body">
                                                <div className="text-muted small">Sections</div>
                                                <div className="fs-3 fw-bold">
                                                    {drawProposal.recommendedPlan.sectionCount === 1
                                                        ? "None"
                                                        : drawProposal.recommendedPlan.sectionCount}
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="col-md-3">
                                        <div className="card border h-100">
                                            <div className="card-body">
                                                <div className="text-muted small">Sectional Rounds</div>
                                                <div className="fs-3 fw-bold">
                                                    {drawProposal.recommendedPlan.sectionalRounds}
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="col-md-3">
                                        <div className="card border h-100">
                                            <div className="card-body">
                                                <div className="text-muted small">Playoff Rounds</div>
                                                <div className="fs-3 fw-bold">
                                                    {drawProposal.recommendedPlan.playoffStages.length}
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="col-md-3">
                                        <div className="card border h-100">
                                            <div className="card-body">
                                                <div className="text-muted small">Required Playing Rounds</div>
                                                <div className="fs-3 fw-bold">
                                                    {drawProposal.recommendedPlan.totalRounds}
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>


                                <div className="alert alert-success">

                                    <div className="fw-semibold mb-1">

                                        Recommended Draw

                                    </div>

                                    <div>

                                        {drawProposal.recommendedPlan.schedule.normalSchedule}

                                    </div>

                                    <div className="small mt-2">

                                        {drawProposal.source === "official_ladies_district_pairs_pdf"
                                            ? "Official sectional pairings and byes loaded from the secretary's draw. Confirming creates the fixtures; dates, Riverside venues and rink allocations must be set in the Playing Schedule."
                                            : drawProposal.recommendedPlan.schedule.competitionType === "weekend"
                                                ? `${drawProposal.recommendedPlan.schedule.saturdaySectionalRounds} sectional round(s) Saturday + ${drawProposal.recommendedPlan.schedule.sundaySectionalRounds} sectional round(s) Sunday, followed by ${drawProposal.recommendedPlan.schedule.playoffRoundsOnSunday} playoff round(s) where required.`
                                                : drawProposal.recommendedPlan.schedule.competitionType === "week"
                                                    ? `${drawProposal.recommendedPlan.totalRounds} playing day(s) required at up to 2 rounds per weekday.`
                                                    : `${drawProposal.recommendedPlan.totalRounds} playing day(s) required at one round per day.`}

                                    </div>

                                </div>


                                {drawProposal.recommendedPlan.schedule.overflow && (
                                    <div className="alert alert-warning">

                                        <strong>Secretary approval may be required:</strong>{" "}
                                        the sectional stage exceeds the preferred weekend pattern.

                                    </div>
                                )}


                                <div className="row g-4">

                                    <div className="col-lg-8">

                                        <div className="card border">

                                            <div className="card-header bg-white">

                                                <div className="d-flex justify-content-between align-items-center">

                                                    <div>
                                                        <strong>Recommended Section Allocation</strong>
                                                        <div className="small text-muted">
                                                            {drawProposal.recommendedPlan.sectionCount === 1
                                                                ? "Single round robin"
                                                                : `${drawProposal.recommendedPlan.sectionCount} sections • ${drawProposal.recommendedPlan.sectionSizes.join(" / ")} teams`}
                                                        </div>
                                                    </div>

                                                    <div className="d-flex align-items-center gap-2">
                                                        {isEditingDrawProposal && (
                                                            <span className="badge bg-info text-dark">Drag & drop enabled</span>
                                                        )}
                                                        <span className="badge bg-success">Recommended</span>
                                                    </div>

                                                </div>

                                            </div>

                                            <div className="card-body">

                                                <div className="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                                                    <div className="small text-muted">
                                                        {isEditingDrawProposal
                                                            ? "Drag an entry onto an entry in another section to swap them. Section sizes will remain unchanged."
                                                            : "You can balance the proposed sections before confirming the draw."}
                                                    </div>
                                                    <button
                                                        type="button"
                                                        className={`btn btn-sm ${isEditingDrawProposal ? "btn-success" : "btn-outline-primary"}`}
                                                        onClick={() => {
                                                            setIsEditingDrawProposal(value => !value);
                                                            setDraggedProposalTeamId("");
                                                            setProposalEditMessage("");
                                                        }}
                                                    >
                                                        <i className={`bi ${isEditingDrawProposal ? "bi-check-lg" : "bi-arrows-move"} me-2`}></i>
                                                        {isEditingDrawProposal ? "Done Editing" : "Edit Sections"}
                                                    </button>
                                                </div>

                                                {proposalEditMessage && (
                                                    <div className="alert alert-success py-2 mb-3" role="status">
                                                        {proposalEditMessage}
                                                    </div>
                                                )}

                                                {drawProposal.recommendedPlan.sections.map(section => (

                                                    <div className="border rounded p-3 mb-3" key={section.number}>

                                                        <div className="d-flex justify-content-between align-items-center mb-2">
                                                            <strong>
                                                                {drawProposal.recommendedPlan.sectionCount === 1
                                                                    ? "Round Robin"
                                                                    : `Section ${section.number}`}
                                                            </strong>
                                                            <span className="badge bg-secondary">
                                                                {section.teams.length} teams • {section.roundCount} rounds
                                                            </span>
                                                        </div>

                                                        <div className="row g-2">
                                                            {section.teams.map(team => (
                                                                <div className="col-md-6" key={team.id}>
                                                                    <div
                                                                        className={`small border rounded px-2 py-2 ${
                                                                            isEditingDrawProposal ? "bg-white border-primary" : "bg-light"
                                                                        }`}
                                                                        draggable={isEditingDrawProposal}
                                                                        onDragStart={event => {
                                                                            if (!isEditingDrawProposal) return;
                                                                            setDraggedProposalTeamId(String(team.id));
                                                                            event.dataTransfer.effectAllowed = "move";
                                                                            event.dataTransfer.setData("text/plain", String(team.id));
                                                                        }}
                                                                        onDragOver={event => {
                                                                            if (isEditingDrawProposal) {
                                                                                event.preventDefault();
                                                                                event.dataTransfer.dropEffect = "move";
                                                                            }
                                                                        }}
                                                                        onDrop={event => {
                                                                            if (!isEditingDrawProposal) return;
                                                                            event.preventDefault();
                                                                            const draggedId = event.dataTransfer.getData("text/plain");
                                                                            if (draggedId) setDraggedProposalTeamId(draggedId);
                                                                            handleProposalEntryDrop(section.number, team.id);
                                                                        }}
                                                                        onDragEnd={() => setDraggedProposalTeamId("")}
                                                                        title={isEditingDrawProposal ? "Drag this entry onto an entry in another section to swap" : ""}
                                                                        style={isEditingDrawProposal ? { cursor: "grab" } : undefined}
                                                                    >
                                                                        {isEditingDrawProposal && (
                                                                            <i className="bi bi-grip-vertical text-primary me-1" aria-hidden="true"></i>
                                                                        )}
                                                                        <TeamDisplay team={team} />
                                                                        {team.clubName && (
                                                                            <span className="text-muted"> — {team.clubName}</span>
                                                                        )}
                                                                    </div>
                                                                </div>
                                                            ))}
                                                        </div>

                                                    </div>

                                                ))}

                                            </div>

                                        </div>

                                    </div>


                                    <div className="col-lg-4">

                                        <div className="card border mb-3">

                                            <div className="card-header bg-white">
                                                <strong>Playoff Path</strong>
                                            </div>

                                            <div className="card-body">

                                                {drawProposal.recommendedPlan.playoffStages.length === 0 ? (
                                                    <div className="text-muted">No playoffs — the competition is a straight round robin.</div>
                                                ) : (
                                                    <>
                                                        {drawProposal.recommendedPlan.playoffStages.map(stage => (
                                                            <div className="mb-2" key={stage}>
                                                                <span className="badge bg-primary me-2">
                                                                    {stage.replaceAll("_", " ")}
                                                                </span>
                                                            </div>
                                                        ))}

                                                        <hr />

                                                        <div className="small text-muted mb-1">Section winners</div>
                                                        <div className="small">
                                                            Points first, then total Aggregate.
                                                        </div>

                                                        <div className="small mt-2">
                                                            Aggregate = total shots for − total shots against.
                                                        </div>

                                                    </>
                                                )}

                                            </div>

                                        </div>


                                        <div className="card border">

                                            <div className="card-header bg-white">
                                                <strong>Alternative</strong>
                                            </div>

                                            <div className="card-body">

                                                {drawProposal.alternativePlans.length === 0 ? (
                                                    <div className="text-muted small">
                                                        No alternative is required for this team count.
                                                    </div>
                                                ) : (
                                                    <>
                                                        <div className="small text-muted mb-2">
                                                            Same competition structure, different team allocation.
                                                        </div>

                                                        <div className="small">
                                                            Same-club pairs: <strong>{drawProposal.alternativePlans[0].sameClubPairs}</strong>
                                                        </div>

                                                        <div className="small mt-2">
                                                            Section sizes: <strong>{drawProposal.alternativePlans[0].sectionSizes.join(" / ")}</strong>
                                                        </div>

                                                    </>
                                                )}

                                            </div>

                                        </div>

                                    </div>

                                </div>


                                <div className="d-flex justify-content-end gap-2 mt-4">

                                    <button
                                        type="button"
                                        className="btn btn-outline-secondary"
                                        onClick={clearDrawProposal}
                                    >
                                        Clear Proposal
                                    </button>

                                    <button
                                        type="button"
                                        className="btn btn-primary"
                                        onClick={handleConfirmDraw}
                                        disabled={confirmingDraw}
                                    >
                                        {confirmingDraw ? (
                                            <>
                                                <span className="spinner-border spinner-border-sm me-2"></span>
                                                Confirming...
                                            </>
                                        ) : (
                                            <>
                                                <i className="bi bi-check-lg me-2"></i>
                                                Confirm Draw
                                            </>
                                        )}
                                    </button>

                                </div>

                            </>

                        )}

                    </div>

                )}

            </div>
                </>
            )}

            {confirmedDraw && scheduleProposal && (
                <div id="workspace-schedule" className={`card shadow-sm border-0 mb-4 workspace-stage-card ${!showSetupDetails && workspaceStage !== "schedule" ? "workspace-collapsed" : ""}`}>
                    <div className="card-header bg-white d-flex justify-content-between align-items-center">
                        <div>
                            <h5 className="mb-0">
                                <i className="bi bi-calendar3 me-2"></i>
                                Schedule Proposal
                            </h5>
                            <div className="small text-muted mt-1">
                                Calculated from the confirmed draw. No dates or venues are being saved yet.
                            </div>
                        </div>
                        <span className="badge bg-info text-dark">Proposal only</span>
                    </div>

                    <div className="card-body">
                        <div className="row g-3 mb-4">
                            <div className="col-md-3">
                                <div className="border rounded p-3 h-100">
                                    <div className="text-muted small">Tournament Type</div>
                                    <div className="fw-bold">
                                        {scheduleProposal.competitionType === "weekend"
                                            ? "Weekend"
                                            : scheduleProposal.competitionType === "week"
                                                ? "Weekday Tournament"
                                                : "Midweek"}
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-3">
                                <div className="border rounded p-3 h-100">
                                    <div className="text-muted small">Playing Days Required</div>
                                    <div className="fs-4 fw-bold">{scheduleProposal.playingDaysRequired}</div>
                                </div>
                            </div>
                            <div className="col-md-3">
                                <div className="border rounded p-3 h-100">
                                    <div className="text-muted small">Sectional Rounds</div>
                                    <div className="fs-4 fw-bold">{scheduleProposal.sectionalRounds}</div>
                                </div>
                            </div>
                            <div className="col-md-3">
                                <div className="border rounded p-3 h-100">
                                    <div className="text-muted small">Playoff Rounds</div>
                                    <div className="fs-4 fw-bold">{scheduleProposal.playoffRounds}</div>
                                </div>
                            </div>
                        </div>

                        {scheduleProposal.competitionType === "weekend" && (
                            <div className="alert alert-info">
                                <strong>Weekend rule:</strong> the proposed schedule groups up to 3 rounds per playing session.
                                For every session, including playoffs, you may select either a Saturday or a Sunday. The suggested day is not compulsory.
                            </div>
                        )}

                        {scheduleProposal.competitionType === "week" && (
                            <div className="alert alert-info">
                                <strong>Weekday Tournament rule:</strong> the schedule groups a maximum of 2 rounds per playing day, Monday to Friday.
                                The competition continues into the following week when required. Playoff rounds are included in this limit.
                            </div>
                        )}

                        {scheduleProposal.competitionType === "week" && hasUnequalWeekdaySections && (
                            <div className="card border-info mb-3">
                                <div className="card-body">
                                    <div className="form-check form-switch mb-2">
                                        <input className="form-check-input" type="checkbox" id="weekdayEarlyStartEnabled"
                                            checked={earlyStartEnabled} onChange={event => setEarlyStartEnabled(event.target.checked)} />
                                        <label className="form-check-label fw-semibold" htmlFor="weekdayEarlyStartEnabled">
                                            Enable early start for the larger section
                                        </label>
                                    </div>
                                    <div className="small text-muted mb-3">
                                        The selected section plays its complete Round 1 (two matches and one BYE for a five-team section) on the Monday before the normal schedule. All other sections keep the normal weekday dates.
                                    </div>
                                    {earlyStartEnabled && (
                                        <div className="row g-2 align-items-end">
                                            <div className="col-md-6">
                                                <label className="form-label">Section to start early</label>
                                                <select className="form-select" value={earlyStartSectionId}
                                                    onChange={event => setEarlyStartSectionId(event.target.value)}>
                                                    <option value="">Select larger section</option>
                                                    {largestWeekdaySections.map(section => (
                                                        <option key={section.id} value={section.id}>
                                                            {section.section_name || `Section ${section.section_number}`} ({section.teamCount} teams)
                                                        </option>
                                                    ))}
                                                </select>
                                            </div>
                                            <div className="col-md-6">
                                                <label className="form-label">Early-start date</label>
                                                <input type="date" className="form-control" value={earlyStartDate} readOnly />
                                                <div className="form-text">Automatically one day before the first normal playing date.</div>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>
                        )}

                        {scheduleProposal.competitionType === "week" && earlyStartEnabled && earlyStartSectionId && earlyStartDate && (
                            <div className="card border-info mb-3">
                                <div className="card-header bg-white">
                                    <strong>Early Start Day</strong>
                                    <div className="small text-muted">Weekday Tournament — selected section starts one round early</div>
                                </div>
                                <div className="card-body">
                                    {(() => {
                                        const earlySection = confirmedDraw.sections?.find(section => String(section.id) === String(earlyStartSectionId));
                                        const firstRound = confirmedDraw.rounds?.find(round => Number(round.round_number) === 1);
                                        const earlyMatches = (earlySection?.matches || []).filter(match =>
                                            String(match.round_id || match.round?.id || "") === String(firstRound?.id || "") ||
                                            Number(match.round?.round_number || match.round_number) === 1
                                        );
                                        const actualGames = earlyMatches.filter(match => match.team_a_id && match.team_b_id).length;
                                        const sectionLabel = earlySection?.section_name || `Section ${earlySection?.section_number || ""}`;
                                        return (
                                            <div className="d-flex flex-wrap justify-content-between align-items-center gap-3">
                                                <div>
                                                    <div className="fw-semibold">{sectionLabel}</div>
                                                    <div className="small text-muted">Sectional Round 1 · {actualGames || 2} matches · 1 BYE</div>
                                                </div>
                                                <div className="text-end">
                                                    <div className="fw-semibold">{earlyStartDate}</div>
                                                    <span className="badge bg-info text-dark">Monday · Early start</span>
                                                </div>
                                            </div>
                                        );
                                    })()}
                                </div>
                            </div>
                        )}

                        <div className="row g-3">
                            {scheduleProposal.days.map(day => (
                                <div className="col-lg-4 col-md-6" key={day.key}>
                                    <div className="card border h-100">
                                        <div className="card-header bg-white">
                                            <strong>{day.label}</strong>
                                            <div className="small text-muted">{day.typeLabel}</div>
                                        </div>
                                        <div className="card-body">
                                            {day.rounds.map(round => (
                                                <div className="d-flex align-items-center border rounded p-2 mb-2" key={round.roundNumber}>
                                                    <span className="badge bg-primary me-2">R{round.roundNumber}</span>
                                                    <div>
                                                        <div className="fw-semibold">{round.roundName}</div>
                                                        <div className="small text-muted">{round.matchCount} matches</div>
                                                    </div>
                                                </div>
                                            ))}
                                            {!day.rounds.length && (
                                                <div className="text-muted small">No rounds scheduled.</div>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>

                        {scheduleProposal.requiresAdditionalWeekend && (
                            <div className="alert alert-warning mt-4 mb-0">
                                <strong>Additional weekend required.</strong> The confirmed draw cannot fit into one weekend under the competition secretary's preferred 3-round Saturday / 3-round Sunday pattern.
                            </div>
                        )}

                        <hr className="my-4" />

                        <div className="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h6 className="mb-1">Assign Actual Dates & Venues</h6>
                                <div className="small text-muted">
                                    The draw and round order are already confirmed. Assign the real playing dates first; the rink allocator will determine the host club and green for each individual game.
                                </div>
                            </div>
                            <span className={`badge ${scheduleAssignments.length && scheduleAssignments.every(item => item.playing_date) && confirmedDraw.rounds.every(round => round.competition_day_id) ? "bg-success" : "bg-secondary"}`}>
                                {scheduleAssignments.length && scheduleAssignments.every(item => item.playing_date) && confirmedDraw.rounds.every(round => round.competition_day_id) ? "Dates assigned" : "Dates required"}
                            </span>
                        </div>

                        {scheduleProposal.competitionType === "week" && earlyStartEnabled && earlyStartSectionId && earlyStartDate && (
                            <div className="col-12 mb-3">
                                <div className="border border-info rounded p-3 bg-light">
                                    <div className="row g-3 align-items-center">
                                        <div className="col-lg-3">
                                            <div className="fw-semibold">Early Start Day</div>
                                            <div className="small text-muted">Weekday Tournament — early section start</div>
                                            <div className="small mt-1">Sectional Round 1</div>
                                        </div>
                                        <div className="col-lg-3">
                                            <label className="form-label">Date</label>
                                            <input type="date" className="form-control" value={earlyStartDate} readOnly />
                                            <div className="small text-muted mt-1">Monday before Playing Day 1</div>
                                        </div>
                                        <div className="col-lg-4">
                                            <label className="form-label">Section playing</label>
                                            <div className="form-control bg-white">
                                                {weekdaySectionSizes.find(section => String(section.id) === String(earlyStartSectionId))?.section_name ||
                                                    `Section ${weekdaySectionSizes.find(section => String(section.id) === String(earlyStartSectionId))?.section_number || ""}`}
                                            </div>
                                            <div className="small text-muted mt-1">Only this section plays on the early-start date.</div>
                                        </div>
                                        <div className="col-lg-2">
                                            <span className="badge bg-info text-dark">Early start</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}

                        <div className="row g-3">
                            {scheduleAssignments.map((assignment, index) => (
                                <div className="col-12" key={assignment.key}>
                                    <div className="border rounded p-3">
                                        <div className="row g-3 align-items-end">
                                            <div className="col-lg-3">
                                                <div className="fw-semibold">{assignment.label}</div>
                                                <div className="small text-muted">{assignment.typeLabel}</div>
                                                <div className="small mt-1">
                                                    {scheduleProposal.days[index]?.rounds.map(round => round.roundName).join(" • ")}
                                                </div>
                                            </div>
                                            <div className="col-lg-3">
                                                <label className="form-label">Date</label>
                                                <input
                                                    type="date"
                                                    className="form-control"
                                                    value={assignment.playing_date}
                                                    onChange={e => handleScheduleAssignmentChange(index, "playing_date", e.target.value)}
                                                />
                                                <div className="small text-muted mt-1">
                                                    {scheduleProposal.competitionType === "weekend"
                                                        ? (assignment.playing_date
                                                            ? `Selected: ${new Date(`${assignment.playing_date}T12:00:00`).toLocaleDateString("en-ZA", { weekday: "long" })} — Saturday or Sunday allowed`
                                                            : "Saturday or Sunday allowed")
                                                        : "Weekday required"}
                                                </div>
                                            </div>
                                            <div className="col-lg-4">
                                                <label className="form-label">Venue allocation</label>
                                                <div className="form-control bg-light text-muted">
                                                    Assigned per game by the rink allocator
                                                </div>
                                                <div className="small text-muted mt-1">
                                                    Club, green and rink will be selected after dates are saved.
                                                </div>
                                            </div>
                                            <div className="col-lg-2">
                                                <label className="form-label">Day Name</label>
                                                <input
                                                    type="text"
                                                    className="form-control"
                                                    value={assignment.name}
                                                    onChange={e => handleScheduleAssignmentChange(index, "name", e.target.value)}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>

                        <div className="d-flex flex-wrap justify-content-between gap-2 mt-4">
                            <button
                                type="button"
                                className="btn btn-outline-primary"
                                onClick={() => navigate(`/facilities/allocation/${competitionId}`)}
                                disabled={!scheduleSaved || savingSchedule}
                                title={scheduleSaved ? "Open rink allocation" : "Save the schedule before allocating club greens and rinks"}
                            >
                                <i className="bi bi-grid-3x3-gap me-2"></i>Allocate Club Greens & Rinks
                            </button>
                            <button
                                type="button"
                                className="btn btn-primary"
                                onClick={handleSaveSchedule}
                                disabled={savingSchedule || !scheduleAssignments.length}
                            >
                                {savingSchedule ? (
                                    <>
                                        <span className="spinner-border spinner-border-sm me-2"></span>
                                        Saving Schedule...
                                    </>
                                ) : (
                                    <>
                                        <i className="bi bi-calendar-check me-2"></i>
                                        Save Schedule
                                    </>
                                )}
                            </button>
                        </div>
                        {!scheduleSaved && (
                            <div className="small text-muted mt-2">
                                Save the schedule first. Club greens and rinks can be allocated once all playing dates have been saved.
                            </div>
                        )}
                    </div>
                </div>
            )}


            {confirmedDraw && (
                <div id="workspace-results" className={`card shadow-sm border-0 mb-4 workspace-stage-card ${!showSetupDetails && !["scoring", "playoffs"].includes(workspaceStage) ? "workspace-collapsed" : ""}`}>
                    <div className="card-header bg-white d-flex justify-content-between align-items-center">
                        <div>
                            <h5 className="mb-0">
                                <i className="bi bi-list-check me-2"></i>
                                Fixtures & Schedule
                            </h5>
                            <div className="small text-muted mt-1">
                                The confirmed fixtures grouped by their assigned playing day and round.
                            </div>
                        </div>
                        <div className="d-flex align-items-center gap-2 flex-wrap">
                            <button
                                type="button"
                                className="btn btn-outline-success btn-sm"
                                onClick={() => navigate(`/facilities/allocation/${competitionId}`)}
                                disabled={!scheduleSaved}
                                title={scheduleSaved ? "Open rink allocation for this competition" : "Save the playing schedule before opening rink allocation"}
                            >
                                <i className="bi bi-grid-3x3-gap me-2"></i>
                                Rink Allocations
                            </button>
                            <button
                                type="button"
                                className="btn btn-outline-primary btn-sm"
                                onClick={() => handleExportDrawPdf(false)}
                                title="Export the draw without rink allocation details"
                            >
                                <i className="bi bi-file-earmark-pdf me-2"></i>
                                Draw PDF (No Rinks)
                            </button>
                            <button
                                type="button"
                                className="btn btn-primary btn-sm"
                                onClick={() => handleExportDrawPdf(true)}
                                title="Export the draw including allocated clubs, greens and rinks"
                            >
                                <i className="bi bi-file-earmark-pdf me-2"></i>
                                Draw PDF (With Rinks)
                            </button>
                            <span className={`badge ${confirmedDraw.rounds.length && confirmedDraw.rounds.every(round => round.competition_day_id) ? "bg-success" : "bg-secondary"}`}>
                            {confirmedDraw.rounds.length && confirmedDraw.rounds.every(round => round.competition_day_id)
                                ? "Scheduled"
                                : "Awaiting schedule"}
                            </span>
                        </div>
                    </div>

                    <div className="card-body">
                        {(() => {
                            const getTeamLabel = (match, side) => {
                                const team = side === "a" ? match.teamA : match.teamB;
                                if (team) {
                                    return <TeamDisplay team={team} />;
                                }

                                const roundName = (match.round?.round_name || "").toLowerCase();
                                const matchNumber = Number(match.match_number) || 0;

                                if (roundName.includes("quarter") && confirmedDraw.sections.length === 8) {
                                    const pairs = [
                                        ["Section 1 Winner", "Section 3 Winner"],
                                        ["Section 2 Winner", "Section 4 Winner"],
                                        ["Section 5 Winner", "Section 7 Winner"],
                                        ["Section 6 Winner", "Section 8 Winner"]
                                    ];
                                    return pairs[matchNumber - 1]?.[side === "a" ? 0 : 1] || "Qualified team";
                                }

                                if (roundName.includes("semi") && matchNumber <= 2) {
                                    if (confirmedDraw.sections.length === 4) {
                                        const pairs = [
                                            ["Section 1 Winner", "Section 3 Winner"],
                                            ["Section 2 Winner", "Section 4 Winner"]
                                        ];
                                        return pairs[matchNumber - 1]?.[side === "a" ? 0 : 1] || "Section winner";
                                    }
                                    const pairs = [
                                        ["Quarter Final 1 Winner", "Quarter Final 3 Winner"],
                                        ["Quarter Final 2 Winner", "Quarter Final 4 Winner"]
                                    ];
                                    return pairs[matchNumber - 1]?.[side === "a" ? 0 : 1] || "Quarter-final winner";
                                }

                                if (roundName.includes("final") && !roundName.includes("quarter") && !roundName.includes("semi") && matchNumber === 1) {
                                    return side === "a" ? "Semi Final 1 Winner" : "Semi Final 2 Winner";
                                }

                                return "To be determined";
                            };

                            const getDayForRound = (round) =>
                                playingDays.find(day => day.id === round.competition_day_id);

                            const scheduledDays = playingDays
                                .filter(day => confirmedDraw.rounds.some(round => round.competition_day_id === day.id))
                                .sort((a, b) => (a.day_number || 0) - (b.day_number || 0));

                            const unassignedRounds = confirmedDraw.rounds.filter(round => !round.competition_day_id);

                            const renderRound = (round) => {
                                const matches = confirmedDraw.matches
                                    .filter(match => match.round_id === round.id)
                                    .sort((a, b) => (a.match_number || 0) - (b.match_number || 0));

                                return (
                                    <div className="border rounded mb-3" key={round.id}>
                                        <div className="px-3 py-2 bg-light border-bottom d-flex justify-content-between align-items-center">
                                            <div>
                                                <span className="badge bg-primary me-2">R{round.round_number}</span>
                                                <strong>{round.round_name}</strong>
                                            </div>
                                            <span className="small text-muted">{matches.length} {matches.length === 1 ? "match" : "matches"}</span>
                                        </div>

                                        <div className="table-responsive">
                                            <table className="table table-sm table-hover mb-0 align-middle">
                                                <thead>
                                                    <tr>
                                                        <th style={{ width: "70px" }}>Match</th>
                                                        <th>Team A</th>
                                                        <th className="text-center" style={{ width: "60px" }}>vs</th>
                                                        <th>Team B</th>
                                                        <th className="text-center" style={{ width: "145px" }}>Result</th>
                                                        <th className="text-end" style={{ width: "150px" }}>Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {matches.map(match => (
                                                        <tr key={match.id}>
                                                            <td className="fw-semibold">{match.match_number}</td>
                                                            <td>{getTeamLabel(match, "a")}</td>
                                                            <td className="text-center text-muted">vs</td>
                                                            <td>{getTeamLabel(match, "b")}</td>
                                                            <td className="text-center fw-semibold">
                                                                {match.score_a !== null && match.score_a !== undefined && match.score_b !== null && match.score_b !== undefined
                                                                    ? `${match.score_a} — ${match.score_b}`
                                                                    : "—"}
                                                            </td>
                                                            <td className="text-end">
                                                                {match.completed ? (
                                                                    <button
                                                                        type="button"
                                                                        className="btn btn-sm btn-outline-secondary"
                                                                        onClick={() => openResultEditor(match)}
                                                                    >
                                                                        Edit Result
                                                                    </button>
                                                                ) : (
                                                                    <button
                                                                        type="button"
                                                                        className="btn btn-sm btn-primary"
                                                                        disabled={!match.team_a_id || !match.team_b_id}
                                                                        onClick={() => openResultEditor(match)}
                                                                    >
                                                                        Enter Result
                                                                    </button>
                                                                )}
                                                            </td>
                                                        </tr>
                                                    ))}
                                                    {!matches.length && (
                                                        <tr>
                                                            <td colSpan="6" className="text-muted text-center py-3">No fixtures found for this round.</td>
                                                        </tr>
                                                    )}
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                );
                            };

                            return (
                                <>
                                    {/* Sectional scoring is grouped by section rather than by round.
                                        This makes it much easier for the scorer to find a specific game
                                        when matches finish in a different order to the draw order. */}
                                    {confirmedDraw.sections?.length > 0 && (
                                        <div className="mb-4" style={{ overflowAnchor: "none" }}>
                                            <div className="d-flex justify-content-between align-items-center mb-3">
                                                <div>
                                                    <h5 className="mb-1">Sectional Scoring</h5>
                                                    <div className="small text-muted">
                                                        Games are grouped by section. Completed sections automatically roll up.
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="row g-3">
                                                {confirmedDraw.sections.map(section => {
                                                    const sectionMatches = (section.matches || [])
                                                        .filter(match => match.section_id !== null && match.section_id !== undefined)
                                                        .sort((a, b) => {
                                                            const roundDiff = (a.round?.round_number || 0) - (b.round?.round_number || 0);
                                                            if (roundDiff !== 0) return roundDiff;
                                                            return (a.match_number || 0) - (b.match_number || 0);
                                                        });

                                                    const sectionTeamCount = (section.teams || []).length;
                                                    const completedGames = sectionMatches.filter(match => match.completed).length;
                                                    const complete = isSectionComplete(section);
                                                    const winner = complete ? getSectionStandings(section.id)[0] : null;
                                                    const manuallyCollapsed = collapsedScoringSections[section.id];
                                                    const collapsed = manuallyCollapsed ?? complete;

                                                    const matchesByRound = sectionMatches.reduce((groups, match) => {
                                                        const roundNumber = match.round?.round_number || 0;
                                                        if (!groups[roundNumber]) groups[roundNumber] = [];
                                                        groups[roundNumber].push(match);
                                                        return groups;
                                                    }, {});

                                                    return (
                                                        <div className="col-12" key={section.id} id={`scoring-section-${section.id}`}>
                                                            <div
                                                                ref={element => { scoringSectionRefs.current[section.id] = element; }}
                                                                className={`card border ${collapsed ? "workspace-section-collapsed" : ""}`}
                                                                style={{ overflowAnchor: "none" }}
                                                            >
                                                                <div className="card-header bg-white d-flex justify-content-between align-items-center">
                                                                    <div>
                                                                        <strong>{section.section_name}</strong>
                                                                        <span className="badge bg-light text-dark border ms-2">{sectionTeamCount} teams</span>
                                                                    </div>
                                                                    <div className="d-flex align-items-center gap-2">
                                                                        {winner ? (
                                                                            <span className="badge bg-success">Winner: <TeamDisplay team={winner.team} /></span>
                                                                        ) : (
                                                                            <span className="badge bg-secondary">{completedGames}/{sectionMatches.length} games complete</span>
                                                                        )}
                                                                        <button
                                                                            type="button"
                                                                            className="btn btn-sm btn-outline-secondary"
                                                                            onClick={() => toggleScoringSection(section.id)}
                                                                            title={collapsed ? "Expand section" : "Collapse section"}
                                                                        >
                                                                            <i className={`bi ${collapsed ? "bi-chevron-down" : "bi-chevron-up"}`}></i>
                                                                        </button>
                                                                    </div>
                                                                </div>

                                                                {!collapsed && (
                                                                    <div className="card-body">
                                                                        {Object.keys(matchesByRound).sort((a, b) => Number(a) - Number(b)).map(roundNumber => {
                                                                            const roundMatches = matchesByRound[roundNumber];
                                                                            const round = confirmedDraw.rounds.find(r => r.round_number === Number(roundNumber));
                                                                            const day = round?.competition_day_id ? playingDays.find(d => d.id === round.competition_day_id) : null;
                                                                            const sectionRoundOverride = sectionRoundDateOverrides.find(item =>
                                                                                String(item.section_id) === String(section.id) &&
                                                                                String(item.round_id) === String(round?.id || "")
                                                                            );
                                                                            const displayedPlayingDate = sectionRoundOverride?.playing_date || day?.playing_date;
                                                                            const venue = day?.clubs?.name || clubs.find(club => club.id === day?.venue_club_id)?.name;

                                                                            return (
                                                                                <div className="mb-3" key={roundNumber}>
                                                                                    <div className="d-flex justify-content-between align-items-center mb-2">
                                                                                        <div className="fw-semibold">
                                                                                            <span className="badge bg-primary me-2">R{roundNumber}</span>
                                                                                            {round?.round_name || `Sectional Round ${roundNumber}`}
                                                                                        </div>
                                                                                        <div className="small text-muted">
                                                                                            {displayedPlayingDate || "Date not assigned"}{venue ? ` • ${venue}` : ""}
                                                                                        </div>
                                                                                    </div>

                                                                                    <div className="table-responsive">
                                                                                        <table className="table table-sm table-hover table-bordered mb-0 align-middle">
                                                                                            <thead>
                                                                                                <tr>
                                                                                                    <th style={{ width: "70px" }}>Match</th>
                                                                                                    <th>Team A</th>
                                                                                                    <th className="text-center" style={{ width: "50px" }}>vs</th>
                                                                                                    <th>Team B</th>
                                                                                                    <th className="text-center" style={{ width: "145px" }}>Result</th>
                                                                                                    <th className="text-end" style={{ width: "150px" }}>Status</th>
                                                                                                </tr>
                                                                                            </thead>
                                                                                            <tbody>
                                                                                                {roundMatches.map(match => (
                                                                                                    <tr key={match.id}>
                                                                                                        <td className="fw-semibold">{match.match_number}</td>
                                                                                                        <td>{getTeamLabel(match, "a")}</td>
                                                                                                        <td className="text-center text-muted">vs</td>
                                                                                                        <td>{getTeamLabel(match, "b")}</td>
                                                                                                        <td className="text-center fw-semibold">
                                                                                                            {match.score_a !== null && match.score_a !== undefined && match.score_b !== null && match.score_b !== undefined ? (
                                                                                                                <div className="bowlpoint-result-display">
                                                                                                                    <div className="bowlpoint-result-score">
                                                                                                                        {match.score_a} <span className="bowlpoint-result-separator">—</span> {match.score_b}
                                                                                                                    </div>
                                                                                                                    {competition?.scoring?.skins?.enabled && (
                                                                                                                        <div className="bowlpoint-result-skins">
                                                                                                                            <span>{match.skins_a ?? 0} {Number(match.skins_a ?? 0) === 1 ? "skin" : "skins"}</span>
                                                                                                                            <span className="bowlpoint-result-skins-separator">—</span>
                                                                                                                            <span>{match.skins_b ?? 0} {Number(match.skins_b ?? 0) === 1 ? "skin" : "skins"}</span>
                                                                                                                        </div>
                                                                                                                    )}
                                                                                                                </div>
                                                                                                            ) : "—"}
                                                                                                        </td>
                                                                                                        <td className="text-end">
                                                                                                            {match.completed ? (
                                                                                                                <button type="button" className="btn btn-sm btn-outline-secondary" onClick={() => openResultEditor(match)}>Edit Result</button>
                                                                                                            ) : (
                                                                                                                <button type="button" className="btn btn-sm btn-primary" disabled={!match.team_a_id || !match.team_b_id} onClick={() => openResultEditor(match)}>Enter Result</button>
                                                                                                            )}
                                                                                                        </td>
                                                                                                    </tr>
                                                                                                ))}
                                                                                                {(() => {
                                                                                                    const byeTeam = getSectionByeTeam(section, roundNumber);
                                                                                                    return byeTeam ? (
                                                                                                        <tr key={`bye-${section.id}-${roundNumber}`} className="table-warning">
                                                                                                            <td className="fw-semibold">—</td>
                                                                                                            <td className="fw-semibold">{getTeamLabel({ teamA: byeTeam }, "a")}</td>
                                                                                                            <td className="text-center">—</td>
                                                                                                            <td className="fw-semibold">{byeDisplayLabel}</td>
                                                                                                            <td className="text-center fw-semibold">—</td>
                                                                                                            <td className="text-end"><span className="badge bg-warning text-dark">{byeDisplayLabel}</span></td>
                                                                                                        </tr>
                                                                                                    ) : null;
                                                                                                })()}
                                                                                            </tbody>
                                                                                        </table>
                                                                                    </div>
                                                                                </div>
                                                                            );
                                                                        })}
                                                                    </div>
                                                                )}
                                                            </div>
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        </div>
                                    )}

                                    {/* Playoffs remain grouped by round because they are not section-specific. */}
                                    {confirmedDraw.rounds.some(round => playoffMatches.some(match => match.round_id === round.id)) && (
                                        <div className="mb-4">
                                            <div className="d-flex justify-content-between align-items-center mb-3">
                                                <div>
                                                    <h5 className="mb-1">Playoff Scoring</h5>
                                                    <div className="small text-muted">Quarter-finals, semi-finals and final.</div>
                                                </div>
                                            </div>
                                            {confirmedDraw.rounds.filter(round => playoffMatches.some(match => match.round_id === round.id)).sort((a, b) => a.round_number - b.round_number).map(renderRound)}
                                        </div>
                                    )}

                                    {confirmedDraw.sections?.length > 0 && (
                                        <div id="workspace-section-standings" className="mt-4 pt-3 border-top" style={{ overflowAnchor: "none" }}>
                                            <div className="d-flex justify-content-between align-items-center mb-3">
                                                <div>
                                                    <h5 className="mb-1">Section Standings</h5>
                                                    <div className="small text-muted">Points first, then Aggregate (Shots For − Shots Against).</div>
                                                </div>
                                            </div>

                                            <div className="row g-3">
                                                {confirmedDraw.sections.map(section => {
                                                    const standings = getSectionStandings(section.id);
                                                    const complete = isSectionComplete(section);
                                                    const winner = complete ? standings[0] : null;

                                                    return (
                                                        <div className="col-12" key={section.id}>
                                                            <div
                                                                ref={element => { scoringSectionRefs.current[section.id] = element; }}
                                                                className={`card border h-100 ${collapsedScoringSections[section.id] ? "workspace-section-collapsed" : ""}`}
                                                                style={{ overflowAnchor: "none" }}
                                                            >
                                                                <div className="card-header bg-white d-flex justify-content-between align-items-center">
                                                                    <strong>{section.section_name}</strong>
                                                                    {winner ? (
                                                                        <span className="badge bg-success">Winner: <TeamDisplay team={winner.team} /></span>
                                                                    ) : (
                                                                        <span className="badge bg-secondary">In progress</span>
                                                                    )}
                                                                    <button type="button" className="btn btn-sm btn-link text-decoration-none ms-2" onClick={() => toggleScoringSection(section.id)}>
                                                                        <i className={`bi ${collapsedScoringSections[section.id] ? "bi-chevron-down" : "bi-chevron-up"}`}></i>
                                                                    </button>
                                                                </div>
                                                                <div className="table-responsive">
                                                                    <table className="table table-sm mb-0 align-middle">
                                                                        <thead>
                                                                            <tr>
                                                                                <th>#</th>
                                                                                <th>Team</th>
                                                                                <th className="text-center">P</th>
                                                                                <th className="text-center">W</th>
                                                                                <th className="text-center">D</th>
                                                                                <th className="text-center">L</th>
                                                                                {competition?.scoring?.skins?.enabled && <th className="text-center">Skins</th>}
                                                                                <th className="text-center">Pts</th>
                                                                                <th className="text-center">Agg</th>
                                                                            </tr>
                                                                        </thead>
                                                                        <tbody>
                                                                            {standings.map((row, index) => (
                                                                                <tr key={row.teamId} className={winner?.teamId === row.teamId ? "table-success" : ""}>
                                                                                    <td>{index + 1}</td>
                                                                                    <td className="fw-semibold"><TeamDisplay team={row.team} /></td>
                                                                                    <td className="text-center">{row.played}</td>
                                                                                    <td className="text-center">{row.wins}</td>
                                                                                    <td className="text-center">{row.draws}</td>
                                                                                    <td className="text-center">{row.losses}</td>
                                                                                    {competition?.scoring?.skins?.enabled && <td className="text-center">{row.skinsWon}</td>}
                                                                                    <td className="text-center fw-bold">{row.points}</td>
                                                                                    <td className="text-center">{row.aggregate > 0 ? `+${row.aggregate}` : row.aggregate}</td>
                                                                                </tr>
                                                                            ))}
                                                                        </tbody>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        </div>
                                    )}

                                    <div className="d-flex justify-content-between align-items-center mt-4 pt-3 border-top">
                                        <div className="small text-muted">
                                            Enter results here. Completed sections automatically roll up so the next active section stays in focus.
                                        </div>
                                        <div className="small text-muted">
                                            Enter completed results to update points and Aggregate. Section winners will advance automatically when their sectional stage is complete.
                                        </div>
                                    </div>
                                </>
                            );
                        })()}
                    </div>
                </div>
            )}


            {resultSavedMessage && (
                <div
                    className="position-fixed bottom-0 end-0 p-3"
                    style={{ zIndex: 1080 }}
                >
                    <div className="alert alert-success shadow-sm mb-0 d-flex align-items-center" role="status">
                        <i className="bi bi-check-circle-fill me-2"></i>
                        {resultSavedMessage}
                    </div>
                </div>
            )}

            {selectedMatch && (
                <div className="modal d-block" tabIndex="-1" style={{ backgroundColor: "rgba(0,0,0,0.45)" }}>
                    <div className="modal-dialog modal-dialog-centered">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">{selectedMatch.completed ? "Edit Result" : "Enter Result"}</h5>
                                <button type="button" className="btn-close" onClick={closeResultEditor} disabled={savingResult}></button>
                            </div>
                            <form onSubmit={handleSaveResult}>
                                <div className="modal-body">
                                    <div className="small text-muted mb-3">
                                        {selectedMatch.round?.round_name || "Match"} • Match {selectedMatch.match_number}
                                    </div>
                                    <div className="row g-3 align-items-end">
                                        <div className={competition?.scoring?.skins?.enabled ? "col-5" : "col-5"}>
                                            <label className="form-label fw-semibold">{getMatchTeamName(selectedMatch, "a")}</label>
                                            <input
                                                type="number" min="0" step="1"
                                                className="form-control form-control-lg text-center"
                                                value={resultForm.score_a}
                                                onChange={e => setResultForm(prev => ({ ...prev, score_a: e.target.value }))}
                                                autoFocus required
                                            />
                                            {competition?.scoring?.skins?.enabled && (
                                                <div className="mt-2">
                                                    <label className="form-label small fw-semibold mb-1">Skins</label>
                                                    <input type="number" min="0" step="1" className="form-control text-center" value={resultForm.skins_a} onChange={e => setResultForm(prev => ({ ...prev, skins_a: e.target.value }))} required />
                                                </div>
                                            )}
                                        </div>
                                        <div className="col-2 text-center pb-2 fw-bold">VS</div>
                                        <div className="col-5">
                                            <label className="form-label fw-semibold">{getMatchTeamName(selectedMatch, "b")}</label>
                                            <input
                                                type="number" min="0" step="1"
                                                className="form-control form-control-lg text-center"
                                                value={resultForm.score_b}
                                                onChange={e => setResultForm(prev => ({ ...prev, score_b: e.target.value }))}
                                                required
                                            />
                                            {competition?.scoring?.skins?.enabled && (
                                                <div className="mt-2">
                                                    <label className="form-label small fw-semibold mb-1">Skins</label>
                                                    <input type="number" min="0" step="1" className="form-control text-center" value={resultForm.skins_b} onChange={e => setResultForm(prev => ({ ...prev, skins_b: e.target.value }))} required />
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                    <div className="alert alert-light border mt-3 mb-0 small">
                                        Win = {competition?.scoring?.win ?? 2} points, Draw = {competition?.scoring?.draw ?? 1} points, Loss = {competition?.scoring?.loss ?? 0} points.
                                        {competition?.scoring?.skins?.enabled ? ` Each skin is worth ${competition.scoring.skins.pointsPerSkin ?? 1} additional point(s).` : ""}
                                        {" "}Aggregate is calculated from total Shots For minus Shots Against.
                                    </div>
                                </div>
                                <div className="modal-footer">
                                    <button type="button" className="btn btn-outline-secondary" onClick={closeResultEditor} disabled={savingResult}>Cancel</button>
                                    <button type="submit" className="btn btn-primary" disabled={savingResult}>
                                        {savingResult ? "Saving..." : "Save Result"}
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            )}

            <div className="alert alert-light border mb-4">

                <div className="fw-semibold">Next step</div>

                <div className="small text-muted mt-1">
                    {confirmedDraw ? "Enter match results to update sectional standings and automatically advance section winners into the playoff bracket." : "Once the draw proposal is accepted, BowlPoint will create the sections, rounds and fixtures. Only then will the Playing Schedule be used to assign actual dates and venues."}
                </div>

            </div>

            <div className="row g-4 mb-4 align-items-stretch">

                <div className="col-lg-6">

                    <div className="card shadow-sm border-0 h-100">

                        <div className="card-body p-4">

                            <h5 className="mb-2">
                                <i className="bi bi-bar-chart me-2"></i>
                                Results & Live Scoring
                            </h5>

                            <p className="text-muted mb-3">
                                Capture results and provide live competition standings.
                            </p>

                            <div className="small text-success fw-semibold">
                                Result entry is available from the scheduled fixtures above.
                            </div>

                        </div>

                    </div>

                </div>

                <div className="col-lg-6">

                    <CompetitionLiveCard
                        competition={competition}
                    />

                </div>

            </div>

            </div>
        </>
    );
}

export default CompetitionWorkspace;